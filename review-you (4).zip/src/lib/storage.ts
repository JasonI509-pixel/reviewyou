import { Quiz, QuizAttempt, NotebookEntry, SubjectStats, UserAccount, FreeformNote } from '../types';

const STORAGE_KEYS = {
  QUIZZES: 'review_you_quizzes_v2',
  ATTEMPTS: 'review_you_attempts_v2',
  NOTEBOOK: 'review_you_notebook_v2',
  FREEFORM_NOTES: 'review_you_freeform_notes_v2',
  ACTIVE_QUIZ: 'review_you_active_quiz_v2',
  USER_SETTINGS: 'review_you_settings_v2',
  ACCOUNTS: 'review_you_accounts_v2',
  ACTIVE_USER: 'review_you_active_user_v2',
};

// Clean default state — only tests, accounts, and notes created by the user
export const INITIAL_ACCOUNTS: UserAccount[] = [];
export const INITIAL_QUIZZES: Quiz[] = [];
export const INITIAL_NOTEBOOK: NotebookEntry[] = [];
export const INITIAL_ATTEMPTS: QuizAttempt[] = [];

export const INITIAL_FREEFORM_NOTES: FreeformNote[] = [
  {
    id: 'note_scratchpad_1',
    title: 'Study Scratchpad',
    content: 'Welcome to your Notebook!\n\nYou can type any word or note you want here without restrictions.\n\nTips:\n- Use Markdown headings, bullet points, or formulas.\n- Check live word & character counters below.\n- Click "Turn Note into Timed Test" to create custom exams from your notes instantly!',
    createdAt: new Date().toISOString(),
    lastModified: new Date().toISOString(),
    wordCount: 47,
    charCount: 310,
    tags: ['General', 'Notes'],
    paperStyle: 'slate',
    fontFamily: 'sans',
    fontSize: 'base',
  }
];

// Purge all previous accounts on startup as requested
if (typeof window !== 'undefined') {
  try {
    const purgeFlag = 'review_you_accounts_purged_v2';
    if (!localStorage.getItem(purgeFlag)) {
      localStorage.removeItem(STORAGE_KEYS.ACCOUNTS);
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
      localStorage.setItem(purgeFlag, 'true');
    }
  } catch (e) {
    console.error('Account purge error:', e);
  }
}

export const clearAllAccounts = (): void => {
  try {
    localStorage.removeItem(STORAGE_KEYS.ACCOUNTS);
    localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
  } catch (err) {
    console.error('Failed to clear accounts:', err);
  }
};

export const loadQuizzes = (): Quiz[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.QUIZZES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(INITIAL_QUIZZES));
      return INITIAL_QUIZZES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_QUIZZES;
  }
};

export const saveQuizzes = (quizzes: Quiz[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.QUIZZES, JSON.stringify(quizzes));
  } catch (err) {
    console.error('Failed to save quizzes:', err);
  }
};

export const loadNotebook = (): NotebookEntry[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.NOTEBOOK);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.NOTEBOOK, JSON.stringify(INITIAL_NOTEBOOK));
      return INITIAL_NOTEBOOK;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_NOTEBOOK;
  }
};

export const saveNotebook = (entries: NotebookEntry[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.NOTEBOOK, JSON.stringify(entries));
  } catch (err) {
    console.error('Failed to save notebook:', err);
  }
};

export const loadFreeformNotes = (): FreeformNote[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.FREEFORM_NOTES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.FREEFORM_NOTES, JSON.stringify(INITIAL_FREEFORM_NOTES));
      return INITIAL_FREEFORM_NOTES;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : INITIAL_FREEFORM_NOTES;
  } catch {
    return INITIAL_FREEFORM_NOTES;
  }
};

export const saveFreeformNotes = (notes: FreeformNote[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.FREEFORM_NOTES, JSON.stringify(notes));
  } catch (err) {
    console.error('Failed to save freeform notes:', err);
  }
};

export const loadAttempts = (): QuizAttempt[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ATTEMPTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(INITIAL_ATTEMPTS));
      return INITIAL_ATTEMPTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_ATTEMPTS;
  }
};

export const saveAttempts = (attempts: QuizAttempt[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.ATTEMPTS, JSON.stringify(attempts));
  } catch (err) {
    console.error('Failed to save attempts:', err);
  }
};

export const calculateSubjectStats = (attempts: QuizAttempt[]): Record<string, SubjectStats> => {
  const map: Record<string, {
    tests: number;
    totalScore: number;
    bestScore: number;
    totalTime: number;
    totalQuestions: number;
    correctQuestions: number;
    scores: number[];
  }> = {};

  attempts.forEach(att => {
    const sub = att.subject || 'General';
    if (!map[sub]) {
      map[sub] = {
        tests: 0,
        totalScore: 0,
        bestScore: 0,
        totalTime: 0,
        totalQuestions: 0,
        correctQuestions: 0,
        scores: [],
      };
    }
    map[sub].tests += 1;
    map[sub].totalScore += att.scorePercentage;
    map[sub].bestScore = Math.max(map[sub].bestScore, att.scorePercentage);
    map[sub].totalTime += att.totalDurationSeconds;
    map[sub].totalQuestions += att.totalQuestions;
    map[sub].correctQuestions += att.correctCount;
    map[sub].scores.push(att.scorePercentage);
  });

  const result: Record<string, SubjectStats> = {};
  Object.keys(map).forEach(sub => {
    const data = map[sub];
    const avgScore = Math.round(data.totalScore / data.tests);
    const avgSpeed = data.totalQuestions > 0 ? Math.round(data.totalTime / data.totalQuestions) : 0;
    
    // Calculate trend
    let trend: 'up' | 'down' | 'steady' = 'steady';
    if (data.scores.length >= 2) {
      const last = data.scores[data.scores.length - 1];
      const prev = data.scores[data.scores.length - 2];
      if (last > prev) trend = 'up';
      else if (last < prev) trend = 'down';
    }

    result[sub] = {
      subject: sub,
      testsTaken: data.tests,
      avgScore,
      bestScore: data.bestScore,
      avgSpeedSeconds: avgSpeed,
      masteryLevel: avgScore,
      recentTrend: trend,
      totalQuestionsAnswered: data.totalQuestions,
      correctQuestionsAnswered: data.correctQuestions,
    };
  });

  return result;
};

export const loadAccounts = (): UserAccount[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(INITIAL_ACCOUNTS));
      return INITIAL_ACCOUNTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_ACCOUNTS;
  }
};

export const saveAccounts = (accounts: UserAccount[]): void => {
  try {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(accounts));
  } catch (err) {
    console.error('Failed to save accounts:', err);
  }
};

export const loadActiveUser = (): UserAccount | null => {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.ACTIVE_USER);
    if (!raw) {
      return null;
    }
    return JSON.parse(raw);
  } catch {
    return null;
  }
};

export const getActiveUser = loadActiveUser;

export const saveActiveUser = (user: UserAccount | null): void => {
  try {
    if (user) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(user));
    } else {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_USER);
    }
  } catch (err) {
    console.error('Failed to save active user:', err);
  }
};

/**
 * Register a user account on the server for cross-device authentication.
 */
export const registerAccountCrossDevice = async (params: {
  name: string;
  email: string;
  password: string;
  studyGoal?: string;
  targetExam?: string;
  themeColor?: 'gold' | 'indigo' | 'emerald' | 'cyan' | 'rose' | 'purple' | 'orange';
}): Promise<UserAccount> => {
  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: params.name.trim(),
        email: params.email.trim().toLowerCase(),
        password: params.password,
        studyGoal: params.studyGoal,
        targetExam: params.targetExam,
        themeColor: params.themeColor,
      }),
    });

    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Failed to register account on server.');
    }

    const newUser: UserAccount = data.user;
    const accounts = loadAccounts();
    const updated = accounts.filter(a => a.email.toLowerCase() !== newUser.email.toLowerCase());
    saveAccounts([newUser, ...updated]);
    saveActiveUser(newUser);
    return newUser;
  } catch (err: any) {
    // If offline or network issue, create local account fallback
    if (err?.message?.includes('already exists')) {
      throw err;
    }
    console.warn('Falling back to local account creation:', err);
    return createAccount({
      name: params.name,
      email: params.email,
      studyGoal: params.studyGoal,
      targetExam: params.targetExam,
      themeColor: params.themeColor,
    });
  }
};

/**
 * Sign in to an existing account with email and password from ANY device.
 * Automatically synchronizes quizzes, notebooks, attempts, and notes from the cloud.
 */
export const loginAccountCrossDevice = async (
  email: string,
  password: string
): Promise<{ user: UserAccount; dataSynced: boolean }> => {
  const cleanEmail = email.trim().toLowerCase();

  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: cleanEmail, password }),
  });

  const body = await res.json();
  if (!res.ok || !body.success) {
    throw new Error(body.error || 'Login failed. Please check your credentials.');
  }

  const user: UserAccount = body.user;
  const cloudData = body.data;

  // Synchronize cloud data to local browser storage so device 2 gets device 1's content
  let dataSynced = false;
  if (cloudData) {
    if (Array.isArray(cloudData.quizzes) && cloudData.quizzes.length > 0) {
      const localQuizzes = loadQuizzes();
      // Merge unique quizzes by ID
      const map = new Map<string, Quiz>();
      cloudData.quizzes.forEach((q: Quiz) => map.set(q.id, q));
      localQuizzes.forEach(q => map.set(q.id, q));
      saveQuizzes(Array.from(map.values()));
      dataSynced = true;
    }

    if (Array.isArray(cloudData.notebook) && cloudData.notebook.length > 0) {
      const localNotebook = loadNotebook();
      const map = new Map<string, NotebookEntry>();
      cloudData.notebook.forEach((n: NotebookEntry) => map.set(n.id, n));
      localNotebook.forEach(n => map.set(n.id, n));
      saveNotebook(Array.from(map.values()));
      dataSynced = true;
    }

    if (Array.isArray(cloudData.attempts) && cloudData.attempts.length > 0) {
      const localAttempts = loadAttempts();
      const map = new Map<string, QuizAttempt>();
      cloudData.attempts.forEach((a: QuizAttempt) => map.set(a.id, a));
      localAttempts.forEach(a => map.set(a.id, a));
      saveAttempts(Array.from(map.values()));
      dataSynced = true;
    }

    if (Array.isArray(cloudData.freeformNotes) && cloudData.freeformNotes.length > 0) {
      const localNotes = loadFreeformNotes();
      const map = new Map<string, FreeformNote>();
      cloudData.freeformNotes.forEach((n: FreeformNote) => map.set(n.id, n));
      localNotes.forEach(n => map.set(n.id, n));
      saveFreeformNotes(Array.from(map.values()));
      dataSynced = true;
    }
  }

  // Save active user in localStorage
  const accounts = loadAccounts();
  const filtered = accounts.filter(a => a.email.toLowerCase() !== cleanEmail);
  saveAccounts([user, ...filtered]);
  saveActiveUser(user);

  return { user, dataSynced };
};

/**
 * Synchronize local user library and progress to cloud storage
 */
export const syncAccountDataToServer = async (userEmail?: string): Promise<boolean> => {
  const activeUser = getActiveUser();
  const email = userEmail || activeUser?.email;
  if (!email) return false;

  try {
    const quizzes = loadQuizzes();
    const notebook = loadNotebook();
    const freeformNotes = loadFreeformNotes();
    const attempts = loadAttempts();

    const res = await fetch('/api/auth/sync', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: email.trim().toLowerCase(),
        quizzes,
        notebook,
        freeformNotes,
        attempts,
        themeColor: activeUser?.themeColor,
        studyGoal: activeUser?.studyGoal,
        targetExam: activeUser?.targetExam,
      }),
    });

    return res.ok;
  } catch (err) {
    console.warn('Background cloud sync deferred:', err);
    return false;
  }
};

/**
 * Pull latest user data from server on app load
 */
export const fetchUserDataFromServer = async (email: string): Promise<boolean> => {
  if (!email) return false;
  try {
    const res = await fetch(`/api/auth/user-data?email=${encodeURIComponent(email.trim().toLowerCase())}`);
    if (!res.ok) return false;
    const body = await res.json();
    if (!body.success || !body.data) return false;

    const cloudData = body.data;
    if (Array.isArray(cloudData.quizzes) && cloudData.quizzes.length > 0) {
      const localQuizzes = loadQuizzes();
      const map = new Map<string, Quiz>();
      cloudData.quizzes.forEach((q: Quiz) => map.set(q.id, q));
      localQuizzes.forEach(q => map.set(q.id, q));
      saveQuizzes(Array.from(map.values()));
    }
    if (Array.isArray(cloudData.notebook) && cloudData.notebook.length > 0) {
      const localNotebook = loadNotebook();
      const map = new Map<string, NotebookEntry>();
      cloudData.notebook.forEach((n: NotebookEntry) => map.set(n.id, n));
      localNotebook.forEach(n => map.set(n.id, n));
      saveNotebook(Array.from(map.values()));
    }
    if (Array.isArray(cloudData.attempts) && cloudData.attempts.length > 0) {
      const localAttempts = loadAttempts();
      const map = new Map<string, QuizAttempt>();
      cloudData.attempts.forEach((a: QuizAttempt) => map.set(a.id, a));
      localAttempts.forEach(a => map.set(a.id, a));
      saveAttempts(Array.from(map.values()));
    }
    if (Array.isArray(cloudData.freeformNotes) && cloudData.freeformNotes.length > 0) {
      const localNotes = loadFreeformNotes();
      const map = new Map<string, FreeformNote>();
      cloudData.freeformNotes.forEach((n: FreeformNote) => map.set(n.id, n));
      localNotes.forEach(n => map.set(n.id, n));
      saveFreeformNotes(Array.from(map.values()));
    }
    return true;
  } catch (err) {
    console.warn('Could not fetch cloud data on startup:', err);
    return false;
  }
};

export const createAccount = (params: {
  name: string;
  email: string;
  studyGoal?: string;
  targetExam?: string;
  themeColor?: 'gold' | 'indigo' | 'emerald' | 'cyan' | 'rose' | 'purple' | 'orange';
}): UserAccount => {
  const accounts = loadAccounts();
  const existing = accounts.find(a => a.email.toLowerCase() === params.email.trim().toLowerCase());
  if (existing) {
    throw new Error('An account with this email address already exists. Please log in.');
  }

  const newUser: UserAccount = {
    id: `user_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    name: params.name.trim(),
    email: params.email.trim().toLowerCase(),
    avatarSeed: params.name.trim().split(' ')[0] || 'student',
    studyGoal: params.studyGoal || 'Comprehensive Test Preparation',
    targetExam: params.targetExam || 'General Review',
    themeColor: params.themeColor || 'gold',
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  const updated = [...accounts, newUser];
  saveAccounts(updated);
  saveActiveUser(newUser);
  return newUser;
};

export const loginUser = (email: string): UserAccount => {
  const accounts = loadAccounts();
  const found = accounts.find(a => a.email.toLowerCase() === email.trim().toLowerCase());
  if (!found) {
    throw new Error('No account found with this email. Please create a new account.');
  }
  const updatedUser: UserAccount = {
    ...found,
    lastLoginAt: new Date().toISOString(),
  };
  const updatedAccounts = accounts.map(a => (a.id === updatedUser.id ? updatedUser : a));
  saveAccounts(updatedAccounts);
  saveActiveUser(updatedUser);
  return updatedUser;
};

export const logoutUser = (): void => {
  saveActiveUser(null);
};
