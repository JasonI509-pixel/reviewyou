export interface DocumentTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  iconName: string;
  defaultTitle: string;
  content: string;
  paperStyle?: 'plain' | 'lined' | 'grid' | 'slate' | 'parchment' | 'word_light' | 'word_dark';
  fontFamily?: 'sans' | 'serif' | 'mono' | 'academic' | 'casual';
  fontSize?: 'xs' | 'sm' | 'base' | 'lg' | 'xl' | '2xl';
  lineSpacing?: '1.0' | '1.15' | '1.5' | '2.0';
  layoutMode?: 'paginated' | 'seamless' | 'split';
}

export const DOCUMENT_TEMPLATES: DocumentTemplate[] = [
  {
    id: 'blank',
    name: 'Blank Document',
    description: 'A completely clean, distraction-free page for writing anything you want.',
    category: 'General',
    iconName: 'FileText',
    defaultTitle: 'Untitled Document',
    content: '',
    paperStyle: 'word_dark',
    fontFamily: 'sans',
    fontSize: 'base',
    lineSpacing: '1.15',
    layoutMode: 'paginated',
  },
  {
    id: 'cornell',
    name: 'Cornell Study Notes',
    description: 'The gold-standard academic framework with Cues, Main Notes, and Summary.',
    category: 'Study',
    iconName: 'BookOpen',
    defaultTitle: 'Cornell Notes: [Topic Name]',
    content: `# [TOPIC NAME] — Cornell Study Notes
**Subject:** General Science / Humanities | **Date:** ${new Date().toLocaleDateString()} | **Exam Target:** Midterm / Final

---

## 📌 Cues & Questions (Left Margin Cues)
*Use these prompt questions during active recall review:*
- **Q1:** What is the primary definition and significance of [Concept A]?
- **Q2:** How does [Mechanism X] differ from [Mechanism Y]?
- **Q3:** What is the main mathematical equation or principle governing this system?

---

## 📝 Lecture & Reading Notes
### 1. Fundamental Principles
- **Core Concept 1:** Write primary definition here with clear terminology.
- **Key Formula / Mechanism:** \`Formula or Rule\`
  - Detailed explanation of variables and conditions.
  - Exception to keep in mind for test questions.

### 2. Step-by-Step Process
1. **Initial State:** Setup conditions and prerequisites.
2. **Reaction / Transformation:** What occurs during the main phase.
3. **Equilibrium / Outcome:** The measurable end result.

### 3. High-Yield Examples
| Concept | Real-World Application | Key Distinction |
| :--- | :--- | :--- |
| **Category A** | Example in practice | Crucial detail to remember |
| **Category B** | Example in practice | Crucial detail to remember |

---

## 🎯 Quick Check: 3 Review Questions
- [ ] 1. Can I explain the main mechanism without looking at this page?
- [ ] 2. Have I memorized the key formula and units?
- [ ] 3. Did I identify the #1 trick question testers love to ask?

---

## 💡 Executive Summary (Bottom Reflection)
*Write a 2 to 3 sentence concise summary connecting the core big ideas:*
> In summary, [Topic Name] centers on the relationship between [A] and [B]. Mastery requires remembering [Key Distinction] and applying [Formula/Rule] accurately in problem-solving.
`,
    paperStyle: 'word_dark',
    fontFamily: 'sans',
    fontSize: 'base',
    lineSpacing: '1.15',
    layoutMode: 'paginated',
  },
  {
    id: 'exam_prep',
    name: 'Exam Prep & High-Yield Cheat Sheet',
    description: 'Compress an entire unit into must-know formulas, mechanisms, and traps.',
    category: 'Exam Prep',
    iconName: 'Zap',
    defaultTitle: 'High-Yield Exam Prep: [Subject]',
    content: `# High-Yield Exam Revision Sheet: [Subject / Exam Name]
**Target Score:** 95%+ | **Review Date:** ${new Date().toLocaleDateString()}

---

## ⚡ Must-Know Formulas & Definitions
- **Equation 1:** \`E = mc²\` (Energy-mass equivalence)
- **Equation 2:** \`PV = nRT\` (Ideal gas law, note units: P in atm, V in L, T in K)
- **Definition 1:** **Term A** — Clear 1-sentence definition.
- **Definition 2:** **Term B** — Clear 1-sentence definition.

---

## ⚠️ Top 5 Exam Traps & Tricky Distinctions
1. ❌ **Common Trap 1:** Confusing [Term A] with [Term B].
   - ✅ *Correction:* Remember that [Term A] requires [Condition X], whereas [Term B] is passive.
2. ❌ **Common Trap 2:** Forgetting to convert units (e.g. grams to kilograms, minutes to seconds).
3. ❌ **Common Trap 3:** Neglecting boundary conditions or zero-division edge cases.

---

## 🧠 High-Yield Concept Comparison Table
| Topic Area | Primary Function | Primary Catalyst / Factor | High-Yield Trap |
| :--- | :--- | :--- | :--- |
| **Concept Alpha** | Primary role description | Key catalyst | Watch out for unit scale |
| **Concept Beta** | Primary role description | Key catalyst | Commonly inverted |
| **Concept Gamma** | Primary role description | Key catalyst | Strict temperature dependence |

---

## 🎯 Practice Drill Checklist
- [ ] Solved 10 timed practice questions on this topic
- [ ] Re-reviewed all missed diagnostic explanations
- [ ] Successfully recited key formulas from memory in under 60 seconds
`,
    paperStyle: 'word_dark',
    fontFamily: 'sans',
    fontSize: 'base',
    lineSpacing: '1.15',
    layoutMode: 'paginated',
  },
  {
    id: 'lab_report',
    name: 'Lab & Science Experiment Report',
    description: 'Structured scientific report with hypothesis, variables, data, and findings.',
    category: 'Science',
    iconName: 'FlaskConical',
    defaultTitle: 'Lab Report: [Experiment Title]',
    content: `# Laboratory Report: [Experiment Title]
**Researcher:** [Your Name] | **Course:** [Subject / Lab Section] | **Date:** ${new Date().toLocaleDateString()}

---

## 1. Abstract / Objective
Briefly describe the primary purpose of the experiment, the hypothesis tested, and the principal conclusion in 3 to 4 sentences.

---

## 2. Hypothesis & Variables
- **Hypothesis:** *If [independent variable] increases, then [dependent variable] will [increase/decrease] because [scientific rationale].*
- **Independent Variable:** [What you change]
- **Dependent Variable:** [What you measure]
- **Controlled Variables:** [Temperature, pressure, sample volume, timing]

---

## 3. Materials & Methodology
1. Gather all required reagents and calibrated apparatus.
2. Prepare the baseline control solution.
3. Conduct 3 repeated trials per test parameter to minimize experimental error.

---

## 4. Quantitative Results & Data Table
| Trial # | Independent Var (Units) | Dependent Var Measured (Units) | Percent Error (%) |
| :--- | :--- | :--- | :--- |
| **Trial 1** | 10.0 | 24.5 | 1.2% |
| **Trial 2** | 20.0 | 48.9 | 0.8% |
| **Trial 3** | 30.0 | 73.1 | 1.5% |

---

## 5. Discussion & Sources of Error
- **Analysis:** Discuss whether the empirical observations support the stated hypothesis.
- **Systematic Errors:** Calibrations, ambient temperature fluctuation.
- **Random Errors:** Parallax reading error, reaction timing latency.

---

## 6. Conclusion
State the conclusive outcome of the investigation and propose potential next steps for future inquiry.
`,
    paperStyle: 'word_dark',
    fontFamily: 'academic',
    fontSize: 'base',
    lineSpacing: '1.5',
    layoutMode: 'paginated',
  },
  {
    id: 'flashcard_glossary',
    name: 'Flashcard Deck & Key Glossary',
    description: 'Organize high-yield terms, mnemonics, and definitions ready for fast review.',
    category: 'Glossary',
    iconName: 'Layers',
    defaultTitle: 'Glossary & Flashcards: [Subject]',
    content: `# Study Glossary & Flashcard Deck: [Subject]
**Total Terms:** 8 | **Updated:** ${new Date().toLocaleDateString()}

---

## 🗂️ High-Yield Study Flashcards

### 🎴 Card 1
- **Front (Term / Question):** What is **[Core Term 1]**?
- **Back (Answer / Definition):** The fundamental process whereby [description].
- **Mnemonic / Memory Trick:** *Remember [Catchy Phrase or Acronym]*

---

### 🎴 Card 2
- **Front (Term / Question):** What are the three primary stages of **[Mechanism 2]**?
- **Back (Answer / Definition):** 1. Initiation, 2. Elongation, 3. Termination.
- **Mnemonic / Memory Trick:** *I-E-T (It's Easy Today)*

---

### 🎴 Card 3
- **Front (Term / Question):** What is the exact formula for calculating **[Metric 3]**?
- **Back (Answer / Definition):** \`Result = (Value A × Value B) / Constant C\`

---

## 📖 Alphabetical Reference Table
| Term | Category | Plain-English Definition | Exam Importance |
| :--- | :--- | :--- | :--- |
| **Term Alpha** | Core Concept | Brief 1-line definition | ★★★★★ |
| **Term Beta** | Mechanism | Brief 1-line definition | ★★★★☆ |
| **Term Gamma** | Property | Brief 1-line definition | ★★★☆☆ |
`,
    paperStyle: 'word_dark',
    fontFamily: 'sans',
    fontSize: 'base',
    lineSpacing: '1.15',
    layoutMode: 'paginated',
  },
  {
    id: 'book_synthesis',
    name: 'Book & Literature Synthesis',
    description: 'Deconstruct chapters, themes, arguments, key quotes, and critique.',
    category: 'Literature',
    iconName: 'Bookmark',
    defaultTitle: 'Book Analysis: [Book Title]',
    content: `# Literature Synthesis: [Book Title]
**Author:** [Author Name] | **Publication Year:** [Year] | **Genre / Field:** [Non-Fiction / Fiction]

---

## 📖 1. Core Thesis & Big Idea
What is the author's primary argument or central message? Summarize the work's primary contribution in 2 to 3 concise paragraphs.

---

## 🔑 2. Major Themes & Motifs
- **Theme 1:** [Title of Theme] — Explanation of how this theme is developed throughout the text.
- **Theme 2:** [Title of Theme] — Explanation with textual evidence and implications.
- **Theme 3:** [Title of Theme] — Connection to broader historical or scientific context.

---

## 💬 3. Memorable Quotes & Critical Analysis
> *"Insert notable quote from Chapter X here."*
- **Significance:** Why this passage represents a pivotal turning point in the argument.

---

## ❓ 4. Essential Discussion & Exam Questions
1. How does the author substantiate their primary claim in Part 2?
2. What are the chief counter-arguments to this perspective?
3. How can this text's framework be applied to contemporary challenges?
`,
    paperStyle: 'word_dark',
    fontFamily: 'serif',
    fontSize: 'base',
    lineSpacing: '1.5',
    layoutMode: 'paginated',
  }
];
