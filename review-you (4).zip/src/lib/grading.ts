// Smart evaluation and grading utility for Short Answer questions

export interface ShortAnswerGradingResult {
  score: number;
  isCorrect: boolean;
  feedback: string;
  keyPointsIncluded: string[];
  keyPointsMissed: string[];
  idealSummary: string;
}

const STOP_WORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and',
  'any', 'are', 'as', 'at', 'be', 'because', 'been', 'before', 'being', 'below',
  'between', 'both', 'but', 'by', 'can', 'did', 'do', 'does', 'doing', 'down',
  'during', 'each', 'few', 'for', 'from', 'further', 'had', 'has', 'have', 'having',
  'he', 'her', 'here', 'hers', 'herself', 'him', 'himself', 'his', 'how', 'i',
  'if', 'in', 'into', 'is', 'it', 'its', 'itself', 'just', 'me', 'more', 'most',
  'my', 'myself', 'no', 'nor', 'not', 'now', 'of', 'off', 'on', 'once', 'only',
  'or', 'other', 'our', 'ours', 'ourselves', 'out', 'over', 'own', 'same', 'she',
  'should', 'so', 'some', 'such', 'than', 'that', 'the', 'their', 'theirs', 'them',
  'themselves', 'then', 'there', 'these', 'they', 'this', 'those', 'through', 'to',
  'too', 'under', 'until', 'up', 'very', 'was', 'we', 'were', 'what', 'when',
  'where', 'which', 'while', 'who', 'whom', 'why', 'with', 'you', 'your', 'yours',
  'yourself', 'yourselves'
]);

// Helper to extract numbers from a string
export function extractNumbers(text: string): number[] {
  const matches = text.match(/-?\d+(?:\.\d+)?/g);
  if (!matches) return [];
  return matches.map(m => Number(m)).filter(n => !isNaN(n));
}

// Clean and normalize text
export function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"']/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Fast client-side and fallback evaluator for short answers.
 * Implements strict numerical accuracy (1 or more off = wrong, exact number = correct)
 * and conceptual similarity for qualitative text answers.
 */
export function evaluateShortAnswer(userAnswer: string, correctAnswer: string): ShortAnswerGradingResult {
  const cleanUser = (userAnswer || '').trim();
  const cleanRef = (correctAnswer || '').trim();

  if (!cleanUser) {
    return {
      score: 0,
      isCorrect: false,
      feedback: 'No answer was provided. Please write out your response.',
      keyPointsIncluded: [],
      keyPointsMissed: ['Complete solution or answer'],
      idealSummary: cleanRef,
    };
  }

  // 1. Direct normalized exact string match
  const normUser = normalizeText(cleanUser);
  const normRef = normalizeText(cleanRef);

  if (normUser === normRef) {
    return {
      score: 100,
      isCorrect: true,
      feedback: 'Excellent! Your answer matches the verified solution exactly.',
      keyPointsIncluded: ['Exact verified solution', 'Complete accuracy'],
      keyPointsMissed: [],
      idealSummary: cleanRef,
    };
  }

  // 2. Numerical / Mathematical Evaluation
  const refNumbers = extractNumbers(cleanRef);
  const userNumbers = extractNumbers(cleanUser);

  // Check if reference answer is primarily numerical or sequence of numbers
  if (refNumbers.length > 0) {
    // If reference is a single number (e.g. "16", "x = 16", "16 cm", etc.)
    if (refNumbers.length === 1) {
      const targetNum = refNumbers[0];

      if (userNumbers.length === 0) {
        return {
          score: 0,
          isCorrect: false,
          feedback: `Your answer did not include the numerical solution. The correct value is ${targetNum}.`,
          keyPointsIncluded: [],
          keyPointsMissed: [`Numerical value: ${targetNum}`],
          idealSummary: cleanRef,
        };
      }

      // Check if any of the numbers the user provided matches the target exactly
      const hasExactMatch = userNumbers.some(n => Math.abs(n - targetNum) < 0.0001);

      if (hasExactMatch) {
        return {
          score: 100,
          isCorrect: true,
          feedback: `Correct! You found the exact target value (${targetNum}).`,
          keyPointsIncluded: [`Calculated target value: ${targetNum}`],
          keyPointsMissed: [],
          idealSummary: cleanRef,
        };
      }

      // If user provided a number and it's 1 or more off
      const primaryUserNum = userNumbers[0];
      const diff = Math.abs(primaryUserNum - targetNum);
      return {
        score: 0,
        isCorrect: false,
        feedback: `Incorrect. Your answer of ${primaryUserNum} is ${diff % 1 === 0 ? diff : diff.toFixed(2)} off from the correct answer of ${targetNum}.`,
        keyPointsIncluded: ['Attempted numerical calculation'],
        keyPointsMissed: [`Accurate calculation (${targetNum})`],
        idealSummary: cleanRef,
      };
    }

    // Reference has multiple numbers (e.g. sequence "2, 8, 6, 12" or "14, 17, 20")
    if (refNumbers.length > 1) {
      if (userNumbers.length === refNumbers.length) {
        const allMatch = userNumbers.every((n, i) => Math.abs(n - refNumbers[i]) < 0.0001);
        if (allMatch) {
          return {
            score: 100,
            isCorrect: true,
            feedback: 'Spot on! All terms in your numerical sequence are completely accurate.',
            keyPointsIncluded: ['Full sequence terms verified'],
            keyPointsMissed: [],
            idealSummary: cleanRef,
          };
        }

        // Count matching terms
        const matchCount = userNumbers.filter((n, i) => Math.abs(n - refNumbers[i]) < 0.0001).length;
        const score = Math.round((matchCount / refNumbers.length) * 100);
        return {
          score,
          isCorrect: score >= 80,
          feedback: score >= 80
            ? `Good job! Most sequence numbers are correct (${matchCount}/${refNumbers.length}). Verified answer: ${cleanRef}.`
            : `Some numbers in your sequence were off. Expected ${cleanRef}, but received ${userNumbers.join(', ')}.`,
          keyPointsIncluded: [`${matchCount} correct sequence terms`],
          keyPointsMissed: [`Full sequence agreement (${cleanRef})`],
          idealSummary: cleanRef,
        };
      }

      // Check if user answer includes all the reference numbers
      const includedAll = refNumbers.every(rn => userNumbers.some(un => Math.abs(un - rn) < 0.0001));
      if (includedAll) {
        return {
          score: 100,
          isCorrect: true,
          feedback: 'Correct! Your response contains all the required target numbers.',
          keyPointsIncluded: ['All required numbers identified'],
          keyPointsMissed: [],
          idealSummary: cleanRef,
        };
      }
    }
  }

  // 3. Conceptual / Textual Evaluation
  const refTokens = normRef.split(' ').filter(w => w.length > 1 && !STOP_WORDS.has(w));
  const userTokens = normUser.split(' ').filter(w => w.length > 1 && !STOP_WORDS.has(w));

  if (refTokens.length === 0 || userTokens.length === 0) {
    // If either has no substantial words, fall back to string containment
    const isContained = normRef.includes(normUser) || normUser.includes(normRef);
    return {
      score: isContained ? 85 : 40,
      isCorrect: isContained,
      feedback: isContained
        ? 'Good! Your answer matches the main concept.'
        : 'Your answer does not match the key concept of the question.',
      keyPointsIncluded: isContained ? ['Core concept identified'] : [],
      keyPointsMissed: isContained ? [] : ['Detailed conceptual explanation'],
      idealSummary: cleanRef,
    };
  }

  // Count keyword matches
  const userTokenSet = new Set(userTokens);
  const matchedTokens = refTokens.filter(token => userTokenSet.has(token));
  const overlapRatio = matchedTokens.length / refTokens.length;

  // Check for substring containment of longer phrases
  const containsCore = normUser.includes(normRef) || (cleanRef.length > 15 && normUser.includes(normRef.slice(0, 20)));

  if (containsCore || overlapRatio >= 0.45) {
    const calculatedScore = Math.min(Math.max(Math.round(overlapRatio * 100) + 20, 85), 100);
    return {
      score: calculatedScore,
      isCorrect: true,
      feedback: 'Great response! Your answer accurately captures the essential concepts and key principles.',
      keyPointsIncluded: matchedTokens.slice(0, 4),
      keyPointsMissed: refTokens.filter(t => !userTokenSet.has(t)).slice(0, 3),
      idealSummary: cleanRef,
    };
  }

  // Lower overlap
  const calculatedScore = Math.round(overlapRatio * 100);
  return {
    score: calculatedScore,
    isCorrect: calculatedScore >= 70,
    feedback: calculatedScore >= 70
      ? 'Good answer! You have covered the key ideas with clear phrasing.'
      : 'Your answer touches on some terms but misses the primary explanation or verified conclusion.',
    keyPointsIncluded: matchedTokens,
    keyPointsMissed: refTokens.filter(t => !userTokenSet.has(t)).slice(0, 4),
    idealSummary: cleanRef,
  };
}
