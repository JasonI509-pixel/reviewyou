// Safe API utility functions with robust JSON validation, error interception, and timeout safeguards

export async function safeFetchJson<T = any>(
  url: string,
  options: RequestInit & { timeoutMs?: number } = {}
): Promise<T> {
  const defaultHeaders: Record<string, string> = {
    'Accept': 'application/json',
  };

  if (options.body && typeof options.body === 'string') {
    defaultHeaders['Content-Type'] = 'application/json';
  }

  const mergedHeaders = {
    ...defaultHeaders,
    ...(options.headers as Record<string, string> || {}),
  };

  const timeoutMs = options.timeoutMs || 60000;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    controller.abort();
  }, timeoutMs);

  try {
    const response = await fetch(url, {
      ...options,
      headers: mergedHeaders,
      signal: options.signal || controller.signal,
    });
    clearTimeout(timeoutId);

    const contentType = response.headers.get('content-type') || '';
    const isJson = contentType.includes('application/json');

    if (!response.ok) {
      if (isJson) {
        const errorJson = await response.json().catch(() => ({}));
        throw new Error(
          errorJson.error || errorJson.message || `Request failed with status ${response.status}`
        );
      } else {
        const errorText = await response.text().catch(() => '');
        if (errorText.trim().startsWith('<!doctype') || errorText.trim().startsWith('<html')) {
          throw new Error(`Server temporarily unavailable (${response.status}). Please try again.`);
        }
        throw new Error(errorText.slice(0, 120) || `Request failed with status ${response.status}`);
      }
    }

    if (!isJson) {
      const rawText = await response.text().catch(() => '');
      if (rawText.trim().startsWith('<!doctype') || rawText.trim().startsWith('<html')) {
        throw new Error('Received unexpected HTML response from server. Please retry in a moment.');
      }
      try {
        return JSON.parse(rawText) as T;
      } catch {
        throw new Error('Unable to parse server response format.');
      }
    }

    return (await response.json()) as T;
  } catch (err: any) {
    clearTimeout(timeoutId);
    if (err.name === 'AbortError') {
      throw new Error('The request timed out. Please try again.');
    }
    throw err;
  }
}
