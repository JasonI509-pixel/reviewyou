export type ThemeColor = 'gold' | 'indigo' | 'emerald' | 'cyan' | 'rose' | 'purple' | 'orange';

export interface ThemeConfig {
  id: ThemeColor;
  name: string;
  label: string;
  colorHex: string;
  secondaryHex: string;
  gradient: string;
  bgGradient: string;
  borderClass: string;
  textClass: string;
  bgClass: string;
  badgeClass: string;
  ringClass: string;
  glowColor: string;
  logoTextColor: string;
}

export const THEMES: Record<ThemeColor, ThemeConfig> = {
  gold: {
    id: 'gold',
    name: 'Review You Gold (Classic)',
    label: 'Classic Gold (Official Logo)',
    colorHex: '#E5C97A',
    secondaryHex: '#C9A038',
    gradient: 'from-[#E5C97A] via-[#F4DE9C] to-[#C9A038]',
    bgGradient: 'from-[#222718]/45 via-slate-950 to-slate-950',
    borderClass: 'border-[#E5C97A]/30 hover:border-[#E5C97A]/60',
    textClass: 'text-[#E5C97A]',
    bgClass: 'bg-[#E5C97A]',
    badgeClass: 'bg-[#E5C97A]/20 text-[#F4DE9C] border-[#E5C97A]/40',
    ringClass: 'ring-[#E5C97A]',
    glowColor: 'rgba(229, 201, 122, 0.3)',
    logoTextColor: '#E5C97A',
  },
  emerald: {
    id: 'emerald',
    name: 'Emerald Knowledge',
    label: 'Emerald Green',
    colorHex: '#10B981',
    secondaryHex: '#059669',
    gradient: 'from-emerald-400 via-teal-400 to-emerald-600',
    bgGradient: 'from-emerald-950/45 via-slate-950 to-slate-950',
    borderClass: 'border-emerald-400/30 hover:border-emerald-400/60',
    textClass: 'text-emerald-300',
    bgClass: 'bg-emerald-600',
    badgeClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30',
    ringClass: 'ring-emerald-400',
    glowColor: 'rgba(16, 185, 129, 0.3)',
    logoTextColor: '#34D399',
  },
  indigo: {
    id: 'indigo',
    name: 'Electric Indigo',
    label: 'Electric Indigo',
    colorHex: '#6366F1',
    secondaryHex: '#8B5CF6',
    gradient: 'from-indigo-400 via-indigo-500 to-purple-600',
    bgGradient: 'from-indigo-950/45 via-slate-950 to-slate-950',
    borderClass: 'border-indigo-400/30 hover:border-indigo-400/60',
    textClass: 'text-indigo-300',
    bgClass: 'bg-indigo-600',
    badgeClass: 'bg-indigo-500/20 text-indigo-300 border-indigo-400/30',
    ringClass: 'ring-indigo-400',
    glowColor: 'rgba(99, 102, 241, 0.3)',
    logoTextColor: '#818CF8',
  },
  cyan: {
    id: 'cyan',
    name: 'Cyber Cyan',
    label: 'Cyber Cyan',
    colorHex: '#06B6D4',
    secondaryHex: '#0284C7',
    gradient: 'from-cyan-400 via-sky-400 to-blue-600',
    bgGradient: 'from-cyan-950/45 via-slate-950 to-slate-950',
    borderClass: 'border-cyan-400/30 hover:border-cyan-400/60',
    textClass: 'text-cyan-300',
    bgClass: 'bg-cyan-600',
    badgeClass: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/30',
    ringClass: 'ring-cyan-400',
    glowColor: 'rgba(6, 182, 212, 0.3)',
    logoTextColor: '#22D3EE',
  },
  rose: {
    id: 'rose',
    name: 'Crimson Rose',
    label: 'Crimson Flame',
    colorHex: '#F43F5E',
    secondaryHex: '#E11D48',
    gradient: 'from-rose-400 via-red-500 to-orange-500',
    bgGradient: 'from-rose-950/45 via-slate-950 to-slate-950',
    borderClass: 'border-rose-400/30 hover:border-rose-400/60',
    textClass: 'text-rose-300',
    bgClass: 'bg-rose-600',
    badgeClass: 'bg-rose-500/20 text-rose-300 border-rose-400/30',
    ringClass: 'ring-rose-400',
    glowColor: 'rgba(244, 63, 94, 0.3)',
    logoTextColor: '#FB7185',
  },
  purple: {
    id: 'purple',
    name: 'Amethyst Royal',
    label: 'Amethyst Purple',
    colorHex: '#A855F7',
    secondaryHex: '#7C3AED',
    gradient: 'from-purple-400 via-purple-500 to-pink-600',
    bgGradient: 'from-purple-950/45 via-slate-950 to-slate-950',
    borderClass: 'border-purple-400/30 hover:border-purple-400/60',
    textClass: 'text-purple-300',
    bgClass: 'bg-purple-600',
    badgeClass: 'bg-purple-500/20 text-purple-300 border-purple-400/30',
    ringClass: 'ring-purple-400',
    glowColor: 'rgba(168, 85, 247, 0.3)',
    logoTextColor: '#C084FC',
  },
  orange: {
    id: 'orange',
    name: 'Sunset Tangerine',
    label: 'Sunset Tangerine',
    colorHex: '#F97316',
    secondaryHex: '#EA580C',
    gradient: 'from-amber-400 via-orange-500 to-red-500',
    bgGradient: 'from-orange-950/45 via-slate-950 to-slate-950',
    borderClass: 'border-orange-400/30 hover:border-orange-400/60',
    textClass: 'text-orange-300',
    bgClass: 'bg-orange-600',
    badgeClass: 'bg-orange-500/20 text-orange-300 border-orange-400/30',
    ringClass: 'ring-orange-400',
    glowColor: 'rgba(249, 115, 22, 0.3)',
    logoTextColor: '#FB923C',
  }
};

const THEME_STORAGE_KEY = 'review_you_theme_color_v1';

export const getSavedTheme = (): ThemeColor => {
  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY) as ThemeColor;
    if (saved && THEMES[saved]) {
      return saved;
    }
  } catch {
    // ignore
  }
  return 'gold'; // Default brand theme matches the logo
};

export const setSavedTheme = (theme: ThemeColor): void => {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, theme);
    applyThemeCss(theme);
  } catch (err) {
    console.error('Failed to save theme:', err);
  }
};

export const applyThemeCss = (theme: ThemeColor): void => {
  const config = THEMES[theme] || THEMES.gold;
  if (typeof document !== 'undefined') {
    const root = document.documentElement;
    root.style.setProperty('--brand-primary', config.colorHex);
    root.style.setProperty('--brand-secondary', config.secondaryHex);
    root.style.setProperty('--brand-glow', config.glowColor);
    root.setAttribute('data-theme', theme);
  }
};
