import React, { useState } from 'react';
import { 
  BookOpen, 
  CheckCircle2, 
  Play, 
  X, 
  Clock, 
  Tag, 
  Search, 
  Lightbulb, 
  Trash2,
  ChevronDown,
  ChevronUp,
  Sparkles,
  RotateCcw
} from 'lucide-react';
import { Quiz } from '../types';
import { sounds } from '../lib/sound';

interface PreTestStudyModalProps {
  quiz: Quiz | null;
  isOpen: boolean;
  onClose: () => void;
  onStartTest: (quiz: Quiz) => void;
  onDeleteQuiz?: (quizId: string) => void;
}

export const PreTestStudyModal: React.FC<PreTestStudyModalProps> = ({
  quiz,
  isOpen,
  onClose,
  onStartTest,
  onDeleteQuiz,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [questionMode, setQuestionMode] = useState<'same' | 'different'>('same');
  const [allExpanded, setAllExpanded] = useState(true);
  const [expandedMap, setExpandedMap] = useState<Record<string, boolean>>({});
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  if (!isOpen || !quiz) return null;

  // Study questions to display in this guide
  const sourceQuestions = (quiz.studyQuestions && quiz.studyQuestions.length > 0)
    ? quiz.studyQuestions
    : quiz.questions;

  const testQuestionsCount = quiz.questions?.length || sourceQuestions.length;
  const studyQuestionsCount = sourceQuestions.length;

  const filteredQuestions = sourceQuestions.filter(q => 
    q.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    q.correctAnswer.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (q.topicTag && q.topicTag.toLowerCase().includes(searchQuery.toLowerCase())) ||
    q.explanation.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleQuestionExpand = (id: string) => {
    sounds.playClick();
    setExpandedMap(prev => ({
      ...prev,
      [id]: prev[id] === undefined ? !allExpanded : !prev[id],
    }));
  };

  const toggleAll = () => {
    sounds.playClick();
    const next = !allExpanded;
    setAllExpanded(next);
    const newMap: Record<string, boolean> = {};
    sourceQuestions.forEach(q => {
      newMap[q.id] = next;
    });
    setExpandedMap(newMap);
  };

  const handleLaunchTest = () => {
    sounds.playCorrect();
    if (questionMode === 'same') {
      const exactPracticeQuiz: Quiz = {
        ...quiz,
        title: quiz.title.includes('(Exact Practice)') ? quiz.title : `${quiz.title} (Practice)`,
        questions: sourceQuestions,
      };
      onStartTest(exactPracticeQuiz);
    } else {
      onStartTest(quiz);
    }
  };

  const handleDelete = () => {
    if (onDeleteQuiz) {
      sounds.playClick();
      onDeleteQuiz(quiz.id);
      setShowConfirmDelete(false);
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 animate-fadeIn">
      
      <div className="relative w-full max-w-5xl h-[92vh] max-h-[950px] bg-slate-900 border border-white/15 rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        
        {/* COMPACT TOP HEADER - Single Clean Row */}
        <div className="px-5 sm:px-7 py-4 bg-slate-950/90 border-b border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 flex-shrink-0">
          
          {/* Title & Subject Info */}
          <div className="flex items-center space-x-3 min-w-0 flex-1">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/15 border border-amber-400/30 flex items-center justify-center text-amber-300 flex-shrink-0">
              <BookOpen className="w-5 h-5" />
            </div>
            
            <div className="min-w-0">
              <div className="flex items-center space-x-2 flex-wrap gap-y-0.5">
                <h2 className="text-base sm:text-lg font-bold text-white truncate">
                  {quiz.title}
                </h2>
                <span className="px-2 py-0.5 rounded-md bg-white/10 text-slate-300 text-[11px] font-medium">
                  {quiz.subject}
                </span>
                {quiz.gradeLevel && (
                  <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[11px] font-medium border border-indigo-400/20">
                    {quiz.gradeLevel}
                  </span>
                )}
                <span className="px-2 py-0.5 rounded-md bg-amber-400/10 text-amber-300 text-[11px] font-bold border border-amber-400/20">
                  {sourceQuestions.length} Study Questions
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate mt-0.5">
                Read the questions, answers, and step-by-step explanations below before taking the test.
              </p>
            </div>
          </div>

          {/* Right Header Action Buttons */}
          <div className="flex items-center space-x-2.5 flex-shrink-0 self-end sm:self-center">
            
            {/* Simple Question Mode Select */}
            <select
              value={questionMode}
              onChange={(e) => {
                sounds.playClick();
                setQuestionMode(e.target.value as 'same' | 'different');
              }}
              className="px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/15 rounded-xl text-xs font-semibold text-slate-200 focus:outline-none focus:border-amber-400 transition-colors"
              title="Select test question format"
            >
              <option value="same" className="bg-slate-900 text-white">
                Test Mode: Same Questions ({studyQuestionsCount} Qs)
              </option>
              <option value="different" className="bg-slate-900 text-white">
                Test Mode: New Challenge ({testQuestionsCount} Qs)
              </option>
            </select>

            {/* Start Practice Test Primary Button */}
            <button
              id="btn-modal-start-test"
              onClick={handleLaunchTest}
              className="px-4 sm:px-5 py-2 sm:py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs sm:text-sm rounded-xl shadow-lg shadow-amber-500/20 flex items-center space-x-2 transition-all hover:scale-[1.02] active:scale-[0.98] border border-amber-300"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>Start Practice Test</span>
            </button>

            {/* Trash button */}
            {onDeleteQuiz && (
              <button
                onClick={() => setShowConfirmDelete(true)}
                className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-white/10 transition-colors"
                title="Delete this study test"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            {/* Close X */}
            <button
              id="btn-modal-close"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10 transition-colors"
              title="Close Study Mode"
            >
              <X className="w-4 h-4" />
            </button>

          </div>

        </div>

        {/* Delete Confirmation Alert Banner */}
        {showConfirmDelete && (
          <div className="p-3 bg-rose-950/90 border-b border-rose-500/40 flex flex-wrap items-center justify-between gap-3 text-xs text-rose-200 flex-shrink-0 animate-fadeIn">
            <div className="flex items-center space-x-2">
              <Trash2 className="w-4 h-4 text-rose-400 flex-shrink-0" />
              <span>Delete <strong>"{quiz.title}"</strong> from your saved library?</span>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={() => setShowConfirmDelete(false)}
                className="px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium"
              >
                Cancel
              </button>
              <button
                onClick={handleDelete}
                className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold"
              >
                Delete
              </button>
            </div>
          </div>
        )}

        {/* SLIM SUB-HEADER: Search & Expand All (Takes minimal space) */}
        <div className="px-5 sm:px-7 py-2.5 bg-white/[0.02] border-b border-white/10 flex items-center justify-between gap-3 text-xs flex-shrink-0">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search study questions or keywords..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-400"
            />
          </div>

          <div className="flex items-center space-x-3 text-slate-400">
            <span className="hidden sm:inline text-xs">
              Showing {filteredQuestions.length} of {sourceQuestions.length} questions
            </span>
            <button
              onClick={toggleAll}
              className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-slate-300 rounded-lg border border-white/10 text-[11px] font-medium transition-colors"
            >
              {allExpanded ? 'Collapse Explanations' : 'Expand Explanations'}
            </button>
          </div>
        </div>

        {/* MAIN SCROLLABLE STUDY CONTENT - Fills 85%+ of the Screen */}
        <div className="p-4 sm:p-6 md:p-8 overflow-y-auto space-y-5 custom-scrollbar flex-1 bg-slate-950/30">
          
          {filteredQuestions.length === 0 ? (
            <div className="text-center py-16 text-slate-400">
              <BookOpen className="w-10 h-10 mx-auto mb-2 text-slate-600" />
              <p className="font-semibold text-white">No study questions found matching your search</p>
              <button
                onClick={() => setSearchQuery('')}
                className="mt-2 text-xs text-amber-300 hover:underline"
              >
                Clear search
              </button>
            </div>
          ) : (
            filteredQuestions.map((q, idx) => {
              const isExpanded = expandedMap[q.id] ?? allExpanded;

              return (
                <div
                  key={q.id}
                  className="p-5 sm:p-6 rounded-2xl bg-slate-900/90 border border-white/15 shadow-md space-y-4 hover:border-amber-400/30 transition-all"
                >
                  
                  {/* Question Header & Badges */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center space-x-2 text-xs flex-wrap gap-y-1">
                        <span className="px-2.5 py-0.5 rounded-md bg-amber-400/15 text-amber-300 font-bold border border-amber-400/30 text-xs">
                          Question {idx + 1}
                        </span>
                        <span className="px-2 py-0.5 rounded bg-white/10 text-slate-300 text-[11px] font-semibold capitalize">
                          {q.type.replace('_', ' ')}
                        </span>
                        {q.topicTag && (
                          <span className="text-indigo-300 font-medium text-[11px] flex items-center space-x-1 px-2 py-0.5 rounded bg-indigo-500/15 border border-indigo-400/20">
                            <Tag className="w-3 h-3 text-indigo-400" />
                            <span>{q.topicTag}</span>
                          </span>
                        )}
                        <span className="text-slate-400 text-[11px] flex items-center space-x-1">
                          <Clock className="w-3 h-3" />
                          <span>{q.timeLimitSeconds || 45}s</span>
                        </span>
                      </div>

                      {/* Question Text */}
                      <h3 className="text-base sm:text-lg font-bold text-white leading-snug pt-1">
                        {q.question}
                      </h3>
                    </div>
                  </div>

                  {/* Options List for Multiple Choice */}
                  {q.type === 'multiple_choice' && q.options && q.options.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                      {q.options.map((opt, oIdx) => {
                        const isCorrect = opt.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase() ||
                          opt.startsWith(q.correctAnswer) || q.correctAnswer.startsWith(opt);
                        const letter = String.fromCharCode(65 + oIdx);

                        return (
                          <div
                            key={oIdx}
                            className={`p-3 rounded-xl border text-xs sm:text-sm flex items-start space-x-2.5 transition-all ${
                              isCorrect
                                ? 'bg-emerald-500/20 border-emerald-400/60 text-emerald-100 font-bold ring-1 ring-emerald-400/30 shadow-sm'
                                : 'bg-white/5 border-white/10 text-slate-300'
                            }`}
                          >
                            <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[11px] flex-shrink-0 ${
                              isCorrect ? 'bg-emerald-400 text-slate-950 font-black' : 'bg-white/10 text-slate-400'
                            }`}>
                              {letter}
                            </span>
                            <span className="flex-1 leading-snug">{opt}</span>
                            {isCorrect && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-400 text-slate-950 text-[10px] font-black uppercase flex items-center space-x-1 flex-shrink-0">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Correct</span>
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Options List for True/False */}
                  {q.type === 'true_false' && (
                    <div className="grid grid-cols-2 gap-3 pt-1">
                      {['True', 'False'].map((opt) => {
                        const isCorrect = opt.toLowerCase() === q.correctAnswer.toLowerCase();
                        return (
                          <div
                            key={opt}
                            className={`p-3 rounded-xl border text-xs sm:text-sm font-bold flex items-center justify-center space-x-2 transition-all ${
                              isCorrect
                                ? 'bg-emerald-500/20 border-emerald-400/60 text-emerald-100 ring-1 ring-emerald-400/30'
                                : 'bg-white/5 border-white/10 text-slate-400'
                            }`}
                          >
                            <span>{opt}</span>
                            {isCorrect && (
                              <span className="px-1.5 py-0.5 rounded bg-emerald-400 text-slate-950 text-[10px] font-black uppercase flex items-center space-x-1">
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Correct Answer</span>
                              </span>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Short Answer Direct Highlight */}
                  {q.type === 'short_answer' && (
                    <div className="p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-400/40 flex items-center justify-between gap-2">
                      <div className="space-y-0.5">
                        <span className="text-[11px] font-bold text-emerald-300 uppercase tracking-wider flex items-center space-x-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Correct Answer:</span>
                        </span>
                        <p className="text-sm sm:text-base font-black text-white pl-4">
                          {q.correctAnswer}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Explanation & Steps (Clean & Easy to Read) */}
                  <div className="border-t border-white/10 pt-3">
                    <button
                      type="button"
                      onClick={() => toggleQuestionExpand(q.id)}
                      className="flex items-center justify-between w-full text-left text-xs font-bold text-indigo-300 hover:text-indigo-200 transition-colors py-0.5"
                    >
                      <div className="flex items-center space-x-2">
                        <Lightbulb className="w-4 h-4 text-amber-400" />
                        <span>Why this answer is correct & step-by-step explanation:</span>
                      </div>
                      <div className="text-slate-400">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="mt-2.5 p-4 rounded-xl bg-white/5 border border-white/10 space-y-2.5 text-xs sm:text-sm text-slate-200 leading-relaxed animate-fadeIn">
                        <p className="whitespace-pre-line text-slate-200">
                          {q.explanation}
                        </p>
                        
                        {q.hint && (
                          <div className="pt-2 border-t border-white/10 flex items-start space-x-2 text-amber-300 text-xs">
                            <Sparkles className="w-3.5 h-3.5 text-amber-400 flex-shrink-0 mt-0.5" />
                            <p><strong>Memory Hook / Exam Tip:</strong> {q.hint}</p>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                </div>
              );
            })
          )}

          {/* End of Study Guide Callout & Action */}
          {filteredQuestions.length > 0 && (
            <div className="p-6 rounded-2xl bg-gradient-to-r from-amber-400/10 via-indigo-500/10 to-purple-500/10 border border-amber-400/30 text-center space-y-3 mt-8">
              <h3 className="text-base font-bold text-white">
                🎉 Ready to test your knowledge?
              </h3>
              <p className="text-xs text-slate-300 max-w-md mx-auto">
                You’ve reviewed the study concepts and answers. Take the test now to see how high you can score!
              </p>
              <div>
                <button
                  onClick={handleLaunchTest}
                  className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-sm rounded-xl shadow-xl shadow-amber-500/25 inline-flex items-center space-x-2 transition-all hover:scale-105 active:scale-95 border border-amber-300"
                >
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>Start Practice Test Now</span>
                </button>
              </div>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
