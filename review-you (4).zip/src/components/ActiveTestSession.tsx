import React, { useState, useEffect, useRef } from 'react';
import { 
  Timer, 
  Clock, 
  HelpCircle, 
  Flag, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle, 
  AlertCircle, 
  Sparkles, 
  X, 
  Pause, 
  Play,
  RotateCcw,
  Zap,
  Send,
  Eye,
  Check
} from 'lucide-react';
import { Quiz, QuizQuestion, QuestionResult } from '../types';
import { sounds } from '../lib/sound';
import { safeFetchJson } from '../lib/api';
import { evaluateShortAnswer } from '../lib/grading';

interface ActiveTestSessionProps {
  quiz: Quiz;
  onCompleteTest: (
    results: QuestionResult[], 
    totalDurationSeconds: number, 
    correctCount: number, 
    scorePercentage: number
  ) => void;
  onExitTest: () => void;
}

export const ActiveTestSession: React.FC<ActiveTestSessionProps> = ({
  quiz,
  onCompleteTest,
  onExitTest,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [questionTimes, setQuestionTimes] = useState<Record<string, number>>({});
  const [flaggedQuestions, setFlaggedQuestions] = useState<Record<string, boolean>>({});
  const [isPaused, setIsPaused] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [totalSecondsElapsed, setTotalSecondsElapsed] = useState(0);

  // Short answer live grading state
  const [isGradingShortAnswer, setIsGradingShortAnswer] = useState(false);
  const [shortAnswerFeedback, setShortAnswerFeedback] = useState<Record<string, {
    score: number;
    isCorrect: boolean;
    feedback: string;
    keyPointsIncluded: string[];
    keyPointsMissed: string[];
    idealSummary: string;
  }>>({});

  // Safe questions list fallback
  const rawQuestions = (quiz?.questions && quiz.questions.length > 0) 
    ? quiz.questions 
    : ((quiz?.studyQuestions && quiz.studyQuestions.length > 0) ? quiz.studyQuestions : []);

  const currentQuestion: QuizQuestion | undefined = rawQuestions[currentIndex] || rawQuestions[0];
  const timeLimit = currentQuestion?.timeLimitSeconds || 45;

  // Track time per question
  const currentQuestionTimeRef = useRef<number>(0);
  const timerIntervalRef = useRef<any>(null);

  // Per-question countdown remaining
  const [timeRemaining, setTimeRemaining] = useState(timeLimit);

  // Initialize/Reset timer when question changes
  useEffect(() => {
    if (!currentQuestion) return;
    setShowHint(false);
    const existingTimeSpent = questionTimes[currentQuestion.id] || 0;
    currentQuestionTimeRef.current = existingTimeSpent;
    const initialRemaining = Math.max(timeLimit - existingTimeSpent, 0);
    setTimeRemaining(initialRemaining);
  }, [currentIndex, currentQuestion?.id, timeLimit]);

  // Main Timer Tick
  useEffect(() => {
    if (isPaused || !currentQuestion) {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
      return;
    }

    timerIntervalRef.current = setInterval(() => {
      setTotalSecondsElapsed(prev => prev + 1);
      currentQuestionTimeRef.current += 1;

      // Update question times record
      setQuestionTimes(prev => ({
        ...prev,
        [currentQuestion.id]: currentQuestionTimeRef.current,
      }));

      setTimeRemaining(prev => {
        const next = prev - 1;
        // Audio tick when <= 5 seconds
        if (next <= 5 && next > 0) {
          sounds.playTimerTick();
        }
        return next;
      });
    }, 1000);

    return () => {
      if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
    };
  }, [isPaused, currentQuestion?.id]);

  // Keyboard shortcut listener for A, B, C, D or 1, 2, 3, 4
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isPaused || showConfirmModal) return;
      if (currentQuestion.type === 'short_answer') return; // Don't intercept typing

      const key = e.key.toUpperCase();
      if (['1', '2', '3', '4'].includes(key)) {
        const idx = parseInt(key, 10) - 1;
        if (currentQuestion.options && currentQuestion.options[idx]) {
          handleSelectOption(currentQuestion.options[idx]);
        }
      } else if (['A', 'B', 'C', 'D'].includes(key)) {
        const charMap: Record<string, number> = { A: 0, B: 1, C: 2, D: 3 };
        const idx = charMap[key];
        if (currentQuestion.options && currentQuestion.options[idx]) {
          handleSelectOption(currentQuestion.options[idx]);
        }
      } else if (e.key === 'ArrowRight' || e.key === 'Enter') {
        if (currentIndex < quiz.questions.length - 1) {
          handleNextQuestion();
        }
      } else if (e.key === 'ArrowLeft') {
        if (currentIndex > 0) {
          handlePrevQuestion();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex, currentQuestion, isPaused, showConfirmModal]);

  const handleSelectOption = (opt: string) => {
    sounds.playClick();
    setAnswers(prev => ({
      ...prev,
      [currentQuestion.id]: opt,
    }));
  };

  const handleToggleFlag = () => {
    sounds.playClick();
    setFlaggedQuestions(prev => ({
      ...prev,
      [currentQuestion.id]: !prev[currentQuestion.id],
    }));
  };

  const handleNextQuestion = () => {
    sounds.playClick();
    if (currentIndex < quiz.questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const handlePrevQuestion = () => {
    sounds.playClick();
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const handleGradeShortAnswer = async () => {
    const userAns = answers[currentQuestion.id];
    if (!userAns || !userAns.trim()) return;

    setIsGradingShortAnswer(true);
    sounds.playClick();

    try {
      const data = await safeFetchJson<{
        score: number;
        isCorrect: boolean;
        feedback: string;
        keyPointsIncluded: string[];
        keyPointsMissed: string[];
        idealSummary: string;
      }>('/api/grade-answer', {
        method: 'POST',
        body: JSON.stringify({
          question: currentQuestion.question,
          correctAnswer: currentQuestion.correctAnswer,
          userAnswer: userAns.trim(),
          context: currentQuestion.topicTag,
        }),
      });

      const finalGrade = data || evaluateShortAnswer(userAns.trim(), currentQuestion.correctAnswer);

      setShortAnswerFeedback(prev => ({
        ...prev,
        [currentQuestion.id]: finalGrade,
      }));

      if (finalGrade.isCorrect) {
        sounds.playCorrect();
      } else {
        sounds.playIncorrect();
      }
    } catch (err) {
      console.error('Error grading answer:', err);
      const fallbackGrade = evaluateShortAnswer(userAns.trim(), currentQuestion.correctAnswer);
      setShortAnswerFeedback(prev => ({
        ...prev,
        [currentQuestion.id]: fallbackGrade,
      }));
      if (fallbackGrade.isCorrect) {
        sounds.playCorrect();
      } else {
        sounds.playIncorrect();
      }
    } finally {
      setIsGradingShortAnswer(false);
    }
  };

  const handleSubmitTest = () => {
    sounds.playClick();
    if (rawQuestions.length === 0) {
      onExitTest();
      return;
    }

    // Build Question Results
    let correctCount = 0;
    const results: QuestionResult[] = rawQuestions.map((q) => {
      const userAns = answers[q.id] || '(No Answer)';
      const timeSpent = questionTimes[q.id] || 0;
      let isCorrect = false;

      let feedbackObj = shortAnswerFeedback[q.id];

      if (q.type === 'multiple_choice' || q.type === 'true_false') {
        isCorrect = userAns.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase();
      } else if (q.type === 'short_answer') {
        if (feedbackObj) {
          isCorrect = feedbackObj.isCorrect;
        } else {
          // Precise evaluation: exact numbers, tolerance 0, string similarity
          feedbackObj = evaluateShortAnswer(userAns, q.correctAnswer);
          isCorrect = feedbackObj.isCorrect;
        }
      }

      if (isCorrect) correctCount += 1;

      return {
        questionId: q.id,
        questionText: q.question,
        type: q.type,
        userAnswer: userAns,
        correctAnswer: q.correctAnswer,
        isCorrect,
        timeSpentSeconds: timeSpent,
        explanation: q.explanation,
        topicTag: q.topicTag,
        aiFeedback: feedbackObj?.feedback,
        keyPointsIncluded: feedbackObj?.keyPointsIncluded,
        keyPointsMissed: feedbackObj?.keyPointsMissed,
      };
    });

    const scorePercentage = Math.round((correctCount / rawQuestions.length) * 100);
    onCompleteTest(results, totalSecondsElapsed, correctCount, scorePercentage);
  };

  // Helper formatting for seconds to MM:SS
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  if (!currentQuestion || rawQuestions.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-4">
        <AlertCircle className="w-12 h-12 text-amber-400 mx-auto" />
        <h2 className="text-xl font-bold text-white">No Test Questions Found</h2>
        <p className="text-sm text-slate-300">
          This test session does not contain any questions. Return to the test generator to start a new practice test.
        </p>
        <button
          onClick={onExitTest}
          className="px-6 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl"
        >
          Return to Tests
        </button>
      </div>
    );
  }

  const answeredCount = Object.keys(answers).filter(k => answers[k] && answers[k].trim() !== '').length;
  const isAnswered = !!answers[currentQuestion.id];
  const isFlagged = !!flaggedQuestions[currentQuestion.id];

  // Timer color indicator
  const timerPercentage = Math.max(0, Math.min(100, (timeRemaining / timeLimit) * 100));
  const isTimeLow = timeRemaining <= 10;
  const isTimeExpired = timeRemaining <= 0;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 animate-fadeIn">
      
      {/* Top Test Header Bar */}
      <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-3xl p-4 sm:p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] mb-6 flex flex-wrap items-center justify-between gap-4">
        
        {/* Left: Test Info */}
        <div className="flex items-center space-x-3">
          <button
            onClick={() => {
              if (confirm('Leave this test session? Your current progress will not be saved.')) {
                onExitTest();
              }
            }}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl border border-white/10 backdrop-blur-md transition-colors"
            title="Exit Test"
          >
            <X className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-white text-sm sm:text-base line-clamp-1">{quiz.title}</span>
              <span className="px-2 py-0.5 bg-indigo-500/20 text-indigo-300 rounded-lg text-[11px] font-semibold uppercase border border-indigo-400/30">
                {quiz.subject}
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Question {currentIndex + 1} of {rawQuestions.length} • {answeredCount} answered
            </p>
          </div>
        </div>

        {/* Right: Timers & Controls */}
        <div className="flex items-center space-x-4">
          
          {/* Pause / Resume */}
          <button
            onClick={() => { sounds.playClick(); setIsPaused(!isPaused); }}
            className={`p-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition-all backdrop-blur-md border ${
              isPaused 
                ? 'bg-amber-500/30 text-amber-200 border-amber-400/50 shadow-md' 
                : 'bg-white/10 text-slate-200 border-white/15 hover:bg-white/15'
            }`}
            title={isPaused ? 'Resume Test' : 'Pause Test'}
          >
            {isPaused ? <Play className="w-4 h-4 fill-current text-amber-300" /> : <Pause className="w-4 h-4" />}
            <span className="hidden sm:inline">{isPaused ? 'Resume' : 'Pause'}</span>
          </button>

          {/* Question Countdown Timer */}
          <div className={`flex items-center space-x-2 px-3 py-1.5 rounded-2xl border transition-all backdrop-blur-md ${
            isTimeExpired
              ? 'bg-rose-500/30 border-rose-400 text-rose-200 animate-bounce'
              : isTimeLow
              ? 'bg-rose-500/20 border-rose-400/40 text-rose-300 animate-pulse'
              : 'bg-white/10 border-white/15 text-slate-200'
          }`}>
            <Clock className={`w-4 h-4 ${isTimeLow ? 'text-rose-400' : 'text-indigo-400'}`} />
            <div>
              <p className="text-[9px] uppercase font-bold text-slate-400 leading-none">Question Pace</p>
              <p className="text-sm font-extrabold font-mono text-white leading-tight">
                {timeRemaining > 0 ? formatTime(timeRemaining) : 'Overtime'}
              </p>
            </div>
          </div>

          {/* Total Test Duration */}
          <div className="hidden sm:flex items-center space-x-2 px-3 py-1.5 bg-white/10 border border-white/15 rounded-2xl text-slate-300 backdrop-blur-md">
            <Timer className="w-4 h-4 text-indigo-400" />
            <div>
              <p className="text-[9px] uppercase font-bold text-slate-400 leading-none">Total Time</p>
              <p className="text-sm font-bold font-mono text-white leading-tight">
                {formatTime(totalSecondsElapsed)}
              </p>
            </div>
          </div>

        </div>

      </div>

      {/* Question Progress Bar */}
      <div className="w-full bg-white/10 border border-white/10 h-2 rounded-full overflow-hidden mb-6 backdrop-blur-md">
        <div 
          className="bg-gradient-to-r from-indigo-500 to-purple-600 h-full transition-all duration-300 rounded-full shadow-lg"
          style={{ width: `${((currentIndex + 1) / rawQuestions.length) * 100}%` }}
        />
      </div>

      {/* Main Question Card */}
      {isPaused ? (
        <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-3xl p-12 text-center shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
          <Pause className="w-12 h-12 text-amber-400 mx-auto mb-3" />
          <h2 className="text-xl font-bold text-white mb-2">Test is Paused</h2>
          <p className="text-sm text-slate-300 max-w-md mx-auto mb-6">
            Take a breath! When you are ready to focus and resume timed answering, click Resume.
          </p>
          <button
            onClick={() => { sounds.playClick(); setIsPaused(false); }}
            className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white font-semibold rounded-2xl text-sm shadow-xl border border-white/20"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>Resume Test</span>
          </button>
        </div>
      ) : (
        <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6">
          
          {/* Question Sub-header & Flags */}
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <div className="flex items-center space-x-2">
              <span className="px-2.5 py-1 bg-indigo-500/20 text-indigo-300 rounded-xl text-xs font-bold uppercase tracking-wider border border-indigo-400/30 backdrop-blur-md">
                Question {currentIndex + 1}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                • {currentQuestion.topicTag || quiz.subject}
              </span>
            </div>

            <div className="flex items-center space-x-3">
              {currentQuestion.hint && (
                <button
                  onClick={() => { sounds.playClick(); setShowHint(!showHint); }}
                  className={`text-xs font-semibold px-2.5 py-1 rounded-xl border transition-all flex items-center space-x-1 backdrop-blur-md ${
                    showHint 
                      ? 'bg-amber-500/25 text-amber-200 border-amber-400/40' 
                      : 'text-slate-300 border-white/15 hover:bg-white/10'
                  }`}
                >
                  <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>{showHint ? 'Hide Hint' : 'Need Hint?'}</span>
                </button>
              )}

              <button
                onClick={handleToggleFlag}
                className={`text-xs font-semibold px-2.5 py-1 rounded-xl border transition-all flex items-center space-x-1 backdrop-blur-md ${
                  isFlagged 
                    ? 'bg-amber-500/30 text-amber-200 border-amber-400/50 font-bold' 
                    : 'text-slate-400 border-white/15 hover:text-white hover:bg-white/10'
                }`}
                title="Flag to review before submitting"
              >
                <Flag className={`w-3.5 h-3.5 ${isFlagged ? 'fill-amber-400 text-amber-400' : ''}`} />
                <span>{isFlagged ? 'Flagged' : 'Flag'}</span>
              </button>
            </div>
          </div>

          {/* Hint Accordion */}
          {showHint && currentQuestion.hint && (
            <div className="p-4 bg-amber-500/15 border border-amber-400/30 rounded-2xl text-xs text-amber-200 flex items-start space-x-2.5 backdrop-blur-md animate-fadeIn">
              <HelpCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-bold">Study Hint:</p>
                <p className="text-amber-100 leading-relaxed mt-0.5">{currentQuestion.hint}</p>
              </div>
            </div>
          )}

          {/* The Prompt Text */}
          <div>
            <h2 className="text-lg sm:text-2xl font-bold text-white leading-snug">
              {currentQuestion.question}
            </h2>
          </div>

          {/* Answer Inputs Based on Question Type */}
          {currentQuestion.type === 'multiple_choice' || currentQuestion.type === 'true_false' ? (
            <div className="space-y-3 pt-2">
              {(currentQuestion.options || ['True', 'False']).map((option, optIdx) => {
                const isSelected = answers[currentQuestion.id] === option;
                const letter = ['A', 'B', 'C', 'D'][optIdx] || `${optIdx + 1}`;

                return (
                  <button
                    key={optIdx}
                    onClick={() => handleSelectOption(option)}
                    className={`w-full text-left p-4 rounded-2xl border text-sm font-medium transition-all flex items-center justify-between group backdrop-blur-md ${
                      isSelected
                        ? 'bg-indigo-500/30 border-indigo-400 text-white shadow-lg ring-1 ring-indigo-400'
                        : 'bg-white/5 border-white/15 hover:bg-white/10 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center space-x-3.5">
                      <div className={`w-7 h-7 rounded-xl flex items-center justify-center text-xs font-bold transition-colors ${
                        isSelected
                          ? 'bg-gradient-to-r from-indigo-500 to-purple-600 text-white border border-white/30'
                          : 'bg-white/10 border border-white/20 text-slate-300 group-hover:border-white/40'
                      }`}>
                        {letter}
                      </div>
                      <span className="leading-relaxed">{option}</span>
                    </div>
                    {isSelected && (
                      <Check className="w-5 h-5 text-indigo-300 flex-shrink-0 ml-2" />
                    )}
                  </button>
                );
              })}
            </div>
          ) : (
            /* Short Answer / Open-Ended */
            <div className="space-y-4 pt-2">
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Type your answer (Exact numerical accuracy for math; conceptual similarity for explanations):
              </label>
              <textarea
                rows={3}
                value={answers[currentQuestion.id] || ''}
                onChange={(e) => {
                  setAnswers(prev => ({ ...prev, [currentQuestion.id]: e.target.value }));
                }}
                placeholder="Enter your exact number (e.g. 16) or explain the concept in your own words..."
                className="w-full p-4 bg-white/5 border border-white/15 rounded-2xl text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 focus:bg-white/10 backdrop-blur-md transition-all placeholder:text-slate-500"
              />

              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={handleGradeShortAnswer}
                  disabled={isGradingShortAnswer || !answers[currentQuestion.id]?.trim()}
                  className="inline-flex items-center space-x-1.5 px-3.5 py-2 bg-indigo-500/20 hover:bg-indigo-500/30 disabled:opacity-50 text-indigo-300 text-xs font-semibold rounded-xl border border-indigo-400/30 backdrop-blur-md transition-colors"
                >
                  {isGradingShortAnswer ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-indigo-400 border-t-transparent rounded-full animate-spin" />
                      <span>AI Evaluating...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Check Answer with AI</span>
                    </>
                  )}
                </button>
                <span className="text-[11px] text-slate-400">Your answer is scored automatically upon test submission.</span>
              </div>

              {/* Live AI Grade Feedback for Short Answer */}
              {shortAnswerFeedback[currentQuestion.id] && (
                <div className={`p-4 rounded-2xl border text-xs space-y-2.5 backdrop-blur-md ${
                  shortAnswerFeedback[currentQuestion.id].isCorrect
                    ? 'bg-emerald-500/20 border-emerald-400/30 text-emerald-200'
                    : 'bg-amber-500/20 border-amber-400/30 text-amber-200'
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="font-bold flex items-center space-x-1.5">
                      {shortAnswerFeedback[currentQuestion.id].isCorrect ? (
                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <AlertCircle className="w-4 h-4 text-amber-400" />
                      )}
                      <span>
                        AI Evaluation: {shortAnswerFeedback[currentQuestion.id].score}% Score
                      </span>
                    </span>
                    <span className="text-[11px] font-semibold px-2 py-0.5 rounded-lg bg-white/10 border border-white/15">
                      {shortAnswerFeedback[currentQuestion.id].isCorrect ? 'Pass / Correct' : 'Needs Work'}
                    </span>
                  </div>
                  <p className="leading-relaxed text-slate-200">{shortAnswerFeedback[currentQuestion.id].feedback}</p>
                  
                  {shortAnswerFeedback[currentQuestion.id].idealSummary && (
                    <div className="pt-2 border-t border-white/10">
                      <p className="font-semibold text-[11px] uppercase text-slate-300">Model Reference Answer:</p>
                      <p className="italic mt-0.5 text-slate-200">{shortAnswerFeedback[currentQuestion.id].idealSummary}</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-6 border-t border-white/10">
            <button
              onClick={handlePrevQuestion}
              disabled={currentIndex === 0}
              className="inline-flex items-center space-x-1.5 px-4 py-2.5 bg-white/10 hover:bg-white/15 disabled:opacity-30 text-slate-200 text-xs font-semibold rounded-2xl border border-white/10 backdrop-blur-md transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <div className="text-xs text-slate-400 hidden sm:block">
              {currentIndex + 1} / {quiz.questions.length}
            </div>

            {currentIndex === quiz.questions.length - 1 ? (
              <button
                onClick={() => { sounds.playClick(); setShowConfirmModal(true); }}
                className="inline-flex items-center space-x-2 px-6 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs font-bold rounded-2xl shadow-xl border border-white/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Submit & View Diagnostic</span>
              </button>
            ) : (
              <button
                onClick={handleNextQuestion}
                className="inline-flex items-center space-x-1.5 px-5 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white text-xs font-semibold rounded-2xl shadow-lg border border-white/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <span>Next</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>

        </div>
      )}

      {/* Question Jump Grid Palette */}
      <div className="mt-6 bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-3xl p-4 sm:p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)]">
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-bold uppercase tracking-wider text-white">Question Navigator</p>
          <div className="flex items-center space-x-3 text-[11px] text-slate-300">
            <span className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-indigo-400 inline-block" />
              <span>Answered</span>
            </span>
            <span className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
              <span>Flagged</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
          {rawQuestions.map((q, idx) => {
            const hasAns = !!answers[q.id];
            const isFlg = !!flaggedQuestions[q.id];
            const isCur = idx === currentIndex;

            return (
              <button
                key={q.id}
                onClick={() => { sounds.playClick(); setCurrentIndex(idx); }}
                className={`py-2 text-xs font-bold rounded-xl border relative transition-all backdrop-blur-md ${
                  isCur
                    ? 'ring-2 ring-indigo-400 bg-gradient-to-r from-indigo-500 to-purple-600 text-white border-white/30 shadow-md'
                    : hasAns
                    ? 'bg-indigo-500/20 border-indigo-400/30 text-indigo-200'
                    : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10'
                }`}
              >
                <span>{idx + 1}</span>
                {isFlg && (
                  <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-amber-400 ring-2 ring-slate-900" />
                )}
              </button>
            );
          })}
        </div>

        <div className="mt-4 pt-3 border-t border-white/10 flex justify-end">
          <button
            onClick={() => { sounds.playClick(); setShowConfirmModal(true); }}
            className="text-xs text-indigo-300 hover:text-white font-semibold flex items-center space-x-1"
          >
            <span>Finish & Submit Test Early</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900/90 border border-white/20 rounded-3xl max-w-md w-full p-6 shadow-2xl backdrop-blur-2xl space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="font-bold text-white text-base flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-indigo-400" />
                <span>Ready to Submit Test?</span>
              </h3>
              <button
                onClick={() => setShowConfirmModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              You have answered <strong>{answeredCount}</strong> of <strong>{rawQuestions.length}</strong> questions in <strong>{formatTime(totalSecondsElapsed)}</strong>.
            </p>

            {answeredCount < rawQuestions.length && (
              <div className="p-3 bg-amber-500/20 border border-amber-400/30 rounded-2xl text-xs text-amber-200 flex items-start space-x-2 backdrop-blur-md">
                <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <span>You have <strong>{rawQuestions.length - answeredCount}</strong> unanswered questions remaining.</span>
              </div>
            )}

            {Object.values(flaggedQuestions).filter(Boolean).length > 0 && (
              <div className="p-3 bg-amber-500/20 border border-amber-400/30 rounded-2xl text-xs text-amber-200 flex items-start space-x-2 backdrop-blur-md">
                <Flag className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <span>You have flagged questions marked for review.</span>
              </div>
            )}

            <div className="flex items-center justify-end space-x-3 pt-3">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="px-4 py-2 bg-white/10 hover:bg-white/15 text-slate-200 text-xs font-semibold rounded-xl border border-white/10 transition-colors"
              >
                Keep Testing
              </button>
              <button
                onClick={() => {
                  setShowConfirmModal(false);
                  handleSubmitTest();
                }}
                className="px-5 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white text-xs font-bold rounded-xl shadow-lg border border-white/20 transition-all"
              >
                Yes, Submit Test
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
