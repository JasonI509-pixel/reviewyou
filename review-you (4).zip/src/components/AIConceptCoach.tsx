import React, { useState } from 'react';
import { 
  HelpCircle, 
  Sparkles, 
  BrainCircuit, 
  Lightbulb, 
  ShieldAlert, 
  BookmarkCheck, 
  BookOpen, 
  Check, 
  CheckCircle2, 
  XCircle, 
  ArrowRight,
  Zap,
  Send
} from 'lucide-react';
import { ConceptExplanation, NotebookEntry } from '../types';
import { sounds } from '../lib/sound';
import { safeFetchJson } from '../lib/api';

interface AIConceptCoachProps {
  initialPrompt?: string;
  onSaveToNotebook: (note: { title: string; content: string; tags: string[]; subject: string }) => void;
  onStartQuizWithTopic: (topic: string) => void;
}

export const AIConceptCoach: React.FC<AIConceptCoachProps> = ({
  initialPrompt = '',
  onSaveToNotebook,
  onStartQuizWithTopic,
}) => {
  const [conceptInput, setConceptInput] = useState(initialPrompt);
  const [tone, setTone] = useState<'clear' | 'analogy_heavy' | 'exam_oriented' | 'simple'>('clear');
  const [isExplaining, setIsExplaining] = useState(false);
  const [explanation, setExplanation] = useState<ConceptExplanation | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  // Interactive check questions answers state
  const [userCheckAnswers, setUserCheckAnswers] = useState<Record<number, string>>({});
  const [savedNote, setSavedNote] = useState(false);

  const handleExplain = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!conceptInput.trim()) return;

    setIsExplaining(true);
    setErrorMsg(null);
    setSavedNote(false);
    setUserCheckAnswers({});
    sounds.playClick();

    try {
      const data = await safeFetchJson<{ explanation: ConceptExplanation }>('/api/explain-concept', {
        method: 'POST',
        body: JSON.stringify({
          concept: conceptInput.trim(),
          tone,
        }),
      });

      if (data && data.explanation) {
        setExplanation(data.explanation);
        sounds.playCorrect();
      } else {
        throw new Error('Invalid explanation structure received');
      }
    } catch (err: any) {
      console.error('Explain concept error:', err);
      setErrorMsg(err.message || 'Could not explain concept. Please check your connection and try again.');
      sounds.playIncorrect();
    } finally {
      setIsExplaining(false);
    }
  };

  const handleSelectCheckOption = (qIdx: number, opt: string) => {
    sounds.playClick();
    setUserCheckAnswers(prev => ({
      ...prev,
      [qIdx]: opt,
    }));
  };

  const handleSaveToNotebook = () => {
    if (!explanation) return;
    sounds.playClick();

    const markdown = `# ${explanation.title} - AI Study Guide

## Core Summary
${explanation.summary}

## In-Depth Breakdown
${explanation.detailedExplanation}

## Mental Model & Analogy
${explanation.realWorldAnalogy}

## Common Exam Traps to Avoid
${explanation.examTrapToAvoid}

## Mnemonic Hook
> **${explanation.mnemonic}**
`;

    onSaveToNotebook({
      title: `${explanation.title} (Clarified)`,
      content: markdown,
      tags: ['AI Coach', 'Clarification'],
      subject: 'Study Prep',
    });

    setSavedNote(true);
    sounds.playCorrect();
  };

  const QUICK_QUESTIONS = [
    'How do you multiply and divide fractions with mixed numbers?',
    'Why do we have 4 seasons on Earth and what causes them?',
    'What is the difference between Mitosis and Meiosis?',
    'How does photosynthesis turn sunlight and water into glucose?',
    'How does the Federal Reserve use interest rates to fight inflation?',
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white flex items-center space-x-2.5 drop-shadow-sm">
            <HelpCircle className="w-7 h-7 text-indigo-400" />
            <span>AI Review Coach & Concept Clarifier</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Never stay confused. Get crystal-clear explanations, mnemonics, exam traps, and instant practice questions.
          </p>
        </div>
      </div>

      {/* Input Box */}
      <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-2xl p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-5 text-white">
        <form onSubmit={handleExplain} className="space-y-4">
          <label className="block text-sm font-bold text-white">
            What concept, test topic, or quiz question are you confused about?
          </label>
          <div className="relative">
            <textarea
              rows={3}
              value={conceptInput}
              onChange={(e) => setConceptInput(e.target.value)}
              placeholder="e.g. Why does cellular respiration switch to lactic acid fermentation? How does Marbury v Madison establish judicial review? How does Dijkstra's algorithm handle negative weights?"
              className="w-full px-4 py-3 bg-white/10 border border-white/15 rounded-xl text-white placeholder-slate-400 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 backdrop-blur-md"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
            
            {/* Tone Selector */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-semibold text-slate-300">Style:</span>
              {[
                { id: 'clear', label: 'Crystal Clear' },
                { id: 'analogy_heavy', label: 'Analogies & Visuals' },
                { id: 'exam_oriented', label: 'Exam Traps & High-Yield' },
                { id: 'simple', label: 'ELI5 (Simplified)' },
              ].map(t => (
                <button
                  type="button"
                  key={t.id}
                  onClick={() => { sounds.playClick(); setTone(t.id as any); }}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
                    tone === t.id
                      ? 'bg-indigo-500/30 text-white border-indigo-400/50 shadow-md backdrop-blur-md'
                      : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/15'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isExplaining || !conceptInput.trim()}
              className="inline-flex items-center space-x-2 px-6 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl shadow-lg border border-white/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              {isExplaining ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Coach is Analyzing...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Explain Concept</span>
                </>
              )}
            </button>

          </div>
        </form>

        {/* Quick Question Prompts */}
        <div className="pt-4 border-t border-white/10">
          <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2">Try a common tricky question:</p>
          <div className="flex flex-wrap gap-2">
            {QUICK_QUESTIONS.map((q, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setConceptInput(q);
                  sounds.playClick();
                }}
                className="text-[11px] text-slate-300 bg-white/5 hover:bg-white/15 hover:text-white border border-white/10 rounded-lg px-2.5 py-1 text-left backdrop-blur-md transition-all"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* Error display */}
      {errorMsg && (
        <div className="p-4 bg-rose-500/20 border border-rose-400/30 rounded-xl text-xs text-rose-200 backdrop-blur-md">
          {errorMsg}
        </div>
      )}

      {/* Structured 5-Pillar Concept Breakdown */}
      {explanation && (
        <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-8 animate-fadeIn text-white">
          
          {/* Header & Save Action */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
            <div>
              <span className="px-3 py-1 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 rounded-full text-xs font-bold uppercase tracking-wider backdrop-blur-md">
                Clarified Concept Breakdown
              </span>
              <h2 className="text-xl sm:text-2xl font-bold text-white mt-2 drop-shadow-sm">
                {explanation.title}
              </h2>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleSaveToNotebook}
                disabled={savedNote}
                className={`inline-flex items-center space-x-1.5 px-4 py-2 text-xs font-semibold rounded-xl border transition-all backdrop-blur-md ${
                  savedNote
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30'
                    : 'bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white border-white/15'
                }`}
              >
                {savedNote ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <BookOpen className="w-3.5 h-3.5 text-indigo-300" />}
                <span>{savedNote ? 'Saved to Notebook' : 'Save to Study Notes'}</span>
              </button>

              <button
                onClick={() => {
                  sounds.playClick();
                  onStartQuizWithTopic(explanation.title);
                }}
                className="inline-flex items-center space-x-1.5 px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white text-xs font-bold rounded-xl shadow-lg border border-white/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Test Me on This Now</span>
              </button>
            </div>
          </div>

          {/* 1. Core Summary & Detailed Explanation */}
          <div className="space-y-4">
            <div className="p-4 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
              <p className="text-xs font-bold uppercase tracking-wider text-indigo-300 mb-1">
                Executive Takeaway
              </p>
              <p className="text-sm font-semibold text-slate-100 leading-relaxed">
                {explanation.summary}
              </p>
            </div>

            <div className="text-xs sm:text-sm text-slate-200 leading-relaxed space-y-3">
              {explanation.detailedExplanation.split('\n\n').map((p, i) => (
                <p key={i}>{p}</p>
              ))}
            </div>
          </div>

          {/* 2 & 3. Real World Analogy & Exam Traps Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            
            {/* Real World Analogy */}
            <div className="bg-amber-500/10 border border-amber-400/25 rounded-2xl p-5 space-y-2 backdrop-blur-md">
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center space-x-2">
                <Lightbulb className="w-4 h-4 text-amber-400" />
                <span>Mental Model & Real-World Analogy</span>
              </h3>
              <p className="text-xs text-slate-200 leading-relaxed">
                {explanation.realWorldAnalogy}
              </p>
            </div>

            {/* Exam Traps to Avoid */}
            <div className="bg-rose-500/10 border border-rose-400/25 rounded-2xl p-5 space-y-2 backdrop-blur-md">
              <h3 className="text-xs font-bold uppercase tracking-wider text-rose-300 flex items-center space-x-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <span>Common Test Traps & Distractors</span>
              </h3>
              <p className="text-xs text-slate-200 leading-relaxed">
                {explanation.examTrapToAvoid}
              </p>
            </div>

          </div>

          {/* 4. Mnemonic Hook */}
          {explanation.mnemonic && (
            <div className="p-4 bg-gradient-to-r from-indigo-900/60 to-purple-900/60 border border-indigo-400/30 text-white rounded-2xl flex items-center justify-between backdrop-blur-md">
              <div className="space-y-1">
                <p className="text-[10px] uppercase font-bold text-amber-300">Memory Hook / Mnemonic Formula</p>
                <p className="text-sm font-extrabold tracking-wide text-white">
                  "{explanation.mnemonic}"
                </p>
              </div>
              <BrainCircuit className="w-8 h-8 text-indigo-300/80 flex-shrink-0" />
            </div>
          )}

          {/* 5. Instant Understanding Check Questions */}
          {explanation.checkQuestions && explanation.checkQuestions.length > 0 && (
            <div className="space-y-4 pt-4 border-t border-white/10">
              <div>
                <h3 className="font-bold text-white text-sm sm:text-base flex items-center space-x-2">
                  <BookmarkCheck className="w-4 h-4 text-indigo-400" />
                  <span>Instant Comprehension Check ({explanation.checkQuestions.length} Questions)</span>
                </h3>
                <p className="text-xs text-slate-400">Test if you understood the explanation right now:</p>
              </div>

              <div className="space-y-4">
                {explanation.checkQuestions.map((q, qIdx) => {
                  const userAns = userCheckAnswers[qIdx];
                  const hasAnswered = !!userAns;
                  const isCorrect = hasAnswered && userAns.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase();

                  return (
                    <div key={qIdx} className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-3 backdrop-blur-md">
                      <p className="text-xs sm:text-sm font-bold text-white">
                        {qIdx + 1}. {q.question}
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {q.options.map((opt, optIdx) => {
                          const isSelected = userAns === opt;
                          const isOptCorrect = opt.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase();

                          let btnStyle = 'bg-white/5 border-white/10 text-slate-200 hover:bg-white/15';
                          if (hasAnswered) {
                            if (isOptCorrect) {
                              btnStyle = 'bg-emerald-500/20 border-emerald-400/40 text-emerald-300 font-bold';
                            } else if (isSelected) {
                              btnStyle = 'bg-rose-500/20 border-rose-400/40 text-rose-300';
                            }
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleSelectCheckOption(qIdx, opt)}
                              disabled={hasAnswered}
                              className={`p-3 rounded-xl border text-xs text-left transition-all flex items-center justify-between backdrop-blur-md ${btnStyle}`}
                            >
                              <span>{opt}</span>
                              {hasAnswered && isOptCorrect && (
                                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 ml-1" />
                              )}
                              {hasAnswered && isSelected && !isOptCorrect && (
                                <XCircle className="w-4 h-4 text-rose-400 flex-shrink-0 ml-1" />
                              )}
                            </button>
                          );
                        })}
                      </div>

                      {hasAnswered && (
                        <div className={`p-3 rounded-xl text-xs space-y-1 backdrop-blur-md border ${
                          isCorrect ? 'bg-emerald-500/15 border-emerald-400/30 text-emerald-200' : 'bg-amber-500/15 border-amber-400/30 text-amber-200'
                        }`}>
                          <p className="font-bold">
                            {isCorrect ? '✓ Correct!' : `✗ Not quite. Correct answer: ${q.correctAnswer}`}
                          </p>
                          <p className="text-slate-200">{q.explanation}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
};
