import React from 'react';
import { ThemeColor, THEMES } from '../lib/theme';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  themeColor?: ThemeColor;
  useDynamicColor?: boolean;
  layout?: 'horizontal' | 'stacked';
  className?: string;
}

/**
 * Review You Official Brand Logo
 * Features the signature Tree of Knowledge sprouting from an open book,
 * with classical academic serif typography "REVIEW YOU - SINCE 2026".
 * Fully responsive & dynamically adapts to any chosen workspace theme color.
 */
export const Logo: React.FC<LogoProps> = ({
  size = 'md',
  themeColor = 'gold',
  useDynamicColor = true,
  layout = 'horizontal',
  className = '',
}) => {
  const currentTheme = THEMES[themeColor] || THEMES.gold;
  const primaryColor = useDynamicColor ? currentTheme.colorHex : '#E5C97A';
  const secondaryColor = useDynamicColor ? currentTheme.secondaryHex : '#C9A038';
  const glowColor = useDynamicColor ? currentTheme.glowColor : 'rgba(229, 201, 122, 0.25)';

  // Dimensions based on size and layout
  if (layout === 'stacked') {
    const dimensions = {
      sm: { width: 140, height: 120, iconSize: 70 },
      md: { width: 180, height: 150, iconSize: 90 },
      lg: { width: 230, height: 190, iconSize: 115 },
      xl: { width: 290, height: 240, iconSize: 145 },
    }[size];

    return (
      <div className={`inline-flex flex-col items-center text-center select-none ${className}`}>
        <svg
          width={dimensions.width}
          height={dimensions.height}
          viewBox="0 0 240 200"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="overflow-visible"
          aria-label="Review You - Since 2026"
        >
          <defs>
            <linearGradient id={`stackedTreeGrad_${themeColor}`} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor={primaryColor} />
              <stop offset="100%" stopColor={secondaryColor} />
            </linearGradient>
            <filter id={`stackedGlow_${themeColor}`} x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor={primaryColor} floodOpacity="0.3" />
            </filter>
          </defs>

          {/* Centered Tree & Book Emblem */}
          <g transform="translate(45, 10) scale(0.75)" filter={`url(#stackedGlow_${themeColor})`}>
            {/* Tree Foliage / Canopy */}
            <path
              d="M 100,5 C 95,8 90,14 88,20 C 82,15 72,16 68,22 C 60,20 52,26 50,34 C 42,32 35,38 34,46 C 26,48 22,56 24,64 C 18,68 16,78 20,86 C 14,92 16,102 24,106 C 20,114 26,124 35,125 C 40,126 46,122 50,118 C 54,124 64,126 70,122 C 76,126 86,125 90,119 C 95,124 105,124 110,119 C 114,125 124,126 130,122 C 136,126 146,124 150,118 C 154,122 160,126 165,125 C 174,124 180,114 176,106 C 184,102 186,92 180,86 C 184,78 182,68 176,64 C 178,56 174,48 166,46 C 165,38 158,32 150,34 C 148,26 140,20 132,22 C 128,16 118,15 112,20 C 110,14 105,8 100,5 Z"
              fill={`url(#stackedTreeGrad_${themeColor})`}
              opacity="0.95"
            />

            {/* Detailed Organic Leaf Clusters */}
            <g fill={primaryColor}>
              {/* Top Leaves */}
              <path d="M 100,2 C 104,10 102,18 100,22 C 98,18 96,10 100,2 Z" />
              <path d="M 88,10 C 94,16 93,24 88,28 C 84,23 83,16 88,10 Z" />
              <path d="M 112,10 C 117,16 116,24 112,28 C 107,23 106,16 112,10 Z" />
              <path d="M 76,18 C 82,23 80,31 75,34 C 71,29 70,22 76,18 Z" />
              <path d="M 124,18 C 130,23 128,31 123,34 C 119,29 118,22 124,18 Z" />

              {/* Middle Layer Leaves */}
              <path d="M 60,30 C 67,34 66,43 60,47 C 55,42 54,34 60,30 Z" />
              <path d="M 140,30 C 147,34 146,43 140,47 C 135,42 134,34 140,30 Z" />
              <path d="M 44,46 C 51,49 50,58 44,62 C 39,57 38,50 44,46 Z" />
              <path d="M 156,46 C 163,49 162,58 156,62 C 151,57 150,50 156,46 Z" />
              <path d="M 32,66 C 39,69 38,78 32,82 C 27,77 26,70 32,66 Z" />
              <path d="M 168,66 C 175,69 174,78 168,82 C 163,77 162,70 168,66 Z" />

              {/* Lower Canopy Cluster Details */}
              <path d="M 28,90 C 35,93 34,102 28,105 C 23,100 23,93 28,90 Z" />
              <path d="M 172,90 C 179,93 178,102 172,105 C 167,100 167,93 172,90 Z" />
              <path d="M 42,108 C 49,111 48,119 42,122 C 37,117 37,111 42,108 Z" />
              <path d="M 158,108 C 165,111 164,119 158,122 C 153,117 153,111 158,108 Z" />
            </g>

            {/* Tree Trunk & Spreading Roots */}
            <path
              d="M 97,75 Q 94,100 88,122 Q 85,130 75,136 L 125,136 Q 115,130 112,122 Q 106,100 103,75 Z"
              fill={primaryColor}
            />
            {/* Organic Branching from Trunk */}
            <path
              d="M 96,88 Q 80,75 68,60 Q 75,68 94,82 Z"
              fill={primaryColor}
            />
            <path
              d="M 104,88 Q 120,75 132,60 Q 125,68 106,82 Z"
              fill={primaryColor}
            />
            <path
              d="M 98,72 Q 86,55 78,42 Q 84,52 97,68 Z"
              fill={primaryColor}
            />
            <path
              d="M 102,72 Q 114,55 122,42 Q 116,52 103,68 Z"
              fill={primaryColor}
            />

            {/* Open Book Base */}
            {/* Top Page Layer Curve */}
            <path
              d="M 100,135 Q 60,128 15,142 Q 60,135 100,146 Q 140,135 185,142 Q 140,128 100,135 Z"
              fill={`url(#stackedTreeGrad_${themeColor})`}
            />
            {/* Left Page Body */}
            <path
              d="M 100,146 Q 60,135 15,142 L 18,154 Q 60,146 100,158 Z"
              fill={primaryColor}
              opacity="0.9"
            />
            {/* Right Page Body */}
            <path
              d="M 100,146 Q 140,135 185,142 L 182,154 Q 140,146 100,158 Z"
              fill={primaryColor}
              opacity="0.9"
            />
            {/* Book Spine / Cover Foundation */}
            <path
              d="M 100,158 Q 55,147 10,156 L 8,162 Q 55,152 100,165 Q 145,152 192,162 L 190,156 Q 145,147 100,158 Z"
              fill={secondaryColor}
            />
          </g>

          {/* Typography - REVIEW YOU */}
          <text
            x="120"
            y="156"
            textAnchor="middle"
            fill={primaryColor}
            style={{
              fontFamily: '"Cinzel", "Playfair Display", "Times New Roman", "Georgia", serif',
              fontWeight: 800,
              fontSize: '23px',
              letterSpacing: '0.12em',
            }}
          >
            REVIEW YOU
          </text>

          {/* Typography - SINCE 2026 */}
          <text
            x="120"
            y="180"
            textAnchor="middle"
            fill={secondaryColor}
            style={{
              fontFamily: '"Cinzel", "Playfair Display", "Times New Roman", "Georgia", serif',
              fontWeight: 600,
              fontSize: '11px',
              letterSpacing: '0.38em',
            }}
          >
            SINCE 2026
          </text>
        </svg>
      </div>
    );
  }

  // Horizontal Header Layout (Emblem on Left, Typography on Right)
  const dimensions = {
    sm: { width: 175, height: 42, iconScale: 0.28, fontSize: 16, subSize: 8 },
    md: { width: 225, height: 50, iconScale: 0.34, fontSize: 20, subSize: 9 },
    lg: { width: 285, height: 64, iconScale: 0.44, fontSize: 25, subSize: 11 },
    xl: { width: 345, height: 78, iconScale: 0.54, fontSize: 30, subSize: 13 },
  }[size];

  return (
    <div className={`inline-flex items-center select-none ${className}`}>
      <svg
        width={dimensions.width}
        height={dimensions.height}
        viewBox="0 0 320 72"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="overflow-visible"
        aria-label="Review You - Since 2026"
      >
        <defs>
          <linearGradient id={`horizTreeGrad_${themeColor}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={primaryColor} />
            <stop offset="100%" stopColor={secondaryColor} />
          </linearGradient>
          <filter id={`horizGlow_${themeColor}`} x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="1.5" stdDeviation="2.5" floodColor={primaryColor} floodOpacity="0.3" />
          </filter>
        </defs>

        {/* Tree and Book Emblem on the Left */}
        <g transform="translate(0, -2) scale(0.38)" filter={`url(#horizGlow_${themeColor})`}>
          {/* Tree Canopy */}
          <path
            d="M 100,5 C 95,8 90,14 88,20 C 82,15 72,16 68,22 C 60,20 52,26 50,34 C 42,32 35,38 34,46 C 26,48 22,56 24,64 C 18,68 16,78 20,86 C 14,92 16,102 24,106 C 20,114 26,124 35,125 C 40,126 46,122 50,118 C 54,124 64,126 70,122 C 76,126 86,125 90,119 C 95,124 105,124 110,119 C 114,125 124,126 130,122 C 136,126 146,124 150,118 C 154,122 160,126 165,125 C 174,124 180,114 176,106 C 184,102 186,92 180,86 C 184,78 182,68 176,64 C 178,56 174,48 166,46 C 165,38 158,32 150,34 C 148,26 140,20 132,22 C 128,16 118,15 112,20 C 110,14 105,8 100,5 Z"
            fill={`url(#horizTreeGrad_${themeColor})`}
          />

          {/* Leaf Clusters */}
          <g fill={primaryColor}>
            <path d="M 100,2 C 104,10 102,18 100,22 C 98,18 96,10 100,2 Z" />
            <path d="M 88,10 C 94,16 93,24 88,28 C 84,23 83,16 88,10 Z" />
            <path d="M 112,10 C 117,16 116,24 112,28 C 107,23 106,16 112,10 Z" />
            <path d="M 76,18 C 82,23 80,31 75,34 C 71,29 70,22 76,18 Z" />
            <path d="M 124,18 C 130,23 128,31 123,34 C 119,29 118,22 124,18 Z" />
          </g>

          {/* Trunk */}
          <path
            d="M 97,75 Q 94,100 88,122 Q 85,130 75,136 L 125,136 Q 115,130 112,122 Q 106,100 103,75 Z"
            fill={primaryColor}
          />
          {/* Main Branches */}
          <path d="M 96,88 Q 80,75 68,60 Q 75,68 94,82 Z" fill={primaryColor} />
          <path d="M 104,88 Q 120,75 132,60 Q 125,68 106,82 Z" fill={primaryColor} />

          {/* Open Book Base */}
          <path
            d="M 100,135 Q 60,128 15,142 Q 60,135 100,146 Q 140,135 185,142 Q 140,128 100,135 Z"
            fill={`url(#horizTreeGrad_${themeColor})`}
          />
          <path
            d="M 100,146 Q 60,135 15,142 L 18,154 Q 60,146 100,158 Z"
            fill={primaryColor}
          />
          <path
            d="M 100,146 Q 140,135 185,142 L 182,154 Q 140,146 100,158 Z"
            fill={primaryColor}
          />
          <path
            d="M 100,158 Q 55,147 10,156 L 8,162 Q 55,152 100,165 Q 145,152 192,162 L 190,156 Q 145,147 100,158 Z"
            fill={secondaryColor}
          />
        </g>

        {/* Brand Typography on the Right */}
        <g transform="translate(85, 0)">
          {/* REVIEW YOU Header */}
          <text
            x="0"
            y="40"
            fill={primaryColor}
            style={{
              fontFamily: '"Cinzel", "Playfair Display", "Times New Roman", "Georgia", serif',
              fontWeight: 800,
              fontSize: '26px',
              letterSpacing: '0.08em',
            }}
          >
            REVIEW YOU
          </text>

          {/* SINCE 2026 Subtitle */}
          <text
            x="3"
            y="58"
            fill={secondaryColor}
            style={{
              fontFamily: '"Cinzel", "Playfair Display", "Times New Roman", "Georgia", serif',
              fontWeight: 600,
              fontSize: '11px',
              letterSpacing: '0.34em',
            }}
          >
            SINCE 2026
          </text>
        </g>
      </svg>
    </div>
  );
};
