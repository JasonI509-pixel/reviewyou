import React, { useState } from 'react';
import { 
  BookOpen, 
  Plus, 
  Sparkles, 
  Trash2, 
  Edit3, 
  Save, 
  Zap, 
  Tag, 
  Search, 
  FileText, 
  GraduationCap, 
  Check, 
  Clock, 
  ArrowRight,
  HelpCircle,
  Copy,
  Printer,
  Download,
  Share2
} from 'lucide-react';
import { NotebookEntry, Quiz } from '../types';
import { sounds } from '../lib/sound';
import { DocumentRenderer } from './DocumentRenderer';
import { DeleteConfirmModal } from './DeleteConfirmModal';

interface StudyNotebookProps {
  entries: NotebookEntry[];
  onSaveEntry: (entry: NotebookEntry) => void;
  onDeleteEntry: (id: string) => void;
  onGenerateTestFromNote: (note: NotebookEntry) => void;
  onExplainConcept: (concept: string) => void;
}

export const StudyNotebook: React.FC<StudyNotebookProps> = ({
  entries,
  onSaveEntry,
  onDeleteEntry,
  onGenerateTestFromNote,
  onExplainConcept,
}) => {
  const [selectedEntryId, setSelectedEntryId] = useState<string>(entries[0]?.id || '');
  const [isEditing, setIsEditing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [entryToDeleteId, setEntryToDeleteId] = useState<string | null>(null);

  // Form states for editing / new note
  const [editTitle, setEditTitle] = useState('');
  const [editSubject, setEditSubject] = useState('');
  const [editContent, setEditContent] = useState('');
  const [editTags, setEditTags] = useState('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const activeEntry = entries.find(e => e.id === selectedEntryId) || entries[0];

  // Initialize edit fields when changing note
  const handleSelectEntry = (entry: NotebookEntry) => {
    sounds.playClick();
    setSelectedEntryId(entry.id);
    setIsEditing(false);
    setEditTitle(entry.title);
    setEditSubject(entry.subject);
    setEditContent(entry.content);
    setEditTags((entry.tags || []).join(', '));
  };

  const handleStartNewNote = () => {
    sounds.playClick();
    const newId = `note_${Date.now()}`;
    const newEntry: NotebookEntry = {
      id: newId,
      title: 'New Study Review Note',
      subject: 'General',
      content: `# Study Note Title\n\n## 📌 Key Concepts\n- Point 1: Key definition or formula\n- Point 2: Important mechanism or relationship\n\n## 🎯 Common Exam Questions\n- [ ] 1. What is the primary difference between X and Y?\n- [ ] 2. How does A affect B?`,
      tags: ['Review', 'High-Yield'],
      lastUpdated: new Date().toISOString(),
    };
    onSaveEntry(newEntry);
    setSelectedEntryId(newId);
    setEditTitle(newEntry.title);
    setEditSubject(newEntry.subject);
    setEditContent(newEntry.content);
    setEditTags(newEntry.tags.join(', '));
    setIsEditing(true);
  };

  const handleSaveCurrentEdit = () => {
    sounds.playClick();
    if (!activeEntry) return;

    const tagsArray = editTags
      .split(',')
      .map(t => t.trim())
      .filter(t => t.length > 0);

    const updated: NotebookEntry = {
      ...activeEntry,
      title: editTitle.trim() || 'Untitled Note',
      subject: editSubject.trim() || 'General',
      content: editContent,
      tags: tagsArray,
      lastUpdated: new Date().toISOString(),
    };

    onSaveEntry(updated);
    setIsEditing(false);
    sounds.playCorrect();
  };

  const handleCopyContent = () => {
    if (!activeEntry) return;
    navigator.clipboard.writeText(activeEntry.content);
    setCopiedId(activeEntry.id);
    sounds.playClick();
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleDownloadDoc = () => {
    if (!activeEntry) return;
    sounds.playClick();
    const element = document.createElement('a');
    const file = new Blob([activeEntry.content], { type: 'text/markdown;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `${activeEntry.title.replace(/[^a-zA-Z0-9_-]/g, '_') || 'study_note'}.md`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    sounds.playCorrect();
  };

  const handlePrint = () => {
    sounds.playClick();
    window.print();
  };

  const confirmDelete = () => {
    if (!entryToDeleteId) return;
    sounds.playClick();
    onDeleteEntry(entryToDeleteId);
    setEntryToDeleteId(null);
    setShowDeleteModal(false);
    sounds.playCorrect();

    // Reset selection to another entry if needed
    const remaining = entries.filter(e => e.id !== entryToDeleteId);
    if (remaining.length > 0) {
      setSelectedEntryId(remaining[0].id);
    }
  };

  // Filter notes
  const allSubjects = ['All', ...Array.from(new Set(entries.map(e => e.subject || 'General')))];
  const filteredEntries = entries.filter(e => {
    const matchSub = selectedSubject === 'All' || (e.subject || 'General') === selectedSubject;
    const matchSearch = searchQuery === '' || 
      e.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      e.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (e.tags || []).some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchSub && matchSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fadeIn">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 flex items-center justify-center shadow-lg shadow-indigo-500/10">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">Study Guides & Notebook</h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Organize key concepts, high-yield notes, and generate exams with 1 click.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handleStartNewNote}
            className="inline-flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Plus className="w-4 h-4" />
            <span>New Study Guide</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Sidebar + Note Viewer/Editor */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Sidebar: Note List */}
        <div className="lg:col-span-4 space-y-4">
          
          {/* Search and Filter */}
          <div className="p-3.5 bg-white/[0.04] border border-white/10 rounded-2xl backdrop-blur-xl space-y-2.5">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search study notes or tags..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-400"
              />
            </div>

            {/* Subject Filters */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar text-[11px]">
              {allSubjects.map(sub => (
                <button
                  key={sub}
                  onClick={() => setSelectedSubject(sub)}
                  className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
                    selectedSubject === sub
                      ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
                      : 'bg-white/5 text-slate-400 hover:text-white border border-transparent'
                  }`}
                >
                  {sub}
                </button>
              ))}
            </div>
          </div>

          {/* List of Notes */}
          <div className="space-y-2.5 max-h-[640px] overflow-y-auto pr-1 custom-scrollbar">
            {filteredEntries.length === 0 ? (
              <div className="p-8 text-center bg-white/[0.02] border border-white/10 rounded-2xl">
                <BookOpen className="w-8 h-8 text-slate-500 mx-auto mb-2" />
                <p className="text-xs text-slate-400">No study notes found.</p>
                <button
                  onClick={handleStartNewNote}
                  className="mt-3 text-xs text-indigo-400 hover:text-indigo-300 font-semibold"
                >
                  + Create your first study guide
                </button>
              </div>
            ) : (
              filteredEntries.map(entry => {
                const isSelected = activeEntry && entry.id === activeEntry.id;
                return (
                  <div
                    key={entry.id}
                    onClick={() => handleSelectEntry(entry)}
                    className={`group p-4 rounded-2xl border text-left cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-indigo-500/15 border-indigo-500/50 shadow-md ring-1 ring-indigo-500/30'
                        : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06] hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <h4 className={`text-xs font-bold truncate ${isSelected ? 'text-indigo-300' : 'text-white'}`}>
                        {entry.title}
                      </h4>
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-white/10 text-slate-300">
                        {entry.subject || 'General'}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-1.5 leading-relaxed font-sans">
                      {entry.content.replace(/[#*`_]/g, '')}
                    </p>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2.5 pt-2 border-t border-white/5">
                      <div className="flex items-center space-x-1 truncate max-w-[140px]">
                        <Tag className="w-3 h-3 text-slate-400 flex-shrink-0" />
                        <span className="truncate">{(entry.tags || []).join(', ') || 'No tags'}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span>{new Date(entry.lastUpdated).toLocaleDateString()}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setEntryToDeleteId(entry.id);
                            setShowDeleteModal(true);
                          }}
                          className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-400 rounded transition-opacity"
                          title="Delete note"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

        </div>

        {/* Right Area: Selected Note Viewer & Editor */}
        <div className="lg:col-span-8">
          {activeEntry ? (
            <div className="bg-slate-900/90 border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl space-y-6">
              
              {/* Header inside Note Viewer */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
                <div className="space-y-1 min-w-0 flex-1">
                  {isEditing ? (
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      placeholder="Note Title..."
                      className="text-xl sm:text-2xl font-black text-white bg-transparent border-b border-indigo-400 focus:outline-none w-full px-1 py-0.5"
                    />
                  ) : (
                    <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                      {activeEntry.title}
                    </h2>
                  )}

                  <div className="flex items-center space-x-3 text-xs text-slate-400 flex-wrap pt-1">
                    <span className="px-2.5 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 font-semibold">
                      {activeEntry.subject || 'General'}
                    </span>
                    <span>Updated: {new Date(activeEntry.lastUpdated).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Top Action Toolbar */}
                <div className="flex items-center space-x-2 flex-wrap">
                  {isEditing ? (
                    <button
                      onClick={handleSaveCurrentEdit}
                      className="inline-flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md transition-all hover:scale-[1.02]"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>Save Changes</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        sounds.playClick();
                        setIsEditing(true);
                        setEditTitle(activeEntry.title);
                        setEditSubject(activeEntry.subject);
                        setEditContent(activeEntry.content);
                        setEditTags((activeEntry.tags || []).join(', '));
                      }}
                      className="p-2.5 text-slate-300 hover:text-white bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all"
                      title="Edit Note"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={handleCopyContent}
                    className="p-2.5 text-slate-300 hover:text-white bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all"
                    title="Copy note text"
                  >
                    {copiedId === activeEntry.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={handleDownloadDoc}
                    className="p-2.5 text-slate-300 hover:text-white bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all"
                    title="Download Note (.md)"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  <button
                    onClick={handlePrint}
                    className="p-2.5 text-slate-300 hover:text-white bg-white/5 hover:bg-white/15 border border-white/10 rounded-xl transition-all"
                    title="Print Note"
                  >
                    <Printer className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => {
                      sounds.playClick();
                      setEntryToDeleteId(activeEntry.id);
                      setShowDeleteModal(true);
                    }}
                    className="p-2.5 text-slate-400 hover:text-rose-400 bg-white/5 hover:bg-rose-500/20 border border-white/10 rounded-xl transition-all"
                    title="Delete Note"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => {
                      sounds.playCorrect();
                      onGenerateTestFromNote(activeEntry);
                    }}
                    className="inline-flex items-center space-x-1.5 px-3.5 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 rounded-xl text-xs font-black shadow-lg shadow-amber-500/20 transition-all hover:scale-[1.02]"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Generate Test</span>
                  </button>
                </div>
              </div>

              {/* Subject & Tags Editor when in Edit mode */}
              {isEditing && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-white/5 p-4 rounded-2xl border border-white/10">
                  <div>
                    <label className="block text-[11px] font-semibold uppercase text-slate-300 mb-1">Subject:</label>
                    <input
                      type="text"
                      value={editSubject}
                      onChange={(e) => setEditSubject(e.target.value)}
                      placeholder="e.g. Biology, History, Computer Science"
                      className="w-full px-3 py-1.5 bg-white/10 border border-white/15 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold uppercase text-slate-300 mb-1">Tags (comma separated):</label>
                    <input
                      type="text"
                      value={editTags}
                      onChange={(e) => setEditTags(e.target.value)}
                      placeholder="e.g. Glycolysis, Exam 1, Formulas"
                      className="w-full px-3 py-1.5 bg-white/10 border border-white/15 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-indigo-400"
                    />
                  </div>
                </div>
              )}

              {/* Note Content Viewer or Editor */}
              {isEditing ? (
                <div>
                  <textarea
                    rows={16}
                    value={editContent}
                    onChange={(e) => setEditContent(e.target.value)}
                    placeholder="Write your markdown study notes here..."
                    className="w-full p-4 bg-slate-950/80 border border-white/15 rounded-2xl text-white font-mono text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-400 leading-relaxed custom-scrollbar"
                  />
                </div>
              ) : (
                <div className="p-4 sm:p-6 bg-slate-950/70 border border-white/10 rounded-2xl min-h-[360px]">
                  <DocumentRenderer
                    content={activeEntry.content}
                    onContentChange={(updatedContent) => {
                      const updated = {
                        ...activeEntry,
                        content: updatedContent,
                        lastUpdated: new Date().toISOString(),
                      };
                      onSaveEntry(updated);
                    }}
                  />
                </div>
              )}

              {/* Quick AI Coaching Chips at Bottom */}
              <div className="pt-4 border-t border-white/10">
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center space-x-1.5">
                  <HelpCircle className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Confused about anything in this note?</span>
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => {
                      sounds.playClick();
                      onExplainConcept(`Explain the core takeaways and common exam traps of: ${activeEntry.title}`);
                    }}
                    className="px-3.5 py-1.5 bg-white/5 hover:bg-white/15 border border-white/10 hover:border-white/20 text-slate-200 hover:text-white rounded-xl text-xs font-semibold transition-all"
                  >
                    💡 Explain Core Concepts & Traps
                  </button>
                  <button
                    onClick={() => {
                      sounds.playClick();
                      onExplainConcept(`Create a memorable mnemonic and real-world analogy for: ${activeEntry.title}`);
                    }}
                    className="px-3.5 py-1.5 bg-white/5 hover:bg-white/15 border border-white/10 hover:border-white/20 text-slate-200 hover:text-white rounded-xl text-xs font-semibold transition-all"
                  >
                    🧠 Generate Mnemonic & Analogies
                  </button>
                </div>
              </div>

            </div>
          ) : (
            <div className="text-center py-20 bg-white/[0.04] border border-white/10 rounded-3xl p-8 text-white">
              <BookOpen className="w-12 h-12 text-slate-500 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white">No Note Selected</h3>
              <p className="text-xs text-slate-400 mt-1 mb-4">Select a note from the left or create a new study guide.</p>
              <button
                onClick={handleStartNewNote}
                className="px-5 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white rounded-xl text-xs font-bold shadow-md transition-all"
              >
                Create Study Note
              </button>
            </div>
          )}
        </div>

      </div>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={showDeleteModal}
        itemType="study"
        itemTitle={entries.find(e => e.id === entryToDeleteId)?.title || activeEntry?.title || 'Study Guide'}
        onConfirm={confirmDelete}
        onCancel={() => {
          setShowDeleteModal(false);
          setEntryToDeleteId(null);
        }}
      />

    </div>
  );
};
