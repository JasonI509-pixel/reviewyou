import React from 'react';
import { Trash2, AlertTriangle, X } from 'lucide-react';
import { sounds } from '../lib/sound';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  itemType: 'test' | 'study' | 'notebook' | 'attempt' | 'all';
  itemTitle: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({
  isOpen,
  itemType,
  itemTitle,
  onConfirm,
  onCancel,
}) => {
  if (!isOpen) return null;

  const typeLabels = {
    test: 'Test / Quiz',
    study: 'Study Guide & Note',
    notebook: 'Notebook Document',
    attempt: 'Test Score Attempt',
    all: 'All History & Attempts',
  };

  const typeLabel = typeLabels[itemType] || 'Item';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
      <div 
        className="w-full max-w-md bg-slate-900 border border-rose-500/30 rounded-3xl p-6 shadow-2xl space-y-5 animate-scaleUp"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-400 flex items-center justify-center">
            <Trash2 className="w-6 h-6" />
          </div>
          <button
            onClick={() => { sounds.playClick(); onCancel(); }}
            className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div>
          <h3 className="text-xl font-bold text-white">Delete {typeLabel}?</h3>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 leading-relaxed">
            Are you sure you want to permanently delete <strong className="text-white font-semibold">"{itemTitle}"</strong>?
          </p>
          <div className="mt-3 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-[11px] text-rose-300 flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0 text-rose-400" />
            <span>This action cannot be undone.</span>
          </div>
        </div>

        <div className="flex items-center justify-end space-x-3 pt-2">
          <button
            type="button"
            onClick={() => { sounds.playClick(); onCancel(); }}
            className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white text-xs font-semibold border border-white/10 transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={() => {
              sounds.playClick();
              onConfirm();
            }}
            className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg shadow-rose-600/30 flex items-center space-x-2 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Trash2 className="w-4 h-4" />
            <span>Delete Permanently</span>
          </button>
        </div>
      </div>
    </div>
  );
};
