import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  Award, 
  CheckCircle2, 
  Flame, 
  RotateCcw, 
  Search, 
  Filter, 
  Sparkles, 
  ChevronRight,
  Eye,
  Zap,
  Target,
  Trash2
} from 'lucide-react';
import { QuizAttempt, SubjectStats } from '../types';
import { sounds } from '../lib/sound';
import { DeleteConfirmModal } from './DeleteConfirmModal';

interface ProgressAnalyticsProps {
  attempts: QuizAttempt[];
  subjectStats: Record<string, SubjectStats>;
  onRetakeTest: (quizId: string) => void;
  onViewAttemptDetails: (attempt: QuizAttempt) => void;
  onDeleteAttempt?: (attemptId: string) => void;
  onClearAllAttempts?: () => void;
}

export const ProgressAnalytics: React.FC<ProgressAnalyticsProps> = ({
  attempts,
  subjectStats,
  onRetakeTest,
  onViewAttemptDetails,
  onDeleteAttempt,
  onClearAllAttempts,
}) => {
  const [filterSubject, setFilterSubject] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [attemptToDelete, setAttemptToDelete] = useState<QuizAttempt | null>(null);
  const [isClearingAll, setIsClearingAll] = useState<boolean>(false);

  // Calculate high-level aggregates
  const totalTests = attempts.length;
  const avgScore = totalTests > 0 
    ? Math.round(attempts.reduce((acc, a) => acc + a.scorePercentage, 0) / totalTests)
    : 0;
  const bestScore = totalTests > 0
    ? Math.max(...attempts.map(a => a.scorePercentage))
    : 0;
  const totalQuestions = attempts.reduce((acc, a) => acc + a.totalQuestions, 0);
  const correctQuestions = attempts.reduce((acc, a) => acc + a.correctCount, 0);
  const overallAccuracy = totalQuestions > 0 ? Math.round((correctQuestions / totalQuestions) * 100) : 0;
  
  const totalTimeSeconds = attempts.reduce((acc, a) => acc + a.totalDurationSeconds, 0);
  const avgSpeedPerQ = totalQuestions > 0 ? Math.round(totalTimeSeconds / totalQuestions) : 0;

  // Filter attempts
  const allSubjects = ['All', ...Object.keys(subjectStats)];
  const filteredAttempts = attempts.filter(att => {
    const matchSub = filterSubject === 'All' || att.subject === filterSubject;
    const matchSearch = searchQuery === '' || 
      att.quizTitle.toLowerCase().includes(searchQuery.toLowerCase()) || 
      att.subject.toLowerCase().includes(searchQuery.toLowerCase());
    return matchSub && matchSearch;
  });

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s < 10 ? '0' : ''}${s}s`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 animate-fadeIn">
      
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white flex items-center space-x-2.5 drop-shadow-sm">
            <BarChart3 className="w-7 h-7 text-indigo-400" />
            <span>Progress & Mastery Intelligence</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Track your accuracy improvements, time-trial velocity, and diagnostic mastery across all subjects.
          </p>
        </div>
      </div>

      {/* Aggregate KPI Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        
        {/* Average Score */}
        <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-2xl p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-1 text-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Average Score</span>
            <Award className="w-4 h-4 text-indigo-400" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-white drop-shadow-sm">{avgScore}%</p>
          <p className="text-[11px] text-slate-300">Across {totalTests} total completed tests</p>
        </div>

        {/* Best Score */}
        <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-2xl p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-1 text-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Top Score</span>
            <Flame className="w-4 h-4 text-orange-400" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-indigo-300 drop-shadow-sm">{bestScore}%</p>
          <p className="text-[11px] text-slate-300">Personal benchmark</p>
        </div>

        {/* Average Speed */}
        <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-2xl p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-1 text-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Pace Velocity</span>
            <Clock className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-white drop-shadow-sm">{avgSpeedPerQ}s</p>
          <p className="text-[11px] text-slate-300">Avg seconds per question</p>
        </div>

        {/* Questions Mastered */}
        <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-2xl p-5 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-1 text-white">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Accuracy</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl sm:text-3xl font-extrabold text-white drop-shadow-sm">{overallAccuracy}%</p>
          <p className="text-[11px] text-slate-300">{correctQuestions} of {totalQuestions} Qs correct</p>
        </div>

      </div>

      {/* Subject Mastery Breakdown Section */}
      <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-2xl p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6 text-white">
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center space-x-2">
              <Target className="w-5 h-5 text-indigo-400" />
              <span>Subject Readiness & Mastery Meters</span>
            </h2>
            <p className="text-xs text-slate-400">Real-time competency tracking calculated from your timed attempts</p>
          </div>
        </div>

        {Object.keys(subjectStats).length === 0 ? (
          <p className="text-xs text-slate-400 py-4">No subject data yet. Complete a test to see readiness metrics.</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {(Object.values(subjectStats) as SubjectStats[]).map((stat) => {
              const isHigh = stat.masteryLevel >= 80;
              const isMid = stat.masteryLevel >= 65 && stat.masteryLevel < 80;

              return (
                <div 
                  key={stat.subject}
                  className="bg-white/5 border border-white/10 rounded-2xl p-5 space-y-3 backdrop-blur-md"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white text-sm">{stat.subject}</span>
                    <div className="flex items-center space-x-1.5 text-xs font-semibold">
                      {stat.recentTrend === 'up' && (
                        <span className="flex items-center text-emerald-300 bg-emerald-500/20 border border-emerald-400/30 px-2 py-0.5 rounded backdrop-blur-md">
                          <TrendingUp className="w-3 h-3 mr-1" />
                          <span>Rising</span>
                        </span>
                      )}
                      {stat.recentTrend === 'down' && (
                        <span className="flex items-center text-rose-300 bg-rose-500/20 border border-rose-400/30 px-2 py-0.5 rounded backdrop-blur-md">
                          <TrendingDown className="w-3 h-3 mr-1" />
                          <span>Review</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Meter Progress Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-slate-300">
                      <span>Mastery Score</span>
                      <span className="font-bold text-white">{stat.masteryLevel}%</span>
                    </div>
                    <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden border border-white/5">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${
                          isHigh ? 'bg-emerald-400' : isMid ? 'bg-indigo-400' : 'bg-amber-400'
                        }`}
                        style={{ width: `${stat.masteryLevel}%` }}
                      />
                    </div>
                  </div>

                  {/* Mini Stats Row */}
                  <div className="grid grid-cols-3 gap-1 pt-2 border-t border-white/10 text-center text-[10px]">
                    <div>
                      <p className="text-slate-400 font-semibold uppercase">Tests</p>
                      <p className="font-bold text-white">{stat.testsTaken}</p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-semibold uppercase">Top Score</p>
                      <p className="font-bold text-indigo-300">{stat.bestScore}%</p>
                    </div>
                    <div>
                      <p className="text-slate-400 font-semibold uppercase">Avg Speed</p>
                      <p className="font-bold text-white">{stat.avgSpeedSeconds}s/Q</p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Historical Test Attempt Logs Table */}
      <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-2xl p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6 text-white">
        
        {/* Table Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-white/10">
          <div>
            <h2 className="text-lg font-bold text-white">Historical Test Log & Diagnostics</h2>
            <p className="text-xs text-slate-400">Review past attempts, score deltas, and AI feedback.</p>
          </div>

          <div className="flex items-center space-x-2 flex-wrap gap-y-2">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search history..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 bg-white/10 border border-white/15 rounded-lg text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-400 backdrop-blur-md"
              />
            </div>

            <select
              value={filterSubject}
              onChange={(e) => setFilterSubject(e.target.value)}
              className="px-3 py-1.5 bg-white/10 border border-white/15 rounded-lg text-xs text-white focus:outline-none focus:ring-2 focus:ring-indigo-400 backdrop-blur-md"
            >
              {allSubjects.map(s => (
                <option key={s} value={s} className="bg-slate-900 text-white">{s}</option>
              ))}
            </select>

            {onClearAllAttempts && attempts.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  sounds.playClick();
                  setIsClearingAll(true);
                }}
                className="px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-lg text-xs font-semibold flex items-center space-x-1 transition-all"
                title="Clear all test logs"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear All Logs</span>
              </button>
            )}
          </div>
        </div>

        {/* Attempts Table */}
        {filteredAttempts.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-xs text-slate-400">No test attempts recorded matching the filters.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-white/10 text-slate-400 uppercase font-semibold text-[10px]">
                  <th className="pb-3 pr-4">Date & Time</th>
                  <th className="pb-3 pr-4">Test Title</th>
                  <th className="pb-3 pr-4">Subject</th>
                  <th className="pb-3 pr-4">Score</th>
                  <th className="pb-3 pr-4">Pacing</th>
                  <th className="pb-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {filteredAttempts.map((attempt) => {
                  const isHigh = attempt.scorePercentage >= 80;
                  const isMid = attempt.scorePercentage >= 65 && attempt.scorePercentage < 80;

                  return (
                    <tr key={attempt.id} className="hover:bg-white/5 transition-colors">
                      
                      {/* Date */}
                      <td className="py-3.5 pr-4 text-slate-300 whitespace-nowrap">
                        {new Date(attempt.completedAt).toLocaleDateString()} at{' '}
                        {new Date(attempt.completedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </td>

                      {/* Title */}
                      <td className="py-3.5 pr-4 font-bold text-white">
                        {attempt.quizTitle}
                      </td>

                      {/* Subject */}
                      <td className="py-3.5 pr-4">
                        <span className="px-2 py-0.5 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 rounded text-[10px] font-semibold">
                          {attempt.subject}
                        </span>
                      </td>

                      {/* Score & Delta */}
                      <td className="py-3.5 pr-4 whitespace-nowrap">
                        <div className="flex items-center space-x-2">
                          <span className={`font-extrabold text-sm ${
                            isHigh ? 'text-emerald-400' : isMid ? 'text-indigo-300' : 'text-rose-400'
                          }`}>
                            {attempt.scorePercentage}%
                          </span>
                          <span className="text-slate-400 text-[11px]">
                            ({attempt.correctCount}/{attempt.totalQuestions})
                          </span>
                          {attempt.scoreImprovement !== undefined && attempt.scoreImprovement > 0 && (
                            <span className="text-[10px] text-emerald-300 font-bold bg-emerald-500/20 border border-emerald-400/30 px-1.5 py-0.5 rounded">
                              +{attempt.scoreImprovement}%
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Time */}
                      <td className="py-3.5 pr-4 text-slate-300 whitespace-nowrap">
                        {formatDuration(attempt.totalDurationSeconds)} ({attempt.avgTimePerQuestion}s/Q)
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 text-right space-x-2 whitespace-nowrap">
                        <button
                          onClick={() => {
                            sounds.playClick();
                            onViewAttemptDetails(attempt);
                          }}
                          className="inline-flex items-center space-x-1 px-3 py-1.5 bg-white/10 hover:bg-white/20 border border-white/15 text-white rounded-lg text-xs font-semibold backdrop-blur-md transition-all"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Diagnostic</span>
                        </button>
                        <button
                          onClick={() => {
                            sounds.playClick();
                            onRetakeTest(attempt.quizId);
                          }}
                          className="inline-flex items-center space-x-1 px-3 py-1.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white rounded-lg text-xs font-semibold shadow-md border border-white/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Retake</span>
                        </button>
                        {onDeleteAttempt && (
                          <button
                            type="button"
                            onClick={() => {
                              sounds.playClick();
                              setAttemptToDelete(attempt);
                            }}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/20 border border-transparent hover:border-rose-400/20 transition-all inline-flex items-center"
                            title="Delete attempt record"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </div>

      {/* Delete Attempt Modal */}
      <DeleteConfirmModal
        isOpen={!!attemptToDelete}
        itemType="attempt"
        itemTitle={attemptToDelete?.quizTitle || 'Test Attempt'}
        onConfirm={() => {
          if (attemptToDelete && onDeleteAttempt) {
            sounds.playClick();
            onDeleteAttempt(attemptToDelete.id);
            setAttemptToDelete(null);
          }
        }}
        onCancel={() => setAttemptToDelete(null)}
      />

      {/* Clear All Attempts Modal */}
      <DeleteConfirmModal
        isOpen={isClearingAll}
        itemType="all test history records"
        itemTitle={`All ${attempts.length} Test Attempt Logs`}
        onConfirm={() => {
          if (onClearAllAttempts) {
            sounds.playClick();
            onClearAllAttempts();
            setIsClearingAll(false);
          }
        }}
        onCancel={() => setIsClearingAll(false)}
      />

    </div>
  );
};
