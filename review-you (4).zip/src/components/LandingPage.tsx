import React, { useState } from 'react';
import { 
  Sparkles, 
  Timer, 
  BookOpen, 
  CheckCircle2, 
  ArrowRight, 
  FileText, 
  Image as ImageIcon, 
  Award, 
  BarChart3, 
  ShieldCheck, 
  Zap, 
  GraduationCap, 
  Layers,
  ChevronRight,
  HelpCircle,
  Clock,
  Flame,
  Check,
  Palette,
  FolderDown
} from 'lucide-react';
import { sounds } from '../lib/sound';
import { Logo } from './Logo';

interface LandingPageProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onGetStarted, onSignIn }) => {
  const [selectedDemoAnswer, setSelectedDemoAnswer] = useState<number | null>(null);
  const [showDemoFeedback, setShowDemoFeedback] = useState(false);

  const handleDemoSelect = (index: number) => {
    sounds.playClick();
    setSelectedDemoAnswer(index);
    setShowDemoFeedback(true);
    if (index === 1) {
      sounds.playCorrect();
    } else {
      sounds.playIncorrect();
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950 relative overflow-x-hidden">
      
      {/* Ambient background glowing accents */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-950/30 via-slate-950 to-slate-950 opacity-95" />
        <div className="absolute -top-40 -left-40 w-[32rem] h-[32rem] bg-amber-500/15 rounded-full blur-3xl" />
        <div className="absolute top-1/3 -right-40 w-[36rem] h-[36rem] bg-yellow-500/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 left-1/3 w-[30rem] h-[30rem] bg-amber-600/10 rounded-full blur-3xl" />
      </div>

      {/* Navigation Header */}
      <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-xl border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          
          <div className="flex items-center space-x-3">
            <Logo size="md" />
          </div>

          <div className="flex items-center space-x-3 sm:space-x-4">
            <button
              id="landing-signin-btn"
              onClick={() => { sounds.playClick(); onSignIn(); }}
              className="px-4 sm:px-5 py-2.5 rounded-xl text-sm font-semibold text-slate-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all"
            >
              Sign In
            </button>
            <button
              id="landing-getstarted-btn"
              onClick={() => { sounds.playClick(); onGetStarted(); }}
              className="px-5 sm:px-6 py-2.5 rounded-xl text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 shadow-xl shadow-amber-500/25 border border-white/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              Get Started Free
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 flex flex-col">
        
        {/* Hero Section */}
        <section className="pt-16 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full text-center">
          <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-400/30 text-amber-300 text-xs sm:text-sm font-medium mb-6 backdrop-blur-md animate-fadeIn">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Turn Any Review Sheet, Book, or Exam into a Timed Practice Test</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white max-w-5xl mx-auto leading-[1.1] mb-6">
            Master Any Exam with <br className="hidden sm:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-200 to-amber-400">
              Personalized Timed Tests
            </span>
          </h1>

          <p className="text-slate-300 text-base sm:text-xl max-w-3xl mx-auto leading-relaxed mb-10">
            Type your study guide questions or upload photos of your review worksheets. Review You builds realistic, timed practice tests with instant AI grading, pacing clocks, and auto-generated study notebooks.
          </p>

          {/* CTA Group */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 max-w-md mx-auto mb-16">
            <button
              id="hero-create-account-btn"
              onClick={() => { sounds.playClick(); onGetStarted(); }}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 font-bold text-base shadow-2xl shadow-amber-500/30 hover:shadow-amber-500/50 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center space-x-3 border border-white/25"
            >
              <span>Build Practice Test</span>
              <ArrowRight className="w-5 h-5" />
            </button>

            <button
              id="hero-see-demo-btn"
              onClick={() => {
                sounds.playClick();
                document.getElementById('interactive-demo')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full sm:w-auto px-6 py-4 rounded-2xl bg-white/5 hover:bg-white/10 text-white font-semibold text-base border border-white/10 transition-all flex items-center justify-center space-x-2"
            >
              <Clock className="w-5 h-5 text-amber-400" />
              <span>Try Interactive Drill</span>
            </button>
          </div>

          {/* Stats / Trust Badges */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-6 border-t border-white/10">
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-sm">
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-300">1-Click</div>
              <div className="text-xs text-slate-400 mt-1">Worksheet OCR & Study Import</div>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-sm">
              <div className="text-2xl sm:text-3xl font-extrabold text-yellow-300">Adaptive</div>
              <div className="text-xs text-slate-400 mt-1">Timed Question Pacing</div>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-sm">
              <div className="text-2xl sm:text-3xl font-extrabold text-amber-300">100%</div>
              <div className="text-xs text-slate-400 mt-1">Deep Diagnostic Breakdowns</div>
            </div>
            <div className="p-4 rounded-2xl bg-white/[0.03] border border-white/10 backdrop-blur-sm">
              <div className="text-2xl sm:text-3xl font-extrabold text-yellow-300">Auto</div>
              <div className="text-xs text-slate-400 mt-1">Concept Notebook Generation</div>
            </div>
          </div>
        </section>

        {/* 4 Core Pillars */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-xs font-bold text-amber-400 uppercase tracking-widest mb-2">Everything You Need to Ace Any Exam</h2>
            <p className="text-2xl sm:text-4xl font-extrabold text-white">Engineered for Maximum Retention & Fast Recall</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            
            <div className="p-6 rounded-3xl bg-slate-900/80 border border-white/15 backdrop-blur-xl shadow-xl hover:border-amber-400/40 transition-all">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center mb-4 border border-amber-400/30">
                <ImageIcon className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Review Photo OCR</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Snap a photo of your handwritten notes, study guide worksheets, or textbook problems. AI extracts every question to generate a targeted exam drill.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-900/80 border border-white/15 backdrop-blur-xl shadow-xl hover:border-amber-400/40 transition-all">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center mb-4 border border-amber-400/30">
                <Timer className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Timed Exam Pacing</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Simulate real exam pressure with realistic per-question timers (30s, 45s, 60s, or adaptive) and instant pace tracking to beat test anxiety.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-900/80 border border-white/15 backdrop-blur-xl shadow-xl hover:border-amber-400/40 transition-all">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center mb-4 border border-amber-400/30">
                <BookOpen className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Auto-Study Notebook</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Review You automatically captures weak points and missed concepts after each test, organizing them into searchable notes and flash-review guides.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-900/80 border border-white/15 backdrop-blur-xl shadow-xl hover:border-amber-400/40 transition-all">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center mb-4 border border-amber-400/30">
                <Palette className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Custom Theme Colors</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Personalize your study sanctuary anytime. Choose between Review You Gold, Electric Indigo, Emerald Mastery, Cyber Cyan, Crimson Flame, and more.
              </p>
            </div>

          </div>
        </section>

        {/* Interactive Demo Question */}
        <section id="interactive-demo" className="py-16 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto w-full">
          <div className="p-6 sm:p-10 rounded-3xl bg-gradient-to-br from-amber-950/30 via-slate-900/90 to-slate-900/90 border-2 border-amber-400/30 shadow-2xl backdrop-blur-2xl">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <span className="w-3 h-3 rounded-full bg-amber-400 animate-ping" />
                <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">Live Sample Diagnostic Question</span>
              </div>
              <span className="text-xs text-slate-400">AP Biology Exam Drill</span>
            </div>

            <h3 className="text-lg sm:text-xl font-bold text-white mb-6">
              Which metabolic stage of cellular respiration produces the highest net yield of ATP per glucose molecule?
            </h3>

            <div className="space-y-3 mb-6">
              {[
                { text: 'Glycolysis in the cytosol', correct: false },
                { text: 'Oxidative Phosphorylation (Electron Transport Chain & Chemiosmosis)', correct: true },
                { text: 'Krebs Cycle (Citric Acid Cycle) in the mitochondrial matrix', correct: false },
                { text: 'Pyruvate oxidation to acetyl-CoA', correct: false },
              ].map((opt, idx) => {
                const isSelected = selectedDemoAnswer === idx;
                const isCorrect = opt.correct;
                let btnStyle = 'bg-white/5 border-white/10 hover:bg-white/10 text-slate-200';
                
                if (showDemoFeedback && isSelected) {
                  btnStyle = isCorrect 
                    ? 'bg-emerald-500/20 border-emerald-400 text-emerald-200 font-bold' 
                    : 'bg-rose-500/20 border-rose-400 text-rose-200 font-bold';
                } else if (showDemoFeedback && isCorrect) {
                  btnStyle = 'bg-emerald-500/20 border-emerald-400 text-emerald-200 font-bold';
                }

                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleDemoSelect(idx)}
                    className={`w-full p-4 rounded-2xl border text-left text-sm transition-all flex items-center justify-between ${btnStyle}`}
                  >
                    <span>{opt.text}</span>
                    {showDemoFeedback && isCorrect && <Check className="w-5 h-5 text-emerald-400 flex-shrink-0" />}
                  </button>
                );
              })}
            </div>

            {showDemoFeedback && (
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-400/30 text-xs text-amber-200 animate-fadeIn mb-6">
                <strong>Diagnostic Breakdown:</strong> Oxidative phosphorylation generates ~26–28 ATP per glucose via ATP synthase powered by the proton gradient across the inner mitochondrial membrane.
              </div>
            )}

            <button
              onClick={() => { sounds.playClick(); onGetStarted(); }}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/20 hover:scale-[1.01] transition-all flex items-center justify-center space-x-2"
            >
              <span>Build Full Practice Test Free</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>

      </main>

      {/* Footer */}
      <footer className="border-t border-white/10 bg-slate-950/90 py-8 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <Logo size="sm" />
          <p className="text-slate-400">AI Test Generator, Timed Exam Room & Diagnostic Notebook Platform.</p>
        </div>
      </footer>

    </div>
  );
};
