import React from 'react';
import { Check, Palette, Sparkles, X } from 'lucide-react';
import { ThemeColor, THEMES, ThemeConfig } from '../lib/theme';
import { sounds } from '../lib/sound';
import { Logo } from './Logo';

interface ThemePickerModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: ThemeColor;
  onSelectTheme: (theme: ThemeColor) => void;
}

export const ThemePickerModal: React.FC<ThemePickerModalProps> = ({
  isOpen,
  onClose,
  currentTheme,
  onSelectTheme,
}) => {
  if (!isOpen) return null;

  const themeList = Object.values(THEMES);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-slate-900/95 border border-white/20 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden">
        
        {/* Background glow of current theme */}
        <div 
          className="absolute -top-24 -right-24 w-60 h-60 rounded-full blur-3xl opacity-30 pointer-events-none transition-colors duration-500"
          style={{ backgroundColor: THEMES[currentTheme]?.colorHex || '#FACC15' }}
        />

        {/* Close Button */}
        <button
          onClick={() => { sounds.playClick(); onClose(); }}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          title="Close theme picker"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center space-x-3 mb-6">
          <div 
            className="w-10 h-10 rounded-2xl flex items-center justify-center text-slate-950 font-bold shadow-lg"
            style={{ backgroundColor: THEMES[currentTheme]?.colorHex || '#FACC15' }}
          >
            <Palette className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Customize Workspace Theme</h2>
            <p className="text-xs text-slate-400">Choose your favorite accent color for tests, timers & highlights</p>
          </div>
        </div>

        {/* Live Logo & Preview Banner */}
        <div className="p-4 rounded-2xl bg-slate-950/70 border border-white/10 mb-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <div className="text-xs text-slate-400 font-medium mb-1">Live Theme Preview:</div>
            <Logo size="sm" themeColor={currentTheme} useDynamicColor={true} />
          </div>
          <div className="flex items-center space-x-2">
            <span 
              className="px-3 py-1 rounded-full text-xs font-bold border"
              style={{
                backgroundColor: `${THEMES[currentTheme]?.colorHex}20`,
                color: THEMES[currentTheme]?.colorHex,
                borderColor: `${THEMES[currentTheme]?.colorHex}50`
              }}
            >
              {THEMES[currentTheme]?.name}
            </span>
          </div>
        </div>

        {/* Theme Options Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
          {themeList.map((t: ThemeConfig) => {
            const isSelected = currentTheme === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => {
                  sounds.playClick();
                  onSelectTheme(t.id);
                }}
                className={`p-3.5 rounded-2xl border text-left flex items-center justify-between transition-all group ${
                  isSelected
                    ? 'bg-white/10 border-white/40 shadow-lg scale-[1.02]'
                    : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.08] hover:border-white/20'
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div 
                    className="w-7 h-7 rounded-xl shadow-md flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-110"
                    style={{ background: `linear-gradient(135deg, ${t.colorHex}, ${t.secondaryHex})` }}
                  >
                    {isSelected && <Check className="w-4 h-4 text-slate-950 stroke-[3]" />}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">{t.name}</div>
                    <div className="text-[10px] text-slate-400">{t.label}</div>
                  </div>
                </div>

                {isSelected && (
                  <span className="text-[10px] uppercase font-bold text-amber-300 px-2 py-0.5 rounded bg-white/10">
                    Active
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer info & Done Button */}
        <div className="flex items-center justify-between pt-2 border-t border-white/10">
          <span className="text-[11px] text-slate-400">Settings save to your account automatically.</span>
          <button
            onClick={() => { sounds.playClick(); onClose(); }}
            className="px-5 py-2.5 rounded-xl font-bold text-xs text-slate-950 shadow-lg transition-transform hover:scale-105 active:scale-95"
            style={{ backgroundColor: THEMES[currentTheme]?.colorHex || '#FACC15' }}
          >
            Done
          </button>
        </div>

      </div>
    </div>
  );
};
