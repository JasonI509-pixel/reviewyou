import React, { useState } from 'react';
import { 
  Sparkles, 
  BookOpen, 
  BarChart3, 
  HelpCircle, 
  Plus, 
  Volume2, 
  VolumeX, 
  Flame,
  Timer,
  LogOut,
  ChevronDown,
  Palette,
  Check,
  Edit3
} from 'lucide-react';
import { sounds } from '../lib/sound';
import { UserAccount } from '../types';
import { Logo } from './Logo';
import { ThemeColor, THEMES } from '../lib/theme';

interface NavbarProps {
  currentTab: 'quizzes' | 'test_session' | 'notebook' | 'analytics' | 'coach';
  setCurrentTab: (tab: 'quizzes' | 'test_session' | 'notebook' | 'analytics' | 'coach') => void;
  isTestActive: boolean;
  onNewTestClick: () => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  streakCount: number;
  activeUser: UserAccount | null;
  onLogout: () => void;
  onOpenAuth: () => void;
  currentTheme?: ThemeColor;
  onOpenThemePicker?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  isTestActive,
  onNewTestClick,
  soundEnabled,
  setSoundEnabled,
  streakCount,
  activeUser,
  onLogout,
  onOpenAuth,
  currentTheme = 'gold',
  onOpenThemePicker,
}) => {
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const themeConfig = THEMES[currentTheme] || THEMES.gold;

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sounds.setEnabled(next);
    if (next) sounds.playClick();
  };

  const navItems = [
    { id: 'quizzes' as const, label: 'Practice Tests', icon: Sparkles },
    { id: 'notebook' as const, label: 'Study Notes', icon: Edit3 },
    { id: 'coach' as const, label: 'AI Tutor', icon: HelpCircle },
    { id: 'analytics' as const, label: 'My Progress', icon: BarChart3 },
  ];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-2xl border-b border-white/10 shadow-[0_4px_24px_rgba(0,0,0,0.4)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          
          {/* Left: Brand Logo */}
          <div 
            className="flex items-center cursor-pointer group py-1"
            onClick={() => { sounds.playClick(); setCurrentTab('quizzes'); }}
            title="Review You - AI Test Prep & Study Hub"
          >
            <Logo size="md" themeColor={currentTheme} useDynamicColor={true} />
          </div>

          {/* Center: Sleek Modern Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1 p-1 bg-white/[0.04] border border-white/10 rounded-2xl backdrop-blur-md">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-${item.id}`}
                  onClick={() => { sounds.playClick(); setCurrentTab(item.id); }}
                  className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-white/15 text-white shadow-sm border border-white/20'
                      : 'text-slate-300 hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <Icon 
                    className="w-4 h-4 transition-colors" 
                    style={{ color: isActive ? themeConfig.colorHex : undefined }}
                  />
                  <span>{item.label}</span>
                </button>
              );
            })}

            {/* Active Test Session Indicator Button */}
            {isTestActive && (
              <button
                id="nav-active-test"
                onClick={() => { sounds.playClick(); setCurrentTab('test_session'); }}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all animate-pulse ${
                  currentTab === 'test_session'
                    ? 'bg-amber-500/30 text-amber-200 border border-amber-400/50 shadow-md'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-400/30 hover:bg-amber-500/30'
                }`}
              >
                <Timer className="w-4 h-4 text-amber-400" />
                <span>Active Test</span>
              </button>
            )}
          </nav>

          {/* Right: Actions, Theme Picker, Streak, Audio, Account Profile & CTA */}
          <div className="flex items-center space-x-2 sm:space-x-2.5">
            
            {/* Theme Color Picker Button */}
            {onOpenThemePicker && (
              <button
                onClick={() => { sounds.playClick(); onOpenThemePicker(); }}
                className="flex items-center space-x-1.5 px-2.5 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs text-slate-300 hover:text-white transition-all backdrop-blur-md"
                title="Change website theme color"
              >
                <div 
                  className="w-3 h-3 rounded-full shadow-sm ring-1 ring-white/30"
                  style={{ backgroundColor: themeConfig.colorHex }}
                />
                <span className="hidden xl:inline text-[11px] font-medium">Theme</span>
              </button>
            )}

            {/* Streak Counter */}
            <div 
              className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-amber-500/15 text-amber-300 rounded-xl border border-amber-400/25 backdrop-blur-md text-xs font-semibold" 
              title="Daily Study Streak"
            >
              <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
              <span>{streakCount}d</span>
            </div>

            {/* Sound Toggle */}
            <button
              id="btn-sound-toggle"
              onClick={toggleSound}
              className="p-2 text-slate-400 hover:text-white hover:bg-white/10 rounded-xl border border-white/10 backdrop-blur-md transition-colors"
              title={soundEnabled ? 'Mute Audio Effects' : 'Enable Audio Feedback'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-slate-200" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>

            {/* User Profile / Menu */}
            {activeUser ? (
              <div className="relative">
                <button
                  id="btn-user-profile-menu"
                  onClick={() => setShowUserDropdown(!showUserDropdown)}
                  className="flex items-center space-x-2 p-1 sm:px-2.5 sm:py-1.5 bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 rounded-xl text-xs text-white backdrop-blur-md transition-all"
                >
                  <div 
                    className="w-6 h-6 rounded-full flex items-center justify-center text-slate-950 font-extrabold text-[11px] shadow"
                    style={{ backgroundColor: themeConfig.colorHex }}
                  >
                    {activeUser.name.charAt(0).toUpperCase()}
                  </div>
                  <span className="font-semibold hidden sm:inline-block max-w-[90px] truncate">{activeUser.name}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* Dropdown Menu */}
                {showUserDropdown && (
                  <div className="absolute right-0 mt-2 w-64 bg-slate-900/98 backdrop-blur-2xl border border-white/20 rounded-2xl p-3 shadow-2xl z-50 animate-fadeIn text-xs">
                    <div className="pb-2.5 mb-2 border-b border-white/10">
                      <p className="font-bold text-white text-sm">{activeUser.name}</p>
                      <p className="text-slate-400 truncate text-[11px]">{activeUser.email}</p>
                      {activeUser.studyGoal && (
                        <p 
                          className="text-[10px] mt-1.5 font-medium px-2 py-0.5 rounded-md inline-block border"
                          style={{
                            backgroundColor: `${themeConfig.colorHex}20`,
                            color: themeConfig.colorHex,
                            borderColor: `${themeConfig.colorHex}40`
                          }}
                        >
                          🎯 {activeUser.studyGoal}
                        </p>
                      )}
                    </div>

                    {onOpenThemePicker && (
                      <button
                        onClick={() => {
                          setShowUserDropdown(false);
                          sounds.playClick();
                          onOpenThemePicker();
                        }}
                        className="w-full flex items-center space-x-2 px-3 py-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-xl transition-all mb-1"
                      >
                        <Palette className="w-4 h-4 text-amber-400" />
                        <span>Customize Theme Color</span>
                      </button>
                    )}

                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        sounds.playClick();
                        onLogout();
                      }}
                      className="w-full flex items-center space-x-2 px-3 py-2 text-rose-300 hover:text-white hover:bg-rose-500/20 rounded-xl transition-all"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Log Out / Switch Account</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                id="btn-nav-login"
                onClick={() => { sounds.playClick(); onOpenAuth(); }}
                className="px-3.5 py-1.5 rounded-xl text-xs font-bold text-slate-950 shadow-md transition-all hover:scale-105"
                style={{ backgroundColor: themeConfig.colorHex }}
              >
                Sign In
              </button>
            )}

            {/* Primary Action Button: + New AI Test */}
            <button
              id="btn-nav-create-test"
              onClick={() => { sounds.playClick(); onNewTestClick(); }}
              className="hidden sm:inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-950 shadow-lg shadow-amber-500/20 border border-white/20 transition-all hover:scale-105 active:scale-95"
              style={{
                background: `linear-gradient(135deg, ${themeConfig.colorHex}, ${themeConfig.secondaryHex})`,
              }}
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>New AI Test</span>
            </button>

          </div>

        </div>

        {/* Mobile Navigation Sub-bar */}
        <div className="flex lg:hidden overflow-x-auto py-2.5 space-x-2 border-t border-white/10 no-scrollbar">
          {navItems.map((item) => {
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => { sounds.playClick(); setCurrentTab(item.id); }}
                className={`whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive 
                    ? 'bg-white/20 text-white border border-white/30' 
                    : 'bg-white/5 text-slate-300 border border-white/10 hover:text-white'
                }`}
              >
                {item.label}
              </button>
            );
          })}

          {isTestActive && (
            <button
              onClick={() => { sounds.playClick(); setCurrentTab('test_session'); }}
              className="whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-bold bg-amber-500/30 text-amber-200 border border-amber-400/40 animate-pulse"
            >
              Active Test
            </button>
          )}
        </div>

      </div>
    </header>
  );
};
