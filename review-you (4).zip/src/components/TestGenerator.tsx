import React, { useState, useRef } from 'react';
import { 
  Sparkles, 
  BookOpen, 
  Timer, 
  Play, 
  AlertCircle, 
  Trash2, 
  GraduationCap, 
  FileText, 
  Search, 
  Image as ImageIcon, 
  X, 
  Download, 
  FolderDown, 
  Check,
  ChevronDown,
  ChevronUp,
  Lightbulb,
  Zap,
  Medal,
  Compass,
  ArrowRight,
  School,
  FileCheck2
} from 'lucide-react';
import { 
  Quiz, 
  DifficultyLevel, 
  QuestionType, 
  NotebookEntry, 
  StudyCategory 
} from '../types';
import { sounds } from '../lib/sound';
import { safeFetchJson } from '../lib/api';
import { PreTestStudyModal } from './PreTestStudyModal';
import { DeleteConfirmModal } from './DeleteConfirmModal';

interface TestGeneratorProps {
  quizzes: Quiz[];
  notebookEntries: NotebookEntry[];
  onStartQuiz: (quiz: Quiz) => void;
  onDeleteQuiz: (quizId: string) => void;
  onSaveNewQuiz: (quiz: Quiz) => void;
  initialTopic?: string;
  initialNoteId?: string;
}

// Curated high-yield downloadable test packages covering Grade 6 Middle School to AP / SAT
const PREBUILT_IMPORT_CATALOG: Array<{
  id: string;
  title: string;
  category: StudyCategory;
  subject: string;
  gradeLevel: string;
  difficulty: DifficultyLevel;
  questionCount: number;
  description: string;
  tags: string[];
  sampleQuestions: any[];
}> = [
  {
    id: 'import_grade6_patterns_and_equations',
    title: 'Patterns and Equations Unit Test (Grade 6)',
    category: 'test',
    subject: 'Mathematics',
    gradeLevel: 'Grade 6 (Middle School)',
    difficulty: 'medium',
    questionCount: 6,
    description: 'Master extending arithmetic sequences, discovering alternating pattern rules, writing terms from starting values, and solving one-step linear equations.',
    tags: ['Grade 6', 'Math', 'Patterns', 'Equations', 'Sequences'],
    sampleQuestions: [
      {
        id: 'pe_1',
        type: 'multiple_choice',
        question: 'Extend the pattern and state the pattern rule: 2, 5, 8, 11, __, __, __',
        options: [
          '14, 17, 20 (Rule: Add 3 each time)',
          '13, 15, 17 (Rule: Add 2 each time)',
          '15, 18, 21 (Rule: Add 4 each time)',
          '12, 14, 16 (Rule: Add 1 each time)'
        ],
        correctAnswer: '14, 17, 20 (Rule: Add 3 each time)',
        explanation: '• Core Rule: 5 - 2 = 3, 8 - 5 = 3, 11 - 8 = 3. Each step adds 3.\n• Next Terms: 11 + 3 = 14, 14 + 3 = 17, 17 + 3 = 20.\n• Test Day Tip: Check at least two consecutive differences to confirm constant step size.',
        hint: 'Find the difference between 5 and 2, 8 and 5.',
        topicTag: 'Arithmetic Patterns',
        timeLimitSeconds: 45
      },
      {
        id: 'pe_2',
        type: 'multiple_choice',
        question: 'Extend the pattern and state the pattern rule: 6, 10, 14, 18, __, __, __',
        options: [
          '22, 26, 30 (Rule: Add 4 each time)',
          '20, 22, 24 (Rule: Add 2 each time)',
          '24, 30, 36 (Rule: Add 6 each time)',
          '21, 24, 27 (Rule: Add 3 each time)'
        ],
        correctAnswer: '22, 26, 30 (Rule: Add 4 each time)',
        explanation: '• Core Rule: 10 - 6 = 4, 14 - 10 = 4, 18 - 14 = 4. Add 4 each time.\n• Next Terms: 18 + 4 = 22, 22 + 4 = 26, 26 + 4 = 30.',
        hint: 'Add 4 to the last term (18).',
        topicTag: 'Linear Number Patterns',
        timeLimitSeconds: 45
      },
      {
        id: 'pe_3',
        type: 'multiple_choice',
        question: 'Extend the alternating pattern: 25, 21, 23, 19, 21, __, __, __',
        options: [
          '17, 19, 15 (Rule: Subtract 4, then add 2)',
          '19, 17, 15 (Rule: Subtract 2 each time)',
          '18, 16, 14 (Rule: Subtract 3 each time)',
          '20, 22, 24 (Rule: Add 2 each time)'
        ],
        correctAnswer: '17, 19, 15 (Rule: Subtract 4, then add 2)',
        explanation: '• Core Rule: 25 - 4 = 21, 21 + 2 = 23, 23 - 4 = 19, 19 + 2 = 21. The pattern alternates -4, then +2.\n• Next Terms: 21 - 4 = 17, 17 + 2 = 19, 19 - 4 = 15.',
        hint: 'Notice the numbers alternate between decreasing and increasing.',
        topicTag: 'Alternating Operations',
        timeLimitSeconds: 45
      },
      {
        id: 'pe_4',
        type: 'multiple_choice',
        question: 'Extend the pattern: 4, 8, 7, 11, 10, __, __, __',
        options: [
          '14, 13, 17 (Rule: Add 4, then subtract 1)',
          '12, 14, 16 (Rule: Add 2 each time)',
          '15, 14, 18 (Rule: Add 5, subtract 1)',
          '11, 12, 13 (Rule: Add 1 each time)'
        ],
        correctAnswer: '14, 13, 17 (Rule: Add 4, then subtract 1)',
        explanation: '• Core Rule: 4 + 4 = 8, 8 - 1 = 7, 7 + 4 = 11, 11 - 1 = 10.\n• Next Terms: 10 + 4 = 14, 14 - 1 = 13, 13 + 4 = 17.',
        hint: 'First add 4, then subtract 1.',
        topicTag: 'Alternating Patterns',
        timeLimitSeconds: 45
      },
      {
        id: 'pe_5',
        type: 'multiple_choice',
        question: 'Write the first 4 terms of the pattern: Start at 4. Add 6 each time.',
        options: [
          '4, 10, 16, 22',
          '6, 12, 18, 24',
          '4, 8, 12, 16',
          '4, 14, 24, 34'
        ],
        correctAnswer: '4, 10, 16, 22',
        explanation: '• Term 1: 4 (starting value)\n• Term 2: 4 + 6 = 10\n• Term 3: 10 + 6 = 16\n• Term 4: 16 + 6 = 22.',
        hint: 'Start with 4, then add 6 three times.',
        topicTag: 'Pattern Generation',
        timeLimitSeconds: 40
      },
      {
        id: 'pe_6',
        type: 'multiple_choice',
        question: 'Write the first 4 terms of the pattern: Start at 2. Alternately add 6, then subtract 2.',
        options: [
          '2, 8, 6, 12',
          '2, 6, 8, 12',
          '2, 8, 14, 20',
          '2, 4, 6, 8'
        ],
        correctAnswer: '2, 8, 6, 12',
        explanation: '• Term 1: 2\n• Term 2: 2 + 6 = 8\n• Term 3: 8 - 2 = 6\n• Term 4: 6 + 6 = 12.',
        hint: '2 + 6 = 8, then 8 - 2 = 6, then 6 + 6 = 12.',
        topicTag: 'Pattern Generation',
        timeLimitSeconds: 40
      }
    ]
  },
  {
    id: 'import_grade6_math_fractions',
    title: 'Grade 6 Math: Fractions, Decimals & Pre-Algebra',
    category: 'test',
    subject: 'Mathematics',
    gradeLevel: 'Grade 6 (Middle School)',
    difficulty: 'medium',
    questionCount: 6,
    description: 'Master dividing fractions, converting decimals to percentages, finding greatest common factors, and solving 1-step equations.',
    tags: ['Grade 6', 'Math', 'Fractions', 'Middle School'],
    sampleQuestions: [
      {
        id: 'g6m_1',
        type: 'multiple_choice',
        question: 'What is 3/4 divided by 1/2?',
        options: ['1 1/2 (or 3/2)', '3/8', '2/3', '1/4'],
        correctAnswer: '1 1/2 (or 3/2)',
        explanation: 'To divide fractions, multiply by the reciprocal (flip the second fraction): 3/4 * 2/1 = 6/4 = 3/2 = 1 1/2.',
        hint: 'Keep, Change, Flip! Keep 3/4, change divide to multiply, flip 1/2 to 2/1.',
        topicTag: 'Fractions Division',
        timeLimitSeconds: 45
      },
      {
        id: 'g6m_2',
        type: 'multiple_choice',
        question: 'What is 0.65 written as a simplified fraction and as a percentage?',
        options: ['13/20 and 65%', '65/10 and 6.5%', '3/5 and 60%', '13/25 and 65%'],
        correctAnswer: '13/20 and 65%',
        explanation: '0.65 = 65/100. Divide top and bottom by 5 to simplify to 13/20. To get a percent, multiply by 100 to get 65%.',
        hint: '65 hundredths reduces by dividing by 5.',
        topicTag: 'Decimals to Fractions',
        timeLimitSeconds: 40
      },
      {
        id: 'g6m_3',
        type: 'true_false',
        question: 'True or False: The number 17 is a prime number because its only factors are 1 and 17.',
        options: ['True', 'False'],
        correctAnswer: 'True',
        explanation: 'A prime number is a whole number greater than 1 whose only factors are 1 and itself.',
        hint: 'Can any other number divide evenly into 17?',
        topicTag: 'Prime Numbers',
        timeLimitSeconds: 30
      },
      {
        id: 'g6m_4',
        type: 'short_answer',
        question: 'Solve for x: 3x + 5 = 20',
        correctAnswer: '5',
        explanation: 'Subtract 5 from both sides: 3x = 15. Divide by 3: x = 5.',
        hint: 'First subtract 5, then divide by 3.',
        topicTag: 'One-Step Equations',
        timeLimitSeconds: 45
      },
      {
        id: 'g6m_5',
        type: 'multiple_choice',
        question: 'What is the area of a triangle with a base of 8 cm and a height of 5 cm?',
        options: ['20 cm²', '40 cm²', '13 cm²', '26 cm²'],
        correctAnswer: '20 cm²',
        explanation: 'Area of triangle = (base * height) / 2 = (8 * 5) / 2 = 40 / 2 = 20 cm².',
        hint: 'Remember to divide the rectangle area by 2.',
        topicTag: 'Geometry Area',
        timeLimitSeconds: 45
      }
    ]
  },
  {
    id: 'import_grade6_science_earth',
    title: 'Middle School Science: Earth Systems, Solar System & Weather',
    category: 'test',
    subject: 'Science',
    gradeLevel: 'Grade 6–8 (Middle School)',
    difficulty: 'easy',
    questionCount: 5,
    description: 'Explore Earth’s rock cycle, tectonic plates, weather patterns, and planetary orbits in our solar system.',
    tags: ['Grade 6', 'Science', 'Earth Science', 'Space'],
    sampleQuestions: [
      {
        id: 'g6s_1',
        type: 'multiple_choice',
        question: 'Why do we have seasons (Summer, Fall, Winter, Spring) on Earth?',
        options: [
          'Because Earth is tilted on its axis as it orbits the Sun',
          'Because Earth gets physically closer to the Sun in the summer',
          'Because the Moon blocks sunlight during certain months',
          'Because the Sun burns hotter during July and August'
        ],
        correctAnswer: 'Because Earth is tilted on its axis as it orbits the Sun',
        explanation: 'Earth’s 23.5-degree axial tilt causes sunlight to strike hemispheres directly or indirectly as Earth revolves around the sun.',
        hint: 'Think about the tilt of Earth’s axis.',
        topicTag: 'Earth & Seasons',
        timeLimitSeconds: 40
      },
      {
        id: 'g6s_2',
        type: 'true_false',
        question: 'True or False: The Water Cycle includes evaporation, condensation, and precipitation.',
        options: ['True', 'False'],
        correctAnswer: 'True',
        explanation: 'Water evaporates into vapor, condenses into clouds, and falls back to Earth as precipitation (rain or snow).',
        hint: 'Recall the journey of water from oceans to clouds to rain.',
        topicTag: 'Water Cycle',
        timeLimitSeconds: 30
      },
      {
        id: 'g6s_3',
        type: 'multiple_choice',
        question: 'Which layer of Earth is the hottest and located in the very center?',
        options: ['Inner Core', 'Crust', 'Mantle', 'Atmosphere'],
        correctAnswer: 'Inner Core',
        explanation: 'The Inner Core is a dense, solid ball of mostly iron and nickel at the center of Earth, reaching temperatures over 5,000°C.',
        hint: 'It is at the deepest core of the planet.',
        topicTag: 'Earth Layers',
        timeLimitSeconds: 35
      }
    ]
  },
  {
    id: 'import_grade6_history_civilizations',
    title: 'Ancient Civilizations: Egypt, Mesopotamia & Greece',
    category: 'test',
    subject: 'History',
    gradeLevel: 'Grade 6 (Social Studies)',
    difficulty: 'medium',
    questionCount: 5,
    description: 'Test your knowledge on the Nile River, Hammurabi’s Code, hieroglyphics, the pyramids, and Athenian democracy.',
    tags: ['Grade 6', 'History', 'Social Studies', 'Ancient Egypt'],
    sampleQuestions: [
      {
        id: 'g6h_1',
        type: 'multiple_choice',
        question: 'Why was the Nile River called the "Gift of the Nile" by ancient historians?',
        options: [
          'Its annual flooding deposited fertile black silt allowing farming in the desert',
          'It flowed into gold mines located in the Mediterranean',
          'It was the only river in Africa with clean water',
          'It prevented all invaders from crossing into Egyptian lands'
        ],
        correctAnswer: 'Its annual flooding deposited fertile black silt allowing farming in the desert',
        explanation: 'Without the Nile’s predictable seasonal floods creating fertile soil for agriculture, civilization could not have thrived in the Egyptian desert.',
        hint: 'Think about farming and fertile soil in the desert.',
        topicTag: 'Ancient Egypt',
        timeLimitSeconds: 40
      },
      {
        id: 'g6h_2',
        type: 'true_false',
        question: 'True or False: The city-state of Athens in ancient Greece was known for inventing the world’s first direct democracy.',
        options: ['True', 'False'],
        correctAnswer: 'True',
        explanation: 'In ancient Athens, eligible citizens voted directly on laws and government policies in assemblies.',
        hint: 'Citizens voting on laws was a Greek innovation.',
        topicTag: 'Ancient Greece',
        timeLimitSeconds: 30
      }
    ]
  },
  {
    id: 'import_sat_math_official',
    title: 'SAT Math High-Yield Drill (Heart of Algebra & Geometry)',
    category: 'test',
    subject: 'Mathematics',
    gradeLevel: 'High School Junior / Senior',
    difficulty: 'medium',
    questionCount: 5,
    description: 'Covers linear systems, quadratic equations, circle geometry, exponential growth, and word problems modeled after official SAT exam patterns.',
    tags: ['SAT', 'Math', 'Algebra', 'College Board'],
    sampleQuestions: [
      {
        id: 'sm_1',
        type: 'multiple_choice',
        question: 'If 3x + 2y = 18 and 2x - y = 5, what is the value of x + y?',
        options: ['4', '5', '7', '9'],
        correctAnswer: '7',
        explanation: 'Multiply the second equation by 2: 4x - 2y = 10. Add to the first equation: 7x = 28, so x = 4. Substitute into 2(4) - y = 5 to get y = 3. Therefore, x + y = 4 + 3 = 7.',
        hint: 'Use the elimination method by doubling the second equation to cancel y.',
        topicTag: 'System of Linear Equations',
        timeLimitSeconds: 45
      },
      {
        id: 'sm_2',
        type: 'multiple_choice',
        question: 'In the xy-plane, the graph of y = (x - 4)^2 - 9 intersects the x-axis at points (a, 0) and (b, 0). What is the distance between these two intercepts?',
        options: ['3', '6', '8', '9'],
        correctAnswer: '6',
        explanation: 'Set y = 0: (x - 4)^2 - 9 = 0 => (x - 4)^2 = 9 => x - 4 = ±3. So x = 7 or x = 1. The distance between (1, 0) and (7, 0) is 7 - 1 = 6.',
        hint: 'Set y = 0 and solve for the roots of the vertex form parabola.',
        topicTag: 'Quadratic Functions',
        timeLimitSeconds: 45
      }
    ]
  },
  {
    id: 'import_apush_midterm',
    title: 'AP US History: Constitutional Era & Jacksonian Democracy',
    category: 'test',
    subject: 'History',
    gradeLevel: '11th Grade AP',
    difficulty: 'medium',
    questionCount: 5,
    description: 'Comprehensive APUSH preparation testing Federalist vs Anti-Federalist debates, Marbury v. Madison, and Reconstruction policies.',
    tags: ['APUSH', 'AP Exam', 'US History', 'College Board'],
    sampleQuestions: [
      {
        id: 'apush_1',
        type: 'multiple_choice',
        question: 'Which constitutional principle was definitively established by Chief Justice John Marshall in Marbury v. Madison (1803)?',
        options: [
          'Federal supremacy over state banking regulations',
          'The power of judicial review over congressional legislation',
          'The doctrine of executive privilege in diplomatic treaties',
          'State nullification rights under the 10th Amendment'
        ],
        correctAnswer: 'The power of judicial review over congressional legislation',
        explanation: 'In Marbury v. Madison (1803), Marshall established that Section 13 of the Judiciary Act of 1789 conflicted with Article III, asserting the Supreme Court’s authority to declare acts of Congress unconstitutional.',
        hint: 'Think about the Supreme Court checking congressional constitutionality.',
        topicTag: 'Supreme Court Rulings',
        timeLimitSeconds: 45
      }
    ]
  }
];

export const TestGenerator: React.FC<TestGeneratorProps> = ({
  quizzes,
  notebookEntries,
  onStartQuiz,
  onDeleteQuiz,
  onSaveNewQuiz,
  initialTopic = '',
  initialNoteId = '',
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'import' | 'library'>('create');
  const [studyQuiz, setStudyQuiz] = useState<Quiz | null>(null);
  const [quizToDelete, setQuizToDelete] = useState<Quiz | null>(null);

  // Simplified Form State
  const [testName, setTestName] = useState<string>(initialTopic || '');
  const [gradeLevel, setGradeLevel] = useState<string>('Grade 6–8 (Middle School)');
  const [category, setCategory] = useState<StudyCategory>('test');
  const [difficulty, setDifficulty] = useState<DifficultyLevel>('medium');
  const [questionCount, setQuestionCount] = useState<number>(5);
  const [questionTypes, setQuestionTypes] = useState<QuestionType[]>(['multiple_choice', 'true_false', 'short_answer']);
  
  // Advanced & Review details (Clean collapsible)
  const [showAdvancedOptions, setShowAdvancedOptions] = useState(false);
  const [learningGoals, setLearningGoals] = useState<string>('');
  const [selectedNoteId, setSelectedNoteId] = useState<string>(initialNoteId || '');
  const [reviewQuestionsText, setReviewQuestionsText] = useState<string>('');
  const [reviewImage, setReviewImage] = useState<{ data: string; mimeType: string; fileName: string; sizeKb: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // UI status
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [importSearch, setImportSearch] = useState<string>('');
  const [importGradeFilter, setImportGradeFilter] = useState<string>('all');
  const [justImportedId, setJustImportedId] = useState<string | null>(null);
  const [librarySearch, setLibrarySearch] = useState<string>('');

  // Quick Preset Selector for topic inspiration
  const handleQuickTopic = (topic: string, grade: string, cat: StudyCategory = 'test') => {
    sounds.playClick();
    setTestName(topic);
    setGradeLevel(grade);
    setCategory(cat);
    setGenerationError(null);
  };

  // Image Upload handler
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setGenerationError('Please upload an image file (PNG, JPG, WEBP).');
      return;
    }

    if (file.size > 8 * 1024 * 1024) {
      setGenerationError('Image size exceeds 8MB. Please pick a smaller photo.');
      return;
    }

    sounds.playClick();
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      setReviewImage({
        data: base64,
        mimeType: file.type,
        fileName: file.name,
        sizeKb: Math.round(file.size / 1024),
      });
      setGenerationError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveImage = () => {
    sounds.playClick();
    setReviewImage(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const toggleQuestionType = (type: QuestionType) => {
    sounds.playClick();
    if (questionTypes.includes(type)) {
      if (questionTypes.length > 1) {
        setQuestionTypes(questionTypes.filter(t => t !== type));
      }
    } else {
      setQuestionTypes([...questionTypes, type]);
    }
  };

  // Generate Test & Open Pre-Test Study Guide
  const handleGenerateAndStart = async (e: React.FormEvent) => {
    e.preventDefault();
    setGenerationError(null);

    let notesContent = '';
    if (selectedNoteId) {
      const foundNote = notebookEntries.find(n => n.id === selectedNoteId);
      if (foundNote) {
        notesContent = foundNote.content;
      }
    }

    const hasImage = Boolean(reviewImage);
    const hasQuestions = Boolean(reviewQuestionsText && reviewQuestionsText.trim().length > 0);
    const hasNotes = Boolean(notesContent && notesContent.trim().length > 0);

    // CRITICAL USER MANDATE: Cannot make a test without adding questions or picture
    if (!hasImage && !hasQuestions && !hasNotes) {
      setGenerationError('You cannot make a test without adding the questions or uploading a photo of the test. Please upload a photo of your test sheet or paste/type your questions.');
      sounds.playIncorrect();
      document.getElementById('section-test-questions')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }

    let actualName = testName.trim();
    if (!actualName) {
      if (hasImage && reviewImage?.fileName) {
        actualName = reviewImage.fileName.replace(/\.[^/.]+$/, '').replace(/[_-]/g, ' ');
      } else if (hasQuestions) {
        // Extract first line or clean title from questions
        const firstLine = reviewQuestionsText.trim().split('\n')[0].replace(/^(\d+[\.\)]\s*|[a-zA-Z][\.\)]\s*)/, '').substring(0, 40);
        actualName = firstLine.length > 5 ? `${firstLine} Test` : 'Practice Review Test';
      } else {
        actualName = 'Custom Practice Test';
      }
    }

    setIsGenerating(true);
    sounds.playClick();

    try {
      const data = await safeFetchJson<{ quiz: Quiz; notice?: string }>('/api/generate-quiz', {
        method: 'POST',
        body: JSON.stringify({
          category,
          testName: actualName,
          gradeLevel,
          learningTopic: learningGoals.trim() || actualName,
          subject: category === 'book' ? 'Literature' : 'Academic Study',
          difficulty,
          questionCount,
          questionTypes,
          notesContent,
          reviewQuestionsText: reviewQuestionsText.trim(),
          reviewImage: reviewImage ? { data: reviewImage.data, mimeType: reviewImage.mimeType } : null,
        }),
      });

      if (data && data.quiz) {
        const fullQuiz: Quiz = {
          ...data.quiz,
          studyCategory: category,
          gradeLevel,
          learningGoals: learningGoals.trim() || actualName,
        };

        sounds.playCorrect();
        onSaveNewQuiz(fullQuiz);
        setStudyQuiz(fullQuiz);
      } else {
        throw new Error('Could not generate the test. Please try again.');
      }
    } catch (err: any) {
      console.error('Quiz generation error:', err);
      sounds.playIncorrect();
      setGenerationError(err?.message || 'Could not generate test. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handle1ClickImport = (pkg: typeof PREBUILT_IMPORT_CATALOG[0]) => {
    sounds.playCorrect();

    const newQuiz: Quiz = {
      id: `imported_${Date.now()}_${pkg.id}`,
      title: pkg.title,
      description: pkg.description,
      subject: pkg.subject,
      studyCategory: pkg.category,
      gradeLevel: pkg.gradeLevel,
      learningGoals: pkg.tags.join(', '),
      difficulty: pkg.difficulty,
      questions: pkg.sampleQuestions.map((q, idx) => ({
        ...q,
        id: `imp_q_${Date.now()}_${idx + 1}`,
      })),
      createdAt: new Date().toISOString(),
    };

    onSaveNewQuiz(newQuiz);
    setJustImportedId(newQuiz.id);
  };

  const filteredImports = PREBUILT_IMPORT_CATALOG.filter(item => {
    const matchesSearch = item.title.toLowerCase().includes(importSearch.toLowerCase()) ||
      item.subject.toLowerCase().includes(importSearch.toLowerCase()) ||
      item.tags.some(t => t.toLowerCase().includes(importSearch.toLowerCase()));
    
    const matchesGrade = importGradeFilter === 'all' || 
      (importGradeFilter === 'middle' && item.gradeLevel.includes('Grade 6')) ||
      (importGradeFilter === 'high' && (item.gradeLevel.includes('High School') || item.gradeLevel.includes('11th'))) ||
      (importGradeFilter === 'cert' && item.category === 'certificate');

    return matchesSearch && matchesGrade;
  });

  const filteredLibrary = quizzes.filter(q => 
    q.title.toLowerCase().includes(librarySearch.toLowerCase()) ||
    q.subject.toLowerCase().includes(librarySearch.toLowerCase()) ||
    (q.gradeLevel && q.gradeLevel.toLowerCase().includes(librarySearch.toLowerCase()))
  );

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      
      {/* Top 3 Tabs Bar */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex p-1.5 bg-slate-900/90 border border-white/15 rounded-2xl backdrop-blur-xl shadow-xl w-full sm:w-auto">
          
          <button
            id="tab-create-test"
            onClick={() => { sounds.playClick(); setActiveTab('create'); }}
            className={`flex-1 sm:flex-initial flex items-center justify-center space-x-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'create'
                ? 'bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 border border-amber-300'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-4 h-4 text-slate-950" />
            <span>Make a Test</span>
          </button>

          <button
            id="tab-import-test"
            onClick={() => { sounds.playClick(); setActiveTab('import'); }}
            className={`flex-1 sm:flex-initial flex items-center justify-center space-x-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'import'
                ? 'bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 border border-amber-300'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <FolderDown className="w-4 h-4 text-slate-950" />
            <span>Sample Tests</span>
          </button>

          <button
            id="tab-library"
            onClick={() => { sounds.playClick(); setActiveTab('library'); }}
            className={`flex-1 sm:flex-initial flex items-center justify-center space-x-2 px-5 py-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'library'
                ? 'bg-amber-400 text-slate-950 shadow-lg shadow-amber-500/20 border border-amber-300'
                : 'text-slate-300 hover:text-white hover:bg-white/5'
            }`}
          >
            <BookOpen className="w-4 h-4 text-slate-950" />
            <span>My Tests ({quizzes.length})</span>
          </button>

        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* TAB 1: MAKE A TEST (Clean, Spacious, Friendly for Grade 6 to College) */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'create' && (
        <div className="space-y-6 animate-fadeIn">
          
          {/* Header Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border border-white/15 shadow-xl">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-400/10 text-amber-300 border border-amber-400/25 text-xs font-semibold mb-2">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>AI Practice & Test Prep</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
                  Make a Practice Test
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                  Type any topic or school subject. Review You will create a practice test with full study explanations!
                </p>
              </div>

              {/* Friendly Quick Inspiration Topics */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  Click for 1-Click Ideas:
                </span>
                <div className="flex flex-wrap gap-1.5 max-w-md">
                  <button
                    type="button"
                    onClick={() => handleQuickTopic('6th Grade Fractions & Decimals', 'Grade 6–8 (Middle School)')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-amber-400/20 text-slate-200 hover:text-amber-200 text-xs border border-white/10 transition-all"
                  >
                    🎒 6th Grade Math
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickTopic('Earth Systems & Solar System', 'Grade 6–8 (Middle School)')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-emerald-400/20 text-slate-200 hover:text-emerald-200 text-xs border border-white/10 transition-all"
                  >
                    🌍 Space & Earth
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickTopic('Ancient Egypt & Civilizations', 'Grade 6–8 (Middle School)')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-indigo-400/20 text-slate-200 hover:text-indigo-200 text-xs border border-white/10 transition-all"
                  >
                    🏛️ Ancient Egypt
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickTopic('Cellular Biology & Photosynthesis', 'High School (9–12)')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-purple-400/20 text-slate-200 hover:text-purple-200 text-xs border border-white/10 transition-all"
                  >
                    🧬 Biology
                  </button>
                  <button
                    type="button"
                    onClick={() => handleQuickTopic('SAT Math Heart of Algebra', 'High School (9–12)')}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-amber-400/20 text-slate-200 hover:text-amber-200 text-xs border border-white/10 transition-all"
                  >
                    📐 SAT Math
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Generation Error Alert */}
          {generationError && (
            <div className="p-4 bg-rose-500/20 border border-rose-400/40 rounded-2xl flex items-start space-x-3 text-rose-200 text-sm backdrop-blur-md">
              <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
              <span>{generationError}</span>
            </div>
          )}

          {/* Main Form */}
          <form onSubmit={handleGenerateAndStart} className="space-y-6">
            
            {/* STEP 1 (MANDATORY): Add Test Questions or Upload Worksheet Photo */}
            <div id="section-test-questions" className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border border-amber-400/30 shadow-xl space-y-5">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[11px] font-extrabold uppercase tracking-wider">
                      Step 1 • Required
                    </span>
                    <h2 className="text-base sm:text-lg font-black text-white">
                      Add Your Test Questions or Test Sheet Photo
                    </h2>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">
                    Upload a photo of your worksheet or type/paste the questions. Review You needs your questions to build your practice test.
                  </p>
                </div>

                {/* Status Indicator Pill */}
                {reviewImage || reviewQuestionsText.trim() || selectedNoteId ? (
                  <div className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-bold self-start sm:self-auto">
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>
                      {reviewImage
                        ? '📷 Test Sheet Photo Attached'
                        : `${reviewQuestionsText.split('\n').filter(l => l.trim().length > 0).length || 1} Question(s) Ready`}
                    </span>
                  </div>
                ) : (
                  <div className="inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-xl bg-rose-500/15 border border-rose-400/30 text-rose-300 text-xs font-bold self-start sm:self-auto">
                    <AlertCircle className="w-4 h-4 text-rose-400" />
                    <span>Questions Required</span>
                  </div>
                )}
              </div>

              {/* Upload Photo & Paste Questions Options */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                
                {/* Method A: Upload Photo */}
                <div className="space-y-2 flex flex-col justify-between">
                  <div>
                    <label className="block text-xs font-bold text-slate-200 uppercase tracking-wider mb-1">
                      📷 Option A: Upload Test Sheet Photo
                    </label>
                    <p className="text-[11px] text-slate-400 mb-2">
                      Take a photo or upload an image of your quiz, worksheet, or study guide.
                    </p>
                  </div>

                  {!reviewImage ? (
                    <div
                      onClick={() => fileInputRef.current?.click()}
                      className="p-6 rounded-2xl border-2 border-dashed border-white/20 hover:border-amber-400 bg-white/[0.03] hover:bg-amber-400/5 cursor-pointer transition-all text-center flex flex-col items-center justify-center space-y-2 group min-h-[140px]"
                    >
                      <div className="w-10 h-10 rounded-xl bg-white/10 group-hover:bg-amber-400/20 flex items-center justify-center text-slate-300 group-hover:text-amber-300 transition-colors">
                        <ImageIcon className="w-5 h-5" />
                      </div>
                      <div className="text-xs font-bold text-white group-hover:text-amber-300">
                        Click or drop your worksheet photo
                      </div>
                      <div className="text-[10px] text-slate-400">
                        Supports JPG, PNG up to 8MB
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 rounded-2xl bg-slate-950 border border-amber-400/40 flex items-center justify-between gap-3 min-h-[140px]">
                      <div className="flex items-center space-x-3 min-w-0">
                        <img
                          src={reviewImage.data}
                          alt="Worksheet Preview"
                          className="w-16 h-16 rounded-xl object-cover border border-white/20 flex-shrink-0 shadow-md"
                        />
                        <div className="min-w-0">
                          <div className="font-bold text-xs text-white truncate">{reviewImage.fileName}</div>
                          <div className="text-[11px] text-amber-300 font-semibold">{reviewImage.sizeKb} KB</div>
                          <div className="text-[10px] text-emerald-400 mt-0.5">✓ Ready for question extraction</div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={handleRemoveImage}
                        title="Remove worksheet image"
                        className="p-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-white border border-rose-400/30 transition-colors"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  )}

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleImageFileChange}
                    className="hidden"
                  />
                </div>

                {/* Method B: Paste / Type Questions */}
                <div className="space-y-2 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="block text-xs font-bold text-slate-200 uppercase tracking-wider">
                        ✍️ Option B: Paste or Type Test Questions
                      </label>
                      {reviewQuestionsText.trim() && (
                        <span className="text-[10px] font-mono text-amber-300">
                          {reviewQuestionsText.split('\n').filter(Boolean).length} lines
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 mb-2">
                      Paste homework problems, number sequences, or study questions.
                    </p>
                  </div>

                  <textarea
                    rows={4}
                    value={reviewQuestionsText}
                    onChange={(e) => setReviewQuestionsText(e.target.value)}
                    placeholder="1. Extend the pattern: 2, 5, 8, 11, __, __, __ (Rule: Add 3)&#10;2. Write the first 4 terms: Start at 4. Add 6 each time.&#10;3. Solve for x: 3x + 5 = 20"
                    className="w-full h-full min-h-[140px] px-3.5 py-2.5 bg-white/5 border border-white/15 focus:border-amber-400 focus:outline-none rounded-2xl text-white placeholder-slate-500 text-xs font-mono transition-all"
                  />
                </div>

              </div>

              {/* Method C: Notebook Link (if notes exist) */}
              {notebookEntries.length > 0 && (
                <div className="pt-3 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center space-x-2 text-xs font-bold text-slate-300">
                    <BookOpen className="w-4 h-4 text-indigo-400" />
                    <span>Or attach a saved note from your Study Notebook:</span>
                  </div>
                  <select
                    value={selectedNoteId}
                    onChange={(e) => {
                      sounds.playClick();
                      setSelectedNoteId(e.target.value);
                    }}
                    className="px-3 py-2 rounded-xl bg-white/5 border border-white/15 text-xs text-slate-200 focus:border-amber-400 focus:outline-none min-w-[200px]"
                  >
                    <option value="">-- None (Use Photo or Text Above) --</option>
                    {notebookEntries.map((n) => (
                      <option key={n.id} value={n.id}>
                        {n.title} ({n.subject})
                      </option>
                    ))}
                  </select>
                </div>
              )}

            </div>

            {/* STEP 2: Topic & Grade Level */}
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border border-white/15 shadow-xl space-y-6">
              
              <div className="space-y-2">
                <label htmlFor="input-test-name" className="block text-sm font-bold text-white uppercase tracking-wider">
                  2. Test Name or Subject Topic:
                </label>
                <div className="relative">
                  <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                  <input
                    id="input-test-name"
                    type="text"
                    placeholder="e.g. Patterns and Equations Unit Test, 6th Grade Math, Solar System, or Biology..."
                    value={testName}
                    onChange={(e) => setTestName(e.target.value)}
                    className="w-full pl-12 pr-4 py-3.5 bg-white/5 border border-white/15 focus:border-amber-400 focus:outline-none rounded-2xl text-white placeholder-slate-500 text-sm sm:text-base transition-all"
                  />
                </div>
              </div>

              {/* Grade Level Selector Buttons */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                  Select Your Grade Level:
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {[
                    { label: 'Grade 6–8 (Middle School)', icon: '🎒', desc: 'Ages 11–14' },
                    { label: 'High School (9–12)', icon: '🎓', desc: 'Ages 14–18' },
                    { label: 'College / AP Prep', icon: '🏛️', desc: 'Advanced & Honors' },
                    { label: 'General / Career', icon: '💼', desc: 'Skills & Certs' },
                  ].map((lvl) => {
                    const isSelected = gradeLevel === lvl.label;
                    return (
                      <button
                        key={lvl.label}
                        type="button"
                        onClick={() => {
                          sounds.playClick();
                          setGradeLevel(lvl.label);
                        }}
                        className={`p-3.5 rounded-2xl border text-left transition-all ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950 font-bold border-amber-300 shadow-md ring-2 ring-amber-400'
                            : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        <div className="text-xl mb-1">{lvl.icon}</div>
                        <div className={`text-xs font-bold ${isSelected ? 'text-slate-950' : 'text-white'}`}>
                          {lvl.label}
                        </div>
                        <div className={`text-[11px] ${isSelected ? 'text-slate-800' : 'text-slate-400'}`}>
                          {lvl.desc}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

            </div>

            {/* STEP 3: Quick Settings (Difficulty & Question Count) */}
            <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border border-white/15 shadow-xl space-y-6">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Difficulty Selector */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                    3. Choose Difficulty:
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'easy' as DifficultyLevel, label: 'Easy', emoji: '🟢', desc: 'Basics & Foundation' },
                      { id: 'medium' as DifficultyLevel, label: 'Medium', emoji: '🟡', desc: 'Standard Practice' },
                      { id: 'hard' as DifficultyLevel, label: 'Hard', emoji: '🔴', desc: 'Exam Challenge' },
                    ].map((d) => (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() => { sounds.playClick(); setDifficulty(d.id); }}
                        className={`p-3 rounded-2xl border text-center transition-all ${
                          difficulty === d.id
                            ? 'bg-amber-400 text-slate-950 font-bold border-amber-300 shadow-md ring-2 ring-amber-400'
                            : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        <div className="text-sm">{d.emoji} {d.label}</div>
                        <div className={`text-[10px] mt-0.5 ${difficulty === d.id ? 'text-slate-900 font-medium' : 'text-slate-400'}`}>
                          {d.desc}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Question Count Selector */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider">
                      4. Question Length:
                    </label>
                    <span className="text-xs font-bold text-amber-300 px-2.5 py-0.5 bg-amber-400/10 rounded-full border border-amber-400/30">
                      {questionCount} Questions
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { count: 5, label: '5 Questions', time: '~5 min drill' },
                      { count: 10, label: '10 Questions', time: '~10 min test' },
                      { count: 15, label: '15 Questions', time: '~20 min exam' },
                    ].map((item) => (
                      <button
                        key={item.count}
                        type="button"
                        onClick={() => { sounds.playClick(); setQuestionCount(item.count); }}
                        className={`p-3 rounded-2xl border text-center transition-all ${
                          questionCount === item.count
                            ? 'bg-amber-400 text-slate-950 font-bold border-amber-300 shadow-md ring-2 ring-amber-400'
                            : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:text-white'
                        }`}
                      >
                        <div className="text-xs font-bold">{item.label}</div>
                        <div className={`text-[10px] mt-0.5 ${questionCount === item.count ? 'text-slate-900 font-medium' : 'text-slate-400'}`}>
                          {item.time}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

              </div>

              {/* Question Formats Pills */}
              <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <span className="text-xs font-bold text-slate-300">Question Types:</span>
                <div className="flex items-center gap-2 flex-wrap">
                  {[
                    { id: 'multiple_choice' as QuestionType, label: 'Multiple Choice' },
                    { id: 'true_false' as QuestionType, label: 'True / False' },
                    { id: 'short_answer' as QuestionType, label: 'Short Answer' },
                  ].map((t) => {
                    const isSelected = questionTypes.includes(t.id);
                    return (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => toggleQuestionType(t.id)}
                        className={`px-3 py-1.5 rounded-xl border text-xs font-semibold flex items-center space-x-1.5 transition-all ${
                          isSelected
                            ? 'bg-white/15 border-white/30 text-white font-bold'
                            : 'bg-white/5 border-white/10 text-slate-500 hover:text-slate-300'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 text-amber-400" />}
                        <span>{t.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

            </div>

            {/* Primary Action Button */}
            <div className="pt-2">
              <button
                id="btn-generate-start-test"
                type="submit"
                disabled={isGenerating}
                className="w-full py-4 sm:py-5 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-2xl font-black text-base sm:text-lg shadow-2xl shadow-amber-500/20 flex items-center justify-center space-x-3 transition-all hover:scale-[1.01] active:scale-[0.99] disabled:opacity-50 border border-amber-300 cursor-pointer"
              >
                {isGenerating ? (
                  <>
                    <div className="w-5 h-5 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                    <span>Creating your practice test & study guide from your questions...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-5 h-5 fill-slate-950" />
                    <span>Create Practice Test & Study Guide</span>
                  </>
                )}
              </button>
            </div>

          </form>

        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 2: SAMPLE TESTS (1-Click Sample Library) */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'import' && (
        <div className="space-y-6 animate-fadeIn">
          
          {/* Header */}
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border border-white/15 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-400/25 text-xs font-semibold mb-2">
                  <FolderDown className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Curated Sample Library</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
                  Sample Practice Tests
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                  Pick any pre-made practice test below. Download with 1-click and study immediately!
                </p>
              </div>

              {/* Search input */}
              <div className="relative w-full sm:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search Grade 6, Math, History, SAT..."
                  value={importSearch}
                  onChange={(e) => setImportSearch(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/15 focus:border-amber-400 focus:outline-none rounded-xl text-white placeholder-slate-500 text-xs"
                />
              </div>
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-2 mt-6 overflow-x-auto pb-1 no-scrollbar">
              {[
                { id: 'all', label: 'All Sample Tests' },
                { id: 'middle', label: '🎒 Grade 6–8 (Middle School)' },
                { id: 'high', label: '🎓 High School & SAT' },
                { id: 'cert', label: '💼 Professional Certs' },
              ].map((pill) => (
                <button
                  key={pill.id}
                  onClick={() => { sounds.playClick(); setImportGradeFilter(pill.id); }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    importGradeFilter === pill.id
                      ? 'bg-amber-400 text-slate-950 font-bold border border-amber-300 shadow-sm'
                      : 'bg-white/5 text-slate-300 hover:text-white border border-white/10'
                  }`}
                >
                  {pill.label}
                </button>
              ))}
            </div>
          </div>

          {/* Test Catalog Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredImports.map((pkg) => {
              const isJustImported = justImportedId === pkg.id || quizzes.some(q => q.title === pkg.title);
              return (
                <div
                  key={pkg.id}
                  className="p-6 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border border-white/15 shadow-xl flex flex-col justify-between space-y-4 hover:border-amber-400/40 transition-all group"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-lg bg-amber-400/15 text-amber-300 border border-amber-400/30">
                        {pkg.subject}
                      </span>
                      <div className="flex items-center space-x-2 text-xs text-slate-400">
                        <span className="capitalize px-2 py-0.5 rounded-md bg-white/10 font-medium">
                          {pkg.difficulty}
                        </span>
                        <span>{pkg.questionCount} Qs</span>
                      </div>
                    </div>

                    <h3 className="text-lg font-bold text-white group-hover:text-amber-300 transition-colors">
                      {pkg.title}
                    </h3>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {pkg.description}
                    </p>

                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {pkg.tags.map((tag) => (
                        <span key={tag} className="text-[10px] px-2 py-0.5 bg-white/5 border border-white/10 rounded-md text-slate-400 font-medium">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-3">
                    <span className="text-xs text-slate-400 font-medium">
                      {pkg.gradeLevel}
                    </span>

                    <button
                      type="button"
                      onClick={() => handle1ClickImport(pkg)}
                      className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
                        isJustImported
                          ? 'bg-emerald-600 text-white shadow-md'
                          : 'bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold shadow-lg shadow-amber-500/20'
                      }`}
                    >
                      {isJustImported ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>Added to Library</span>
                        </>
                      ) : (
                        <>
                          <Download className="w-4 h-4" />
                          <span>Download & Practice</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* ------------------------------------------------------------- */}
      {/* TAB 3: MY TEST LIBRARY */}
      {/* ------------------------------------------------------------- */}
      {activeTab === 'library' && (
        <div className="space-y-6 animate-fadeIn">
          
          {/* Header & Search */}
          <div className="p-6 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border border-white/15 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white">Your Saved Tests</h2>
              <p className="text-xs text-slate-400">
                You have {quizzes.length} practice tests ready to study.
              </p>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search saved tests..."
                value={librarySearch}
                onChange={(e) => setLibrarySearch(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/15 focus:border-amber-400 focus:outline-none rounded-xl text-white placeholder-slate-500 text-xs"
              />
            </div>
          </div>

          {/* Quizzes Grid */}
          {filteredLibrary.length === 0 ? (
            <div className="p-12 text-center rounded-3xl bg-slate-900/40 border border-white/10 space-y-4">
              <BookOpen className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="text-lg font-bold text-white">No Saved Tests Yet</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Create a test using the "Make a Test" tab or pick a ready-to-use one from "Sample Tests".
              </p>
              <button
                type="button"
                onClick={() => { sounds.playClick(); setActiveTab('create'); }}
                className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20"
              >
                Make My First Practice Test
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredLibrary.map((quiz) => (
                <div
                  key={quiz.id}
                  className="p-5 rounded-3xl bg-slate-900/80 backdrop-blur-2xl border border-white/15 shadow-xl flex flex-col justify-between space-y-4 hover:border-amber-400/40 transition-all"
                >
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-400/15 text-amber-300 border border-amber-400/30">
                        {quiz.subject || 'Academic'}
                      </span>
                      <span className="text-xs text-slate-400 font-medium">
                        {quiz.questions.length} Questions
                      </span>
                    </div>

                    <h4 className="font-bold text-base text-white line-clamp-1">{quiz.title}</h4>
                    <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">{quiz.description}</p>

                    {quiz.bestScore !== undefined && (
                      <div className="p-2.5 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between text-xs">
                        <span className="text-slate-400">Best Score:</span>
                        <span className="font-bold text-emerald-400">{quiz.bestScore}%</span>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        sounds.playClick();
                        setQuizToDelete(quiz);
                      }}
                      className="p-2.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 border border-transparent hover:border-rose-400/20 transition-all"
                      title="Delete Test"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>

                    <button
                      type="button"
                      onClick={() => { sounds.playClick(); setStudyQuiz(quiz); }}
                      className="px-3 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 font-bold text-xs border border-white/10 flex items-center justify-center space-x-1.5 transition-all"
                      title="Read study guide before testing"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>Study Guide</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => { sounds.playClick(); setStudyQuiz(quiz); }}
                      className="flex-1 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center space-x-1.5 transition-all"
                    >
                      <Play className="w-3.5 h-3.5 fill-slate-950" />
                      <span>Start Test</span>
                    </button>
                  </div>

                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {/* Pre-Test Study & Answer Learning Modal */}
      <PreTestStudyModal
        quiz={studyQuiz}
        isOpen={!!studyQuiz}
        onClose={() => setStudyQuiz(null)}
        onDeleteQuiz={(id) => {
          onDeleteQuiz(id);
          setStudyQuiz(null);
        }}
        onStartTest={(q) => {
          setStudyQuiz(null);
          onStartQuiz(q);
        }}
      />

      {/* Delete Test Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={!!quizToDelete}
        itemType="test"
        itemTitle={quizToDelete?.title || 'Practice Test'}
        onConfirm={() => {
          if (quizToDelete) {
            sounds.playClick();
            onDeleteQuiz(quizToDelete.id);
            setQuizToDelete(null);
          }
        }}
        onCancel={() => setQuizToDelete(null)}
      />

    </div>
  );
};
