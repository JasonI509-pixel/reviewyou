import React, { useState } from 'react';
import { 
  Sparkles, 
  User, 
  Mail, 
  ArrowRight, 
  CheckCircle2, 
  Lock, 
  GraduationCap, 
  BookOpen, 
  Timer, 
  Target,
  AlertCircle,
  X,
  FileCheck2,
  Medal,
  Compass,
  Check,
  ChevronLeft,
  Palette
} from 'lucide-react';
import { UserAccount } from '../types';
import { 
  createAccount, 
  loginUser, 
  registerAccountCrossDevice, 
  loginAccountCrossDevice 
} from '../lib/storage';
import { sounds } from '../lib/sound';
import { Logo } from './Logo';
import { ThemeColor, THEMES } from '../lib/theme';

interface AuthModalProps {
  onAuthenticated: (user: UserAccount) => void;
  isOpen: boolean;
  onClose?: () => void;
  initialMode?: 'signup' | 'login';
}

const USE_CASE_OPTIONS = [
  { id: 'ap_highschool', title: 'AP & High School Exams', desc: 'AP Bio, APUSH, Calc, Literature, Physics', icon: GraduationCap },
  { id: 'standardized_tests', title: 'Standardized Tests', desc: 'SAT, ACT, GRE, MCAT, LSAT entrance prep', icon: FileCheck2 },
  { id: 'certifications', title: 'Professional Certifications', desc: 'AWS, CompTIA Security+, PMP, BLS / CPR', icon: Medal },
  { id: 'college_courses', title: 'College & University Courses', desc: 'Undergrad & Grad midterms, finals & labs', icon: BookOpen },
  { id: 'book_reviews', title: 'Book Reviews & Literature', desc: 'Novels, chapter analyses, themes & quotes', icon: BookOpen },
  { id: 'skill_building', title: 'Skill & Language Mastery', desc: 'Coding algorithms, Spanish, Economics', icon: Compass },
];

const GRADE_LEVELS = [
  'Kindergarten',
  'Primary',
  'Middle School',
  'High School',
  'College',
  'University+'
];

export const AuthModal: React.FC<AuthModalProps> = ({ 
  onAuthenticated, 
  isOpen, 
  onClose,
  initialMode = 'signup' 
}) => {
  const [mode, setMode] = useState<'signup' | 'login'>(initialMode);
  const [signupStep, setSignupStep] = useState<1 | 2 | 3>(1);

  // Step 1: Account credentials
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Step 2: What are you going to use Review You for?
  const [selectedUseCases, setSelectedUseCases] = useState<string[]>(['ap_highschool', 'standardized_tests']);

  // Step 3: Academic details & Study focus & Theme Color
  const [selectedGrade, setSelectedGrade] = useState('High School');
  const [targetSubjects, setTargetSubjects] = useState('Biology, US History & Literature');
  const [dailyGoalMinutes, setDailyGoalMinutes] = useState<number>(30);
  const [selectedTheme, setSelectedTheme] = useState<ThemeColor>('gold');

  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const toggleUseCase = (id: string) => {
    sounds.playClick();
    if (selectedUseCases.includes(id)) {
      if (selectedUseCases.length > 1) {
        setSelectedUseCases(selectedUseCases.filter(u => u !== id));
      }
    } else {
      setSelectedUseCases([...selectedUseCases, id]);
    }
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (signupStep === 1) {
      if (!name.trim()) {
        setError('Please enter your full name.');
        sounds.playIncorrect();
        return;
      }
      if (!email.trim() || !email.includes('@')) {
        setError('Please enter a valid email address.');
        sounds.playIncorrect();
        return;
      }
      if (!password || password.length < 4) {
        setError('Please enter a password with at least 4 characters.');
        sounds.playIncorrect();
        return;
      }
      sounds.playClick();
      setSignupStep(2);
    } else if (signupStep === 2) {
      if (selectedUseCases.length === 0) {
        setError('Please select at least one way you plan to use Review You.');
        sounds.playIncorrect();
        return;
      }
      sounds.playClick();
      setSignupStep(3);
    } else if (signupStep === 3) {
      handleCompleteSignup();
    }
  };

  const handleCompleteSignup = async () => {
    setIsSubmitting(true);
    sounds.playClick();
    setError(null);

    try {
      if (!password || password.length < 4) {
        throw new Error('Please enter a secure password of at least 4 characters.');
      }

      const selectedLabels = USE_CASE_OPTIONS
        .filter(u => selectedUseCases.includes(u.id))
        .map(u => u.title)
        .join(', ');

      const user = await registerAccountCrossDevice({
        name: name.trim(),
        email: email.trim(),
        password: password,
        studyGoal: `${selectedLabels} (${selectedGrade})`,
        targetExam: targetSubjects.trim() || 'General Exams',
        themeColor: selectedTheme,
      });

      sounds.playCorrect();
      onAuthenticated(user);
    } catch (err: any) {
      sounds.playIncorrect();
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsSubmitting(true);
    sounds.playClick();

    try {
      if (!email.trim()) {
        throw new Error('Please enter your email address.');
      }
      if (!password) {
        throw new Error('Please enter your account password.');
      }
      const { user } = await loginAccountCrossDevice(email.trim(), password);
      sounds.playCorrect();
      onAuthenticated(user);
    } catch (err: any) {
      sounds.playIncorrect();
      setError(err?.message || 'Login failed. Please check your email and password.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-slate-900/95 backdrop-blur-2xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-[0_20px_70px_rgba(0,0,0,0.7)] text-slate-100 overflow-hidden my-8">
        
        {/* Glow ambient background accents */}
        <div className="absolute -top-24 -left-24 w-72 h-72 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-yellow-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close button (if modal is dismissible) */}
        {onClose && (
          <button
            onClick={() => { sounds.playClick(); onClose(); }}
            className="absolute top-6 right-6 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors z-20"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Header with Brand Logo */}
        <div className="relative z-10 flex flex-col items-center text-center mb-6">
          <div className="mb-2">
            <Logo size="md" />
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white mt-2">
            {mode === 'signup' ? 'Create Your Free Study Account' : 'Welcome Back'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-md mt-1">
            {mode === 'signup' 
              ? 'Tell us a bit about what you want to study so we can tailor your timed practice tests.'
              : 'Sign in to access your test library, study notes, and diagnostic progress.'}
          </p>
        </div>

        {/* Mode Switcher */}
        <div className="relative z-10 flex p-1 bg-white/5 border border-white/10 rounded-2xl mb-6 backdrop-blur-md">
          <button
            type="button"
            id="tab-auth-signup"
            onClick={() => { sounds.playClick(); setMode('signup'); setError(null); }}
            className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              mode === 'signup'
                ? 'bg-amber-400 text-slate-950 font-bold shadow-lg shadow-amber-500/20 border border-amber-300'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Sign Up & Onboarding
          </button>
          <button
            type="button"
            id="tab-auth-login"
            onClick={() => { sounds.playClick(); setMode('login'); setError(null); }}
            className={`flex-1 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              mode === 'login'
                ? 'bg-amber-400 text-slate-950 font-bold shadow-lg shadow-amber-500/20 border border-amber-300'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Sign In to Existing Account
          </button>
        </div>

        {/* Error Notification */}
        {error && (
          <div className="relative z-10 mb-5 p-3.5 bg-rose-500/20 border border-rose-400/40 rounded-xl flex items-start space-x-3 text-rose-200 text-sm backdrop-blur-md animate-shake">
            <AlertCircle className="w-5 h-5 text-rose-400 flex-shrink-0 mt-0.5" />
            <p>{error}</p>
          </div>
        )}

        {/* SIGN UP MULTI-STEP FLOW */}
        {mode === 'signup' ? (
          <div className="relative z-10">
            {/* Step progress pills */}
            <div className="flex items-center justify-between mb-6 px-2">
              <div className="flex items-center space-x-2">
                <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                  signupStep >= 1 ? 'bg-amber-400 text-slate-950' : 'bg-white/10 text-slate-400'
                }`}>
                  1
                </span>
                <span className={`text-xs font-medium ${signupStep >= 1 ? 'text-white' : 'text-slate-500'}`}>Account</span>
              </div>
              <div className="h-0.5 w-10 sm:w-16 bg-white/10" />
              <div className="flex items-center space-x-2">
                <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                  signupStep >= 2 ? 'bg-amber-400 text-slate-950' : 'bg-white/10 text-slate-400'
                }`}>
                  2
                </span>
                <span className={`text-xs font-medium ${signupStep >= 2 ? 'text-white' : 'text-slate-500'}`}>Use Case</span>
              </div>
              <div className="h-0.5 w-10 sm:w-16 bg-white/10" />
              <div className="flex items-center space-x-2">
                <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${
                  signupStep >= 3 ? 'bg-amber-400 text-slate-950' : 'bg-white/10 text-slate-400'
                }`}>
                  3
                </span>
                <span className={`text-xs font-medium ${signupStep >= 3 ? 'text-white' : 'text-slate-500'}`}>Preferences</span>
              </div>
            </div>

            <form onSubmit={handleNextStep}>
              
              {/* STEP 1: Account Credentials */}
              {signupStep === 1 && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                      Full Name or Nickname
                    </label>
                    <div className="relative">
                      <User className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="input-signup-name"
                        type="text"
                        required
                        placeholder="e.g. Bob Bobison"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-white/5 border border-white/15 focus:border-amber-400 focus:bg-white/10 focus:outline-none rounded-xl text-white placeholder-slate-500 text-sm transition-all shadow-inner"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                      Email Address
                    </label>
                    <div className="relative">
                      <Mail className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="input-signup-email"
                        type="email"
                        required
                        placeholder="e.g. student@school.edu"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-white/5 border border-white/15 focus:border-amber-400 focus:bg-white/10 focus:outline-none rounded-xl text-white placeholder-slate-500 text-sm transition-all shadow-inner"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                      Create Password
                    </label>
                    <div className="relative">
                      <Lock className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                      <input
                        id="input-signup-password"
                        type="password"
                        required
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full pl-11 pr-4 py-3 bg-white/5 border border-white/15 focus:border-amber-400 focus:bg-white/10 focus:outline-none rounded-xl text-white placeholder-slate-500 text-sm transition-all shadow-inner"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3.5 mt-2 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 rounded-xl font-bold text-sm shadow-xl shadow-amber-500/20 flex items-center justify-center space-x-2 hover:scale-[1.01] transition-transform"
                  >
                    <span>Next: How will you use Review You?</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}

              {/* STEP 2: What are you going to use Review You for? */}
              {signupStep === 2 && (
                <div className="space-y-4 animate-fadeIn">
                  <div>
                    <h3 className="text-base font-bold text-white mb-1">
                      What are you going to use Review You for?
                    </h3>
                    <p className="text-xs text-slate-300 mb-3">
                      Select all that apply to personalize your question styles and pacing.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-72 overflow-y-auto pr-1">
                    {USE_CASE_OPTIONS.map((opt) => {
                      const Icon = opt.icon;
                      const isSelected = selectedUseCases.includes(opt.id);
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() => toggleUseCase(opt.id)}
                          className={`p-3.5 rounded-2xl border text-left flex items-start space-x-3 transition-all ${
                            isSelected
                              ? 'bg-amber-500/20 border-amber-400 text-white shadow-md ring-1 ring-amber-400/40'
                              : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:text-white'
                          }`}
                        >
                          <div className={`p-2 rounded-xl flex-shrink-0 ${
                            isSelected ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-white/10 text-slate-400'
                          }`}>
                            <Icon className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="font-bold text-xs text-white">{opt.title}</div>
                            <div className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{opt.desc}</div>
                          </div>
                          {isSelected && <Check className="w-4 h-4 text-amber-400 flex-shrink-0" />}
                        </button>
                      );
                    })}
                  </div>

                  <div className="flex items-center justify-between pt-3 gap-3">
                    <button
                      type="button"
                      onClick={() => { sounds.playClick(); setSignupStep(1); }}
                      className="px-4 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white font-medium text-xs flex items-center space-x-1"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      <span>Back</span>
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-3.5 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 rounded-xl font-bold text-xs sm:text-sm shadow-xl shadow-amber-500/20 flex items-center justify-center space-x-2 hover:scale-[1.01]"
                    >
                      <span>Next: Academic Focus & Theme</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* STEP 3: Education Level, Target Focus & Theme Color */}
              {signupStep === 3 && (
                <div className="space-y-4 animate-fadeIn max-h-[65vh] overflow-y-auto pr-1">
                  <div>
                    <h3 className="text-base font-bold text-white mb-1">
                      Finalize Your Study Workspace
                    </h3>
                    <p className="text-xs text-slate-300 mb-3">
                      Calibrate difficulty and choose your favorite workspace theme color.
                    </p>
                  </div>

                  {/* Theme Color Selection */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center space-x-1.5">
                      <Palette className="w-3.5 h-3.5 text-amber-400" />
                      <span>Choose Your Accent Theme Color</span>
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                      {Object.values(THEMES).map((t) => {
                        const isSelected = selectedTheme === t.id;
                        return (
                          <button
                            key={t.id}
                            type="button"
                            onClick={() => { sounds.playClick(); setSelectedTheme(t.id); }}
                            className={`p-2.5 rounded-xl border text-left flex items-center space-x-2 transition-all ${
                              isSelected
                                ? 'bg-white/15 border-white/40 ring-1 ring-white/50 shadow-md scale-[1.02]'
                                : 'bg-white/5 border-white/10 hover:bg-white/10'
                            }`}
                          >
                            <div 
                              className="w-4 h-4 rounded-full flex-shrink-0 shadow-sm"
                              style={{ backgroundColor: t.colorHex }}
                            />
                            <span className="text-[11px] font-medium text-white truncate">{t.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Grade level selection */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                      Your Education / Career Level
                    </label>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {GRADE_LEVELS.map((gl) => (
                        <button
                          key={gl}
                          type="button"
                          onClick={() => { sounds.playClick(); setSelectedGrade(gl); }}
                          className={`py-2 px-3 rounded-xl text-xs font-medium border text-center transition-all ${
                            selectedGrade === gl
                              ? 'bg-amber-500/20 border-amber-400 text-white font-bold ring-1 ring-amber-400'
                              : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          {gl}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Target exam / subjects */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                      Primary Subjects or Upcoming Exams
                    </label>
                    <input
                      type="text"
                      value={targetSubjects}
                      onChange={(e) => setTargetSubjects(e.target.value)}
                      placeholder="e.g. AP Biology, SAT Math, AWS Cloud Architect, To Kill a Mockingbird"
                      className="w-full px-4 py-3 bg-white/5 border border-white/15 focus:border-amber-400 focus:outline-none rounded-xl text-white placeholder-slate-500 text-sm transition-all"
                    />
                  </div>

                  {/* Daily practice goal */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                        Daily Study Time Goal
                      </label>
                      <span className="text-xs font-bold text-amber-300">{dailyGoalMinutes} min/day</span>
                    </div>
                    <div className="flex gap-2">
                      {[15, 30, 45, 60].map((m) => (
                        <button
                          key={m}
                          type="button"
                          onClick={() => { sounds.playClick(); setDailyGoalMinutes(m); }}
                          className={`flex-1 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
                            dailyGoalMinutes === m
                              ? 'bg-amber-500/20 border-amber-400 text-white'
                              : 'bg-white/5 border-white/10 text-slate-400 hover:text-white'
                          }`}
                        >
                          {m} min
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3 gap-3">
                    <button
                      type="button"
                      onClick={() => { sounds.playClick(); setSignupStep(2); }}
                      className="px-4 py-3 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white font-medium text-xs flex items-center space-x-1"
                    >
                      <ChevronLeft className="w-4 h-4" />
                      <span>Back</span>
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-1 py-3.5 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 rounded-xl font-bold text-sm shadow-xl shadow-amber-500/30 flex items-center justify-center space-x-2 hover:scale-[1.01] disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span>Setting up your study space...</span>
                      ) : (
                        <>
                          <Sparkles className="w-4 h-4" />
                          <span>Complete Setup & Start Studying</span>
                        </>
                      )}
                    </button>
                  </div>

                </div>
              )}

            </form>
          </div>
        ) : (
          /* SIGN IN TO EXISTING ACCOUNT */
          <form onSubmit={handleLoginSubmit} className="relative z-10 space-y-4 animate-fadeIn">
            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Account Email Address
              </label>
              <div className="relative">
                <Mail className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="input-login-email"
                  type="email"
                  required
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-white/5 border border-white/15 focus:border-amber-400 focus:bg-white/10 focus:outline-none rounded-xl text-white placeholder-slate-500 text-sm transition-all shadow-inner"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="input-login-password"
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 bg-white/5 border border-white/15 focus:border-amber-400 focus:bg-white/10 focus:outline-none rounded-xl text-white placeholder-slate-500 text-sm transition-all shadow-inner"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3.5 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 text-slate-950 font-bold text-sm rounded-xl shadow-xl shadow-amber-500/20 hover:scale-[1.01] transition-transform disabled:opacity-50"
            >
              {isSubmitting ? 'Signing in...' : 'Sign In & Access Study Library'}
            </button>
          </form>
        )}

      </div>
    </div>
  );
};
