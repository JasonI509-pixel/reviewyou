import React, { useState, useEffect, useRef } from 'react';
import { 
  Edit3, 
  Plus, 
  Trash2, 
  Copy, 
  Download, 
  Sparkles, 
  Check, 
  Type, 
  FileText, 
  BookOpen, 
  Sliders, 
  RefreshCw, 
  Clock, 
  AlignLeft, 
  Hash, 
  Bold, 
  Italic, 
  List, 
  CheckSquare, 
  Code, 
  Quote, 
  FolderPlus,
  Save,
  Search,
  Printer,
  FileDown,
  Columns,
  Eye,
  Maximize2,
  Minimize2,
  Table,
  Underline,
  Strikethrough,
  Highlighter,
  Subscript,
  Superscript,
  Calculator,
  Lightbulb,
  AlertTriangle,
  Zap,
  Star,
  CopyCheck,
  RotateCcw,
  Replace,
  Layers,
  ChevronDown,
  BookMarked
} from 'lucide-react';
import { FreeformNote, Quiz } from '../types';
import { sounds } from '../lib/sound';
import { loadFreeformNotes, saveFreeformNotes } from '../lib/storage';
import { DOCUMENT_TEMPLATES, DocumentTemplate } from '../lib/documentTemplates';
import { DocumentRenderer } from './DocumentRenderer';
import { DeleteConfirmModal } from './DeleteConfirmModal';
import { safeFetchJson } from '../lib/api';

interface FreeformNotebookProps {
  onGenerateTestFromText?: (title: string, text: string) => void;
}

export const FreeformNotebook: React.FC<FreeformNotebookProps> = ({
  onGenerateTestFromText,
}) => {
  const [notes, setNotes] = useState<FreeformNote[]>(() => loadFreeformNotes());
  const [activeNoteId, setActiveNoteId] = useState<string>(() => {
    const loaded = loadFreeformNotes();
    return loaded[0]?.id || 'note_1';
  });

  // UI state
  const [copied, setCopied] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');
  const [viewMode, setViewMode] = useState<'editor' | 'preview' | 'split'>('editor');
  const [showTemplatesModal, setShowTemplatesModal] = useState(false);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [noteToDeleteId, setNoteToDeleteId] = useState<string | null>(null);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [aiLoadingAction, setAiLoadingAction] = useState<string | null>(null);
  const [aiFlashcardsModal, setAiFlashcardsModal] = useState<{ front: string; back: string }[] | null>(null);
  const [flippedCardIndex, setFlippedCardIndex] = useState<number | null>(null);
  const [showMathSymbols, setShowMathSymbols] = useState(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Active note lookup
  const activeNote = notes.find(n => n.id === activeNoteId) || notes[0] || {
    id: 'note_1',
    title: 'Untitled Document',
    content: '',
    createdAt: new Date().toISOString(),
    lastModified: new Date().toISOString(),
    wordCount: 0,
    charCount: 0,
    paragraphCount: 0,
    paperStyle: 'word_dark',
    fontFamily: 'sans',
    fontSize: 'base',
    lineSpacing: '1.15',
    layoutMode: 'paginated',
    pageSize: 'letter',
  };

  // Sync notes to localStorage
  useEffect(() => {
    saveFreeformNotes(notes);
  }, [notes]);

  const calculateCounts = (text: string) => {
    const trimmed = text.trim();
    const words = trimmed ? trimmed.split(/\s+/).length : 0;
    const chars = text.length;
    const paragraphs = trimmed ? trimmed.split(/\n\s*\n/).filter(Boolean).length : 0;
    return { words, chars, paragraphs };
  };

  const updateActiveNote = (fields: Partial<FreeformNote>) => {
    setNotes(prev => prev.map(note => {
      if (note.id === activeNote.id) {
        const updated = {
          ...note,
          ...fields,
          lastModified: new Date().toISOString(),
        };

        if (fields.content !== undefined) {
          const counts = calculateCounts(fields.content);
          updated.wordCount = counts.words;
          updated.charCount = counts.chars;
          updated.paragraphCount = counts.paragraphs;
        }

        return updated;
      }
      return note;
    }));
  };

  // Create new blank document
  const handleCreateNewBlankNote = () => {
    sounds.playClick();
    const newNote: FreeformNote = {
      id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: `Untitled Document ${notes.length + 1}`,
      content: '',
      createdAt: new Date().toISOString(),
      lastModified: new Date().toISOString(),
      wordCount: 0,
      charCount: 0,
      paragraphCount: 0,
      paperStyle: activeNote.paperStyle || 'word_dark',
      fontFamily: activeNote.fontFamily || 'sans',
      fontSize: activeNote.fontSize || 'base',
      lineSpacing: activeNote.lineSpacing || '1.15',
      layoutMode: activeNote.layoutMode || 'paginated',
      pageSize: activeNote.pageSize || 'letter',
    };

    setNotes(prev => [newNote, ...prev]);
    setActiveNoteId(newNote.id);
    setViewMode('editor');
    sounds.playCorrect();

    setTimeout(() => {
      textareaRef.current?.focus();
    }, 100);
  };

  // Create from starter template
  const handleCreateFromTemplate = (template: DocumentTemplate) => {
    sounds.playClick();
    const counts = calculateCounts(template.content);
    const newNote: FreeformNote = {
      id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: template.defaultTitle,
      content: template.content,
      createdAt: new Date().toISOString(),
      lastModified: new Date().toISOString(),
      wordCount: counts.words,
      charCount: counts.chars,
      paragraphCount: counts.paragraphs,
      category: template.category,
      paperStyle: template.paperStyle || 'word_dark',
      fontFamily: template.fontFamily || 'sans',
      fontSize: template.fontSize || 'base',
      lineSpacing: template.lineSpacing || '1.15',
      layoutMode: template.layoutMode || 'paginated',
    };

    setNotes(prev => [newNote, ...prev]);
    setActiveNoteId(newNote.id);
    setShowTemplatesModal(false);
    sounds.playCorrect();
  };

  // Duplicate Document
  const handleDuplicateNote = (note: FreeformNote) => {
    sounds.playClick();
    const dup: FreeformNote = {
      ...note,
      id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title: `${note.title} (Copy)`,
      createdAt: new Date().toISOString(),
      lastModified: new Date().toISOString(),
    };
    setNotes(prev => [dup, ...prev]);
    setActiveNoteId(dup.id);
    sounds.playCorrect();
  };

  // Delete Document with Confirmation
  const confirmDeleteNote = () => {
    if (!noteToDeleteId) return;
    const targetId = noteToDeleteId;
    sounds.playClick();

    if (notes.length <= 1) {
      // Clear current note if only 1 exists
      const resetNote: FreeformNote = {
        id: `doc_${Date.now()}`,
        title: 'Untitled Document',
        content: '',
        createdAt: new Date().toISOString(),
        lastModified: new Date().toISOString(),
        wordCount: 0,
        charCount: 0,
        paragraphCount: 0,
        paperStyle: 'word_dark',
        fontFamily: 'sans',
        fontSize: 'base',
      };
      setNotes([resetNote]);
      setActiveNoteId(resetNote.id);
    } else {
      const remaining = notes.filter(n => n.id !== targetId);
      setNotes(remaining);
      if (activeNoteId === targetId) {
        setActiveNoteId(remaining[0]?.id || '');
      }
    }

    setNoteToDeleteId(null);
    setShowDeleteModal(false);
    sounds.playCorrect();
  };

  // Copy text to clipboard
  const handleCopyText = () => {
    sounds.playClick();
    navigator.clipboard.writeText(activeNote.content);
    setCopied(true);
    sounds.playCorrect();
    setTimeout(() => setCopied(false), 2000);
  };

  // Download file in various formats (Word .doc, Markdown .md, Plain text .txt)
  const handleDownloadNote = (format: 'txt' | 'md' | 'doc') => {
    sounds.playClick();
    let mimeType = 'text/plain;charset=utf-8';
    let fileContent = activeNote.content;

    if (format === 'doc') {
      mimeType = 'application/msword;charset=utf-8';
      // HTML wrapper that Microsoft Word opens directly as a formatted document
      fileContent = `
        <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
        <head><title>${activeNote.title}</title>
        <style>
          body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; line-height: 1.5; color: #111; margin: 1in; }
          h1 { font-size: 20pt; color: #1e3a8a; border-bottom: 2px solid #1e3a8a; padding-bottom: 4px; }
          h2 { font-size: 15pt; color: #1e40af; margin-top: 18px; }
          h3 { font-size: 13pt; color: #374151; }
          table { width: 100%; border-collapse: collapse; margin: 16px 0; }
          th, td { border: 1px solid #cbd5e1; padding: 8px 12px; text-align: left; }
          th { background-color: #f1f5f9; font-weight: bold; }
          code { background: #f1f5f9; font-family: Consolas, monospace; padding: 2px 4px; font-size: 10pt; }
          blockquote { border-left: 4px solid #3b82f6; padding-left: 12px; color: #475569; font-style: italic; }
        </style>
        </head>
        <body>
          <h1>${activeNote.title}</h1>
          <p><em>Generated by Review You Document Studio • ${new Date().toLocaleDateString()}</em></p>
          <hr/>
          <pre style="font-family: Calibri, Arial, sans-serif; white-space: pre-wrap;">${activeNote.content}</pre>
        </body>
        </html>
      `;
    } else if (format === 'md') {
      mimeType = 'text/markdown;charset=utf-8';
    }

    const element = document.createElement('a');
    const file = new Blob([fileContent], { type: mimeType });
    element.href = URL.createObjectURL(file);
    element.download = `${activeNote.title.replace(/[^a-zA-Z0-9_-]/g, '_') || 'document'}.${format}`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    sounds.playCorrect();
  };

  // Print Document formatted
  const handlePrintDocument = () => {
    sounds.playClick();
    window.print();
  };

  // Insert formatting at cursor
  const handleInsertFormatting = (prefix: string, suffix: string = '', defaultPlaceholder: string = 'text') => {
    sounds.playClick();
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const currentText = activeNote.content;
    const selected = currentText.substring(start, end);

    const replacement = `${prefix}${selected || defaultPlaceholder}${suffix}`;
    const newContent = currentText.substring(0, start) + replacement + currentText.substring(end);

    updateActiveNote({ content: newContent });

    setTimeout(() => {
      textarea.focus();
      const newCursorStart = start + prefix.length;
      const newCursorEnd = newCursorStart + (selected.length || defaultPlaceholder.length);
      textarea.setSelectionRange(newCursorStart, newCursorEnd);
    }, 50);
  };

  // Insert Special Tables
  const handleInsertTable = (rows: number = 3, cols: number = 3) => {
    sounds.playClick();
    let tableMd = '\n| ' + Array.from({ length: cols }, (_, i) => `Header ${i + 1}`).join(' | ') + ' |\n';
    tableMd += '| ' + Array.from({ length: cols }, () => ':---').join(' | ') + ' |\n';
    for (let r = 0; r < rows; r++) {
      tableMd += '| ' + Array.from({ length: cols }, (_, c) => `Row ${r + 1} Col ${c + 1}`).join(' | ') + ' |\n';
    }
    tableMd += '\n';

    handleInsertFormatting(tableMd, '', '');
  };

  // Insert Callout Box
  const handleInsertCallout = (type: 'tip' | 'warning' | 'formula' | 'question') => {
    sounds.playClick();
    let calloutText = '';
    if (type === 'tip') calloutText = '\n> 💡 **Key Insight:** Explain the most important mechanism or rule here.\n\n';
    if (type === 'warning') calloutText = '\n> ⚠️ **Common Exam Trap:** Watch out for unit conversions or edge-case conditions!\n\n';
    if (type === 'formula') calloutText = '\n> 📌 **Core Formula:** `Result = (Factor A * Factor B) / Constant C`\n\n';
    if (type === 'question') calloutText = '\n> 🎯 **Check Question:** What is the primary difference between X and Y?\n\n';

    handleInsertFormatting(calloutText, '', '');
  };

  // Insert Math Symbol
  const handleInsertMathSymbol = (symbol: string) => {
    sounds.playClick();
    handleInsertFormatting(symbol, '', '');
  };

  // Find and Replace in Document
  const handleFindReplace = (replaceAll: boolean = false) => {
    if (!findText) return;
    sounds.playClick();
    const current = activeNote.content;
    if (replaceAll) {
      const regex = new RegExp(findText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
      const updated = current.replace(regex, replaceText);
      updateActiveNote({ content: updated });
    } else {
      const updated = current.replace(findText, replaceText);
      updateActiveNote({ content: updated });
    }
    sounds.playCorrect();
  };

  // AI Copilot Assistants (Word-style intelligence)
  const handleAiAssist = async (action: 'polish' | 'summarize' | 'flashcards' | 'questions') => {
    if (!activeNote.content.trim()) {
      alert('Please type some text in the document first.');
      return;
    }

    sounds.playClick();
    setAiLoadingAction(action);

    try {
      if (action === 'polish' || action === 'summarize') {
        const data = await safeFetchJson<{ result: string }>('/api/document-ai-assist', {
          method: 'POST',
          body: JSON.stringify({
            action,
            title: activeNote.title,
            content: activeNote.content,
          }),
        });

        if (data && data.result) {
          if (action === 'polish') {
            updateActiveNote({ content: data.result });
          } else {
            // Append summary to bottom of document
            updateActiveNote({ content: `${activeNote.content}\n\n---\n\n${data.result}` });
          }
          sounds.playCorrect();
        }
      } else if (action === 'flashcards') {
        const data = await safeFetchJson<{ flashcards: { front: string; back: string }[] }>('/api/document-ai-assist', {
          method: 'POST',
          body: JSON.stringify({
            action: 'flashcards',
            title: activeNote.title,
            content: activeNote.content,
          }),
        });

        if (data && data.flashcards && data.flashcards.length > 0) {
          setAiFlashcardsModal(data.flashcards);
          setFlippedCardIndex(null);
          sounds.playCorrect();
        } else {
          alert('Could not extract flashcards. Try adding more detailed text.');
        }
      } else if (action === 'questions') {
        if (onGenerateTestFromText) {
          sounds.playCorrect();
          onGenerateTestFromText(activeNote.title || 'Study Document Test', activeNote.content);
        }
      }
    } catch (err: any) {
      console.error('AI Document Assist error:', err);
      alert(err?.message || 'AI document processing temporarily unavailable.');
      sounds.playIncorrect();
    } finally {
      setAiLoadingAction(null);
    }
  };

  // Font family styles
  const getFontFamilyClass = () => {
    if (activeNote.fontFamily === 'serif') return 'font-serif';
    if (activeNote.fontFamily === 'mono') return 'font-mono';
    if (activeNote.fontFamily === 'academic') return 'font-serif tracking-normal';
    if (activeNote.fontFamily === 'casual') return 'font-sans tracking-wide';
    return 'font-sans';
  };

  // Font size styles
  const getFontSizeClass = () => {
    if (activeNote.fontSize === 'xs') return 'text-xs leading-relaxed';
    if (activeNote.fontSize === 'sm') return 'text-sm leading-relaxed';
    if (activeNote.fontSize === 'lg') return 'text-lg leading-relaxed';
    if (activeNote.fontSize === 'xl') return 'text-xl leading-relaxed';
    if (activeNote.fontSize === '2xl') return 'text-2xl leading-relaxed';
    return 'text-base leading-relaxed';
  };

  // Line Spacing Class
  const getLineSpacingClass = () => {
    if (activeNote.lineSpacing === '1.0') return 'leading-tight';
    if (activeNote.lineSpacing === '1.5') return 'leading-loose';
    if (activeNote.lineSpacing === '2.0') return 'leading-[2.4]';
    return 'leading-relaxed';
  };

  // Paper background styles
  const getPaperBgClass = () => {
    if (activeNote.paperStyle === 'word_light') {
      return 'bg-slate-100 text-slate-900 border-slate-300 shadow-2xl';
    }
    if (activeNote.paperStyle === 'parchment') {
      return 'bg-amber-950/40 text-amber-100 border-amber-500/30';
    }
    if (activeNote.paperStyle === 'lined') {
      return 'bg-[linear-gradient(rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:100%_2rem] bg-slate-950/95';
    }
    if (activeNote.paperStyle === 'grid') {
      return 'bg-[radial-gradient(rgba(255,255,255,0.12)_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] bg-slate-950/95';
    }
    return 'bg-slate-950/95 border-white/15';
  };

  const readingTimeMinutes = Math.max(1, Math.ceil(activeNote.wordCount / 200));

  const filteredNotes = notes.filter(n => {
    const matchesSearch = searchQuery === '' ||
      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      n.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'All' || n.category === categoryFilter;
    return matchesSearch && matchesCategory;
  });

  const allCategories = ['All', ...Array.from(new Set(notes.map(n => n.category || 'General')))];

  const mathSymbols = ['∑', '∫', '√', 'π', 'θ', 'α', 'β', 'Δ', '±', '∞', '≈', '≠', '≤', '≥', '÷', '×', '→', '⇄', 'λ', 'μ', 'σ', 'Ω'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fadeIn select-text">
      
      {/* Top Header / Document Suite Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 border border-amber-400/40 text-amber-300 flex items-center justify-center shadow-lg shadow-amber-500/10">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center space-x-2">
                <span>Document Studio</span>
                <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-300 border border-amber-400/30">
                  Word Pro
                </span>
              </h1>
              <p className="text-xs sm:text-sm text-slate-300 mt-0.5">
                Advanced blank document editor, formatted study notes & instant AI test generation.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-2.5 flex-wrap">
          <button
            onClick={() => setShowTemplatesModal(true)}
            className="inline-flex items-center space-x-2 px-3.5 py-2.5 bg-white/10 hover:bg-white/15 text-slate-200 hover:text-white text-xs font-bold rounded-xl border border-white/15 transition-all hover:scale-[1.02]"
          >
            <BookMarked className="w-4 h-4 text-indigo-400" />
            <span>Templates</span>
          </button>

          <button
            onClick={handleCreateNewBlankNote}
            className="inline-flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 text-xs font-black rounded-xl shadow-lg shadow-amber-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            <Plus className="w-4 h-4" />
            <span>New Document</span>
          </button>

          {onGenerateTestFromText && (
            <button
              onClick={() => handleAiAssist('questions')}
              className="inline-flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-bold rounded-xl border border-indigo-400/30 shadow-lg shadow-indigo-500/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Turn Doc into Timed Test</span>
            </button>
          )}
        </div>
      </div>

      {/* 2-Column Split: Document Explorer Sidebar & Word-Style Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Sidebar: Document Explorer */}
        <div className="lg:col-span-3 space-y-4">
          
          {/* Search & Filter Card */}
          <div className="p-3.5 bg-white/[0.04] border border-white/10 rounded-2xl backdrop-blur-xl space-y-2.5">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search documents..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 bg-white/5 border border-white/10 rounded-xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-400"
              />
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar text-[11px]">
              {allCategories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-colors ${
                    categoryFilter === cat
                      ? 'bg-amber-400/20 text-amber-300 border border-amber-400/40'
                      : 'bg-white/5 text-slate-400 hover:text-white border border-transparent'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Document List */}
          <div className="space-y-2 max-h-[640px] overflow-y-auto pr-1 custom-scrollbar">
            {filteredNotes.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 bg-white/[0.02] border border-white/10 rounded-2xl">
                No matching documents found.
              </div>
            ) : (
              filteredNotes.map(note => {
                const isSelected = note.id === activeNote.id;
                const preview = note.content.trim() ? note.content.trim().slice(0, 75) : '(Blank document...)';

                return (
                  <div
                    key={note.id}
                    onClick={() => { sounds.playClick(); setActiveNoteId(note.id); }}
                    className={`group p-3.5 rounded-2xl border text-left cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-amber-400/15 border-amber-400/50 shadow-md ring-1 ring-amber-400/30'
                        : 'bg-white/[0.03] border-white/10 hover:bg-white/[0.06] hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center space-x-1.5 min-w-0">
                        <FileText className={`w-3.5 h-3.5 flex-shrink-0 ${isSelected ? 'text-amber-400' : 'text-slate-400'}`} />
                        <h4 className={`text-xs font-bold truncate ${isSelected ? 'text-amber-300' : 'text-white'}`}>
                          {note.title || 'Untitled Document'}
                        </h4>
                      </div>

                      {/* Hover Actions: Duplicate & Delete */}
                      <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDuplicateNote(note); }}
                          className="p-1 text-slate-400 hover:text-white rounded"
                          title="Duplicate document"
                        >
                          <Copy className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setNoteToDeleteId(note.id);
                            setShowDeleteModal(true);
                          }}
                          className="p-1 text-slate-400 hover:text-rose-400 rounded"
                          title="Delete document"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <p className="text-[11px] text-slate-400 line-clamp-2 mt-1.5 font-sans leading-relaxed">
                      {preview}
                    </p>

                    <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2.5 pt-1.5 border-t border-white/5">
                      <span>{note.wordCount || 0} words • {note.paragraphCount || 0} paras</span>
                      <span>{new Date(note.lastModified).toLocaleDateString()}</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

        </div>

        {/* Right Area: Word-Style Document Studio */}
        <div className="lg:col-span-9 space-y-4">
          
          {/* Main Document Workspace Card */}
          <div className="border border-white/15 rounded-3xl shadow-2xl overflow-hidden backdrop-blur-2xl bg-slate-950/90 transition-all">
            
            {/* Top Word-Style Title & Action Ribbon Header */}
            <div className="p-4 sm:p-5 border-b border-white/10 bg-slate-900/90 space-y-4">
              
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                
                {/* Title Input */}
                <div className="flex items-center space-x-2 flex-1">
                  <FileText className="w-5 h-5 text-amber-400 flex-shrink-0" />
                  <input
                    type="text"
                    value={activeNote.title}
                    onChange={(e) => updateActiveNote({ title: e.target.value })}
                    placeholder="Document Title..."
                    className="text-lg sm:text-xl font-bold text-white bg-transparent border-b border-transparent hover:border-white/20 focus:border-amber-400 focus:outline-none w-full px-1 py-0.5 transition-colors"
                  />
                </div>

                {/* View Modes & Action Buttons */}
                <div className="flex items-center space-x-1.5 flex-wrap">
                  
                  {/* View Mode Switcher */}
                  <div className="flex items-center bg-white/5 p-0.5 rounded-xl border border-white/10 text-xs">
                    <button
                      onClick={() => { sounds.playClick(); setViewMode('editor'); }}
                      className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition-colors ${
                        viewMode === 'editor' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
                      }`}
                      title="Edit text"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Edit</span>
                    </button>

                    <button
                      onClick={() => { sounds.playClick(); setViewMode('split'); }}
                      className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition-colors ${
                        viewMode === 'split' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
                      }`}
                      title="Split screen editor & rendered view"
                    >
                      <Columns className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Split</span>
                    </button>

                    <button
                      onClick={() => { sounds.playClick(); setViewMode('preview'); }}
                      className={`flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition-colors ${
                        viewMode === 'preview' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-300 hover:text-white'
                      }`}
                      title="Formatted Page View"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">Preview</span>
                    </button>
                  </div>

                  {/* Find & Replace Toggle */}
                  <button
                    onClick={() => { sounds.playClick(); setShowFindReplace(!showFindReplace); }}
                    className={`p-2 rounded-xl text-xs border transition-colors ${
                      showFindReplace ? 'bg-amber-400/20 text-amber-300 border-amber-400/40' : 'bg-white/5 text-slate-300 hover:text-white border-white/10'
                    }`}
                    title="Find & Replace"
                  >
                    <Replace className="w-3.5 h-3.5" />
                  </button>

                  {/* Print Document */}
                  <button
                    onClick={handlePrintDocument}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-colors"
                    title="Print Document or Save as PDF"
                  >
                    <Printer className="w-3.5 h-3.5" />
                  </button>

                  {/* Copy Text */}
                  <button
                    onClick={handleCopyText}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition-colors"
                    title="Copy full text"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>

                  {/* Download Dropdown options */}
                  <div className="flex items-center space-x-1 bg-white/5 rounded-xl border border-white/10 p-0.5 text-xs">
                    <button
                      onClick={() => handleDownloadNote('doc')}
                      className="px-2 py-1 hover:bg-white/10 text-slate-300 hover:text-white rounded-lg font-bold"
                      title="Download as Word Document (.doc)"
                    >
                      .doc
                    </button>
                    <button
                      onClick={() => handleDownloadNote('md')}
                      className="px-2 py-1 hover:bg-white/10 text-slate-300 hover:text-white rounded-lg font-bold"
                      title="Download as Markdown (.md)"
                    >
                      .md
                    </button>
                    <button
                      onClick={() => handleDownloadNote('txt')}
                      className="px-2 py-1 hover:bg-white/10 text-slate-300 hover:text-white rounded-lg font-bold"
                      title="Download as Text (.txt)"
                    >
                      .txt
                    </button>
                  </div>

                  {/* Delete Document Button */}
                  <button
                    onClick={() => {
                      sounds.playClick();
                      setNoteToDeleteId(activeNote.id);
                      setShowDeleteModal(true);
                    }}
                    className="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 hover:text-rose-200 border border-rose-500/30 transition-colors"
                    title="Delete this document"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>

                </div>

              </div>

              {/* Find and Replace Drawer */}
              {showFindReplace && (
                <div className="p-3 bg-white/5 border border-white/10 rounded-2xl flex flex-col sm:flex-row items-center gap-2 animate-fadeIn text-xs">
                  <input
                    type="text"
                    placeholder="Find in document..."
                    value={findText}
                    onChange={(e) => setFindText(e.target.value)}
                    className="flex-1 px-3 py-1.5 bg-slate-900 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                  <input
                    type="text"
                    placeholder="Replace with..."
                    value={replaceText}
                    onChange={(e) => setReplaceText(e.target.value)}
                    className="flex-1 px-3 py-1.5 bg-slate-900 border border-white/10 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
                  />
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleFindReplace(false)}
                      className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl font-semibold"
                    >
                      Replace
                    </button>
                    <button
                      onClick={() => handleFindReplace(true)}
                      className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl font-bold"
                    >
                      Replace All
                    </button>
                  </div>
                </div>
              )}

              {/* Word-Style Formatting Ribbon Toolbar */}
              <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/10 text-xs">
                
                {/* Left: Text Formatting Shortcuts */}
                <div className="flex items-center space-x-1 flex-wrap">
                  <button
                    onClick={() => handleInsertFormatting('**', '**', 'bold text')}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors font-bold"
                    title="Bold (**text**)"
                  >
                    <Bold className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('*', '*', 'italic text')}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors italic"
                    title="Italic (*text*)"
                  >
                    <Italic className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('<u>', '</u>', 'underlined text')}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Underline (<u>text</u>)"
                  >
                    <Underline className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('~~', '~~', 'strikethrough text')}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Strikethrough (~~text~~)"
                  >
                    <Strikethrough className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('==', '==', 'highlighted text')}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors text-amber-300"
                    title="Highlight (==text==)"
                  >
                    <Highlighter className="w-3.5 h-3.5" />
                  </button>

                  <div className="h-4 w-px bg-white/15 mx-1" />

                  {/* Headings */}
                  <button
                    onClick={() => handleInsertFormatting('# ', '', 'Main Heading')}
                    className="px-2 py-1 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors font-bold"
                    title="Heading 1"
                  >
                    H1
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('## ', '', 'Section Heading')}
                    className="px-2 py-1 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors font-semibold"
                    title="Heading 2"
                  >
                    H2
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('### ', '', 'Subsection')}
                    className="px-2 py-1 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Heading 3"
                  >
                    H3
                  </button>

                  <div className="h-4 w-px bg-white/15 mx-1" />

                  {/* Lists & Tasks */}
                  <button
                    onClick={() => handleInsertFormatting('- ', '', 'List item')}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Bullet list"
                  >
                    <List className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('- [ ] ', '', 'Checklist task item')}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Checklist task item"
                  >
                    <CheckSquare className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('1. ', '', 'Numbered item')}
                    className="px-2 py-1 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors font-mono"
                    title="Numbered list"
                  >
                    1.
                  </button>

                  <div className="h-4 w-px bg-white/15 mx-1" />

                  {/* Insert Table & Callouts */}
                  <button
                    onClick={() => handleInsertTable(3, 3)}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Insert Table (3x3)"
                  >
                    <Table className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertCallout('tip')}
                    className="p-1.5 text-amber-300 hover:text-amber-200 hover:bg-white/10 rounded-lg transition-colors"
                    title="Insert Key Insight Callout"
                  >
                    <Lightbulb className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertCallout('warning')}
                    className="p-1.5 text-rose-300 hover:text-rose-200 hover:bg-white/10 rounded-lg transition-colors"
                    title="Insert Common Exam Trap"
                  >
                    <AlertTriangle className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setShowMathSymbols(!showMathSymbols)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      showMathSymbols ? 'bg-indigo-500/30 text-indigo-300' : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                    title="Math & Science Symbols"
                  >
                    <Calculator className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleInsertFormatting('```\n', '\n```', '// Code snippet here')}
                    className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
                    title="Code block"
                  >
                    <Code className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Right: Typography, Paper Theme & Page Setup Controls */}
                <div className="flex items-center space-x-2 text-slate-300 text-xs flex-wrap">
                  
                  {/* Font Family */}
                  <select
                    value={activeNote.fontFamily || 'sans'}
                    onChange={(e) => updateActiveNote({ fontFamily: e.target.value as any })}
                    className="bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-slate-200 focus:outline-none focus:border-amber-400"
                    title="Font Family"
                  >
                    <option value="sans" className="bg-slate-900">Modern Sans (Aptos/Calibri)</option>
                    <option value="serif" className="bg-slate-900">Classic Serif (Times/Georgia)</option>
                    <option value="academic" className="bg-slate-900">Academic Book (Editorial)</option>
                    <option value="mono" className="bg-slate-900">Monospace (Code/Technical)</option>
                    <option value="casual" className="bg-slate-900">Casual Notes</option>
                  </select>

                  {/* Font Size */}
                  <select
                    value={activeNote.fontSize || 'base'}
                    onChange={(e) => updateActiveNote({ fontSize: e.target.value as any })}
                    className="bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-slate-200 focus:outline-none focus:border-amber-400"
                    title="Font Size"
                  >
                    <option value="xs" className="bg-slate-900">12pt (Small)</option>
                    <option value="sm" className="bg-slate-900">14pt (Standard)</option>
                    <option value="base" className="bg-slate-900">16pt (Medium)</option>
                    <option value="lg" className="bg-slate-900">18pt (Large)</option>
                    <option value="xl" className="bg-slate-900">20pt (Extra Large)</option>
                  </select>

                  {/* Line Spacing */}
                  <select
                    value={activeNote.lineSpacing || '1.15'}
                    onChange={(e) => updateActiveNote({ lineSpacing: e.target.value as any })}
                    className="bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-slate-200 focus:outline-none focus:border-amber-400"
                    title="Line Spacing"
                  >
                    <option value="1.0" className="bg-slate-900">1.0 Single</option>
                    <option value="1.15" className="bg-slate-900">1.15 Word Normal</option>
                    <option value="1.5" className="bg-slate-900">1.5 Academic</option>
                    <option value="2.0" className="bg-slate-900">2.0 Double</option>
                  </select>

                  {/* Paper Background Style */}
                  <select
                    value={activeNote.paperStyle || 'word_dark'}
                    onChange={(e) => updateActiveNote({ paperStyle: e.target.value as any })}
                    className="bg-white/5 border border-white/10 rounded-lg px-2 py-1 text-slate-200 focus:outline-none focus:border-amber-400"
                    title="Paper Style"
                  >
                    <option value="word_dark" className="bg-slate-900">Dark Executive Sheet</option>
                    <option value="word_light" className="bg-slate-900">Word Document (Light)</option>
                    <option value="lined" className="bg-slate-900">College Ruled Lined</option>
                    <option value="grid" className="bg-slate-900">Engineering Grid</option>
                    <option value="parchment" className="bg-slate-900">Warm Parchment</option>
                  </select>

                </div>

              </div>

              {/* Math Symbols Ribbon (when toggled) */}
              {showMathSymbols && (
                <div className="p-2.5 bg-indigo-950/40 border border-indigo-500/30 rounded-2xl flex items-center gap-1.5 flex-wrap animate-fadeIn text-xs">
                  <span className="text-[11px] font-bold text-indigo-300 mr-2 flex items-center space-x-1">
                    <Calculator className="w-3.5 h-3.5" />
                    <span>Quick Symbols:</span>
                  </span>
                  {mathSymbols.map(sym => (
                    <button
                      key={sym}
                      onClick={() => handleInsertMathSymbol(sym)}
                      className="px-2 py-1 bg-white/10 hover:bg-white/20 text-white rounded-lg font-mono text-sm hover:scale-110 transition-transform"
                    >
                      {sym}
                    </button>
                  ))}
                </div>
              )}

              {/* AI Copilot Action Strip */}
              <div className="pt-2 border-t border-white/10 flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center space-x-2 text-[11px] text-slate-400">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span className="font-semibold text-slate-300">Word AI Assistant:</span>
                </div>

                <div className="flex items-center space-x-2 flex-wrap">
                  <button
                    onClick={() => handleAiAssist('polish')}
                    disabled={!!aiLoadingAction}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/15 text-slate-200 hover:text-white rounded-xl text-xs border border-white/10 transition-colors disabled:opacity-50"
                  >
                    {aiLoadingAction === 'polish' ? <RefreshCw className="w-3 h-3 animate-spin text-amber-400" /> : <Sparkles className="w-3 h-3 text-amber-400" />}
                    <span>AI Polish & Grammar</span>
                  </button>

                  <button
                    onClick={() => handleAiAssist('summarize')}
                    disabled={!!aiLoadingAction}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/15 text-slate-200 hover:text-white rounded-xl text-xs border border-white/10 transition-colors disabled:opacity-50"
                  >
                    {aiLoadingAction === 'summarize' ? <RefreshCw className="w-3 h-3 animate-spin text-indigo-400" /> : <BookOpen className="w-3 h-3 text-indigo-400" />}
                    <span>AI Study Summary</span>
                  </button>

                  <button
                    onClick={() => handleAiAssist('flashcards')}
                    disabled={!!aiLoadingAction}
                    className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-white/5 hover:bg-white/15 text-slate-200 hover:text-white rounded-xl text-xs border border-white/10 transition-colors disabled:opacity-50"
                  >
                    {aiLoadingAction === 'flashcards' ? <RefreshCw className="w-3 h-3 animate-spin text-emerald-400" /> : <Layers className="w-3 h-3 text-emerald-400" />}
                    <span>AI Flashcards</span>
                  </button>
                </div>
              </div>

            </div>

            {/* Word Document Canvas Container */}
            <div className={`p-4 sm:p-8 min-h-[560px] ${getPaperBgClass()}`}>
              
              {/* Paginated Word Page Layout Frame */}
              <div className="max-w-4xl mx-auto">
                
                {/* Simulated Word Page Header (Visible in Paginated Preview & Print) */}
                <div className="hidden print:flex sm:flex items-center justify-between pb-4 mb-6 border-b border-white/10 text-[10px] text-slate-400 uppercase tracking-wider">
                  <span>Review You Document Studio • {activeNote.title}</span>
                  <span>Page 1 of 1</span>
                </div>

                {/* View Mode Switching: Editor, Split, or Preview */}
                {viewMode === 'editor' && (
                  <textarea
                    ref={textareaRef}
                    value={activeNote.content}
                    onChange={(e) => updateActiveNote({ content: e.target.value })}
                    placeholder="Start typing your document here... Support for rich markdown headings (#), tables (|), checklists (- [ ]), and formulas."
                    className={`w-full min-h-[480px] bg-transparent border-none focus:outline-none ${
                      activeNote.paperStyle === 'word_light' ? 'text-slate-900 placeholder-slate-400' : 'text-white placeholder-slate-500'
                    } resize-y ${getFontFamilyClass()} ${getFontSizeClass()} ${getLineSpacingClass()}`}
                  />
                )}

                {viewMode === 'preview' && (
                  <div className="min-h-[480px]">
                    <DocumentRenderer
                      content={activeNote.content}
                      onContentChange={(newContent) => updateActiveNote({ content: newContent })}
                      fontFamilyClass={getFontFamilyClass()}
                      fontSizeClass={getFontSizeClass()}
                      lineSpacingClass={getLineSpacingClass()}
                    />
                  </div>
                )}

                {viewMode === 'split' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 min-h-[480px]">
                    <div className="border-r border-white/10 pr-4">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Raw Markdown Input</div>
                      <textarea
                        ref={textareaRef}
                        value={activeNote.content}
                        onChange={(e) => updateActiveNote({ content: e.target.value })}
                        placeholder="Type markdown here..."
                        className={`w-full h-full min-h-[450px] bg-transparent border-none focus:outline-none ${
                          activeNote.paperStyle === 'word_light' ? 'text-slate-900' : 'text-white'
                        } resize-y ${getFontFamilyClass()} ${getFontSizeClass()}`}
                      />
                    </div>
                    <div className="pl-4">
                      <div className="text-[10px] font-bold text-amber-300 uppercase tracking-wider mb-2">Live Rendered View</div>
                      <DocumentRenderer
                        content={activeNote.content}
                        onContentChange={(newContent) => updateActiveNote({ content: newContent })}
                        fontFamilyClass={getFontFamilyClass()}
                        fontSizeClass={getFontSizeClass()}
                        lineSpacingClass={getLineSpacingClass()}
                      />
                    </div>
                  </div>
                )}

              </div>

            </div>

            {/* Word-Style Bottom Status Bar */}
            <div className="px-6 py-3 bg-slate-900/90 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
              
              <div className="flex items-center space-x-5">
                <span className="flex items-center space-x-1.5">
                  <AlignLeft className="w-3.5 h-3.5 text-amber-400" />
                  <span><strong>{activeNote.wordCount || 0}</strong> words</span>
                </span>
                <span className="flex items-center space-x-1.5">
                  <Hash className="w-3.5 h-3.5 text-indigo-400" />
                  <span><strong>{activeNote.charCount || 0}</strong> characters</span>
                </span>
                <span className="flex items-center space-x-1.5 hidden sm:flex">
                  <Clock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>~{readingTimeMinutes} min reading time</span>
                </span>
              </div>

              <div className="flex items-center space-x-3 text-[11px]">
                <span className="text-slate-500">Last edited: {new Date(activeNote.lastModified).toLocaleTimeString()}</span>
                <div className="flex items-center space-x-1.5 text-emerald-400 font-semibold">
                  <Save className="w-3 h-3" />
                  <span>Auto-saved</span>
                </div>
              </div>

            </div>

          </div>

        </div>

      </div>

      {/* Templates Gallery Modal */}
      {showTemplatesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-3xl bg-slate-900 border border-white/15 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto custom-scrollbar animate-scaleUp">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
                  <BookMarked className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">Starter Document Templates</h3>
                  <p className="text-xs text-slate-300">Choose a professional framework to start taking structured notes instantly.</p>
                </div>
              </div>
              <button
                onClick={() => setShowTemplatesModal(false)}
                className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {DOCUMENT_TEMPLATES.map(tmpl => (
                <div
                  key={tmpl.id}
                  onClick={() => handleCreateFromTemplate(tmpl)}
                  className="p-5 rounded-2xl bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 hover:border-amber-400/50 cursor-pointer transition-all space-y-3 group"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300">
                      {tmpl.category}
                    </span>
                    <Plus className="w-4 h-4 text-slate-400 group-hover:text-amber-400 transition-colors" />
                  </div>
                  <h4 className="font-bold text-base text-white group-hover:text-amber-300 transition-colors">
                    {tmpl.name}
                  </h4>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {tmpl.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* AI Flashcards Interactive Modal */}
      {aiFlashcardsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-2xl bg-slate-900 border border-indigo-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 animate-scaleUp">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-300 flex items-center justify-center">
                  <Layers className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">AI Extracted Flashcards</h3>
                  <p className="text-xs text-slate-300">Click any card to flip between Question and Answer.</p>
                </div>
              </div>
              <button
                onClick={() => setAiFlashcardsModal(null)}
                className="p-2 text-slate-400 hover:text-white rounded-xl bg-white/5"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-1 custom-scrollbar">
              {aiFlashcardsModal.map((card, idx) => {
                const isFlipped = flippedCardIndex === idx;
                return (
                  <div
                    key={idx}
                    onClick={() => {
                      sounds.playClick();
                      setFlippedCardIndex(isFlipped ? null : idx);
                    }}
                    className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                      isFlipped
                        ? 'bg-emerald-950/40 border-emerald-500/40 shadow-lg'
                        : 'bg-white/[0.04] border-white/10 hover:border-indigo-400/40'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400 mb-2">
                      <span className="font-bold uppercase tracking-wider">Card {idx + 1} of {aiFlashcardsModal.length}</span>
                      <span className="text-indigo-300 font-semibold">{isFlipped ? 'Answer View' : 'Question View (Click to flip)'}</span>
                    </div>
                    <div className="text-sm sm:text-base font-semibold text-white leading-relaxed">
                      {isFlipped ? (
                        <div className="text-emerald-200">{card.back}</div>
                      ) : (
                        <div className="text-white">{card.front}</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-white/10">
              <button
                onClick={() => {
                  sounds.playClick();
                  const markdownCards = aiFlashcardsModal.map((c, i) => `### 🎴 Card ${i + 1}\n- **Front:** ${c.front}\n- **Back:** ${c.back}\n`).join('\n');
                  updateActiveNote({ content: `${activeNote.content}\n\n---\n\n## 🗂️ Study Flashcards\n\n${markdownCards}` });
                  setAiFlashcardsModal(null);
                  sounds.playCorrect();
                }}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-md transition-colors"
              >
                Insert All into Document
              </button>

              <button
                onClick={() => setAiFlashcardsModal(null)}
                className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-semibold rounded-xl transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal for Any Document */}
      <DeleteConfirmModal
        isOpen={showDeleteModal}
        itemType="notebook"
        itemTitle={notes.find(n => n.id === noteToDeleteId)?.title || activeNote.title}
        onConfirm={confirmDeleteNote}
        onCancel={() => {
          setShowDeleteModal(false);
          setNoteToDeleteId(null);
        }}
      />

    </div>
  );
};
