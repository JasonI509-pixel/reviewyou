import React from 'react';
import { CheckSquare, Square, Copy, Check, Info, AlertTriangle, Lightbulb, Sparkles } from 'lucide-react';
import { sounds } from '../lib/sound';

interface DocumentRendererProps {
  content: string;
  onContentChange?: (newContent: string) => void;
  fontFamilyClass?: string;
  fontSizeClass?: string;
  lineSpacingClass?: string;
  isEditableInPreview?: boolean;
}

export const DocumentRenderer: React.FC<DocumentRendererProps> = ({
  content,
  onContentChange,
  fontFamilyClass = 'font-sans',
  fontSizeClass = 'text-base',
  lineSpacingClass = 'leading-relaxed',
}) => {
  const [copiedIndex, setCopiedIndex] = React.useState<number | null>(null);

  // Toggle checklist item in the markdown text
  const handleToggleChecklist = (lineIndex: number) => {
    if (!onContentChange) return;
    sounds.playClick();

    const lines = content.split('\n');
    if (lineIndex >= 0 && lineIndex < lines.length) {
      const line = lines[lineIndex];
      if (line.includes('- [ ] ')) {
        lines[lineIndex] = line.replace('- [ ] ', '- [x] ');
      } else if (line.includes('- [x] ') || line.includes('- [X] ')) {
        lines[lineIndex] = line.replace(/- \[[xX]\] /, '- [ ] ');
      }
      onContentChange(lines.join('\n'));
    }
  };

  const handleCopyCode = (code: string, idx: number) => {
    sounds.playClick();
    navigator.clipboard.writeText(code);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  // Helper to parse inline styles (bold, italic, code, underline, highlight, links)
  const renderInlineFormatted = (text: string): React.ReactNode => {
    // Quick regex tokenizer for inline markdown elements
    // Supports **bold**, *italic*, `code`, ==highlight==, <u>underline</u>, ~~strikethrough~~
    const tokens: React.ReactNode[] = [];
    let remaining = text;
    let keyIdx = 0;

    // Replace HTML-style underlines or tags safely
    while (remaining.length > 0) {
      // Bold + Italic ***text***
      const boldItalicMatch = remaining.match(/^(\*\*\*|___)(.+?)\1/);
      if (boldItalicMatch) {
        tokens.push(
          <strong key={keyIdx++} className="font-extrabold italic text-amber-200">
            {boldItalicMatch[2]}
          </strong>
        );
        remaining = remaining.substring(boldItalicMatch[0].length);
        continue;
      }

      // Bold **text**
      const boldMatch = remaining.match(/^(\*\*|__)(.+?)\1/);
      if (boldMatch) {
        tokens.push(
          <strong key={keyIdx++} className="font-bold text-white">
            {boldMatch[2]}
          </strong>
        );
        remaining = remaining.substring(boldMatch[0].length);
        continue;
      }

      // Italic *text* or _text_
      const italicMatch = remaining.match(/^(\*|_)(.+?)\1/);
      if (italicMatch) {
        tokens.push(
          <em key={keyIdx++} className="italic text-slate-200">
            {italicMatch[2]}
          </em>
        );
        remaining = remaining.substring(italicMatch[0].length);
        continue;
      }

      // Inline code `code`
      const codeMatch = remaining.match(/^`([^`]+)`/);
      if (codeMatch) {
        tokens.push(
          <code key={keyIdx++} className="px-1.5 py-0.5 mx-0.5 rounded-md bg-white/10 text-amber-300 font-mono text-xs border border-white/15">
            {codeMatch[1]}
          </code>
        );
        remaining = remaining.substring(codeMatch[0].length);
        continue;
      }

      // Highlight ==text==
      const highlightMatch = remaining.match(/^==(.+?)==/);
      if (highlightMatch) {
        tokens.push(
          <mark key={keyIdx++} className="bg-amber-400/30 text-amber-200 px-1 py-0.5 rounded mx-0.5 font-medium border-b-2 border-amber-400">
            {highlightMatch[1]}
          </mark>
        );
        remaining = remaining.substring(highlightMatch[0].length);
        continue;
      }

      // Strikethrough ~~text~~
      const strikeMatch = remaining.match(/^~~(.+?)~~/);
      if (strikeMatch) {
        tokens.push(
          <del key={keyIdx++} className="line-through text-slate-400">
            {strikeMatch[1]}
          </del>
        );
        remaining = remaining.substring(strikeMatch[0].length);
        continue;
      }

      // Underline <u>text</u>
      const underlineMatch = remaining.match(/^<u>(.+?)<\/u>/i);
      if (underlineMatch) {
        tokens.push(
          <u key={keyIdx++} className="underline decoration-amber-400/70 underline-offset-4">
            {underlineMatch[1]}
          </u>
        );
        remaining = remaining.substring(underlineMatch[0].length);
        continue;
      }

      // Normal character chunk until next formatting token
      const nextSpecial = remaining.search(/(\*|_|`|==|~~|<u)/);
      if (nextSpecial === -1) {
        tokens.push(<span key={keyIdx++}>{remaining}</span>);
        break;
      } else if (nextSpecial === 0) {
        tokens.push(<span key={keyIdx++}>{remaining[0]}</span>);
        remaining = remaining.substring(1);
      } else {
        tokens.push(<span key={keyIdx++}>{remaining.substring(0, nextSpecial)}</span>);
        remaining = remaining.substring(nextSpecial);
      }
    }

    return tokens;
  };

  // Parse lines and render blocks
  const renderDocumentBlocks = () => {
    if (!content || !content.trim()) {
      return (
        <div className="py-20 text-center text-slate-500 italic select-none">
          (Empty document. Start typing or choose a starter template from above...)
        </div>
      );
    }

    const lines = content.split('\n');
    const blocks: React.ReactNode[] = [];
    let i = 0;
    let blockKey = 0;

    while (i < lines.length) {
      const line = lines[i];

      // 1. Code Blocks (``` ... ```)
      if (line.trim().startsWith('```')) {
        const lang = line.trim().replace(/^```/, '');
        const codeLines: string[] = [];
        i++;
        while (i < lines.length && !lines[i].trim().startsWith('```')) {
          codeLines.push(lines[i]);
          i++;
        }
        const fullCode = codeLines.join('\n');
        const currentIdx = blockKey++;
        blocks.push(
          <div key={currentIdx} className="my-4 rounded-2xl bg-slate-950/90 border border-white/15 overflow-hidden shadow-xl font-mono text-xs">
            <div className="flex items-center justify-between px-4 py-2 bg-white/5 border-b border-white/10 text-slate-400 text-[11px]">
              <span className="uppercase tracking-wider font-semibold text-amber-300">{lang || 'Code Snippet'}</span>
              <button
                onClick={() => handleCopyCode(fullCode, currentIdx)}
                className="flex items-center space-x-1 hover:text-white transition-colors"
                title="Copy code"
              >
                {copiedIndex === currentIdx ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-4 overflow-x-auto text-slate-200 leading-relaxed custom-scrollbar">
              <code>{fullCode}</code>
            </pre>
          </div>
        );
        i++;
        continue;
      }

      // 2. Markdown Tables (| ... |)
      if (line.trim().startsWith('|') && line.trim().endsWith('|')) {
        const tableLines: string[] = [];
        while (i < lines.length && lines[i].trim().startsWith('|') && lines[i].trim().endsWith('|')) {
          tableLines.push(lines[i]);
          i++;
        }

        if (tableLines.length >= 2) {
          const headerRow = tableLines[0].split('|').slice(1, -1).map(c => c.trim());
          const dataRows = tableLines.slice(2).map(r => r.split('|').slice(1, -1).map(c => c.trim()));

          blocks.push(
            <div key={blockKey++} className="my-5 overflow-x-auto rounded-2xl border border-white/15 bg-white/[0.03] shadow-lg">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-white/10 border-b border-white/15 text-white">
                    {headerRow.map((h, hIdx) => (
                      <th key={hIdx} className="px-4 py-3 font-bold">
                        {renderInlineFormatted(h)}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/10">
                  {dataRows.map((row, rIdx) => (
                    <tr key={rIdx} className="hover:bg-white/[0.04] transition-colors">
                      {row.map((cell, cIdx) => (
                        <td key={cIdx} className="px-4 py-2.5 text-slate-300">
                          {renderInlineFormatted(cell)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );
          continue;
        }
      }

      // 3. Horizontal Rule (--- or ***)
      if (line.trim() === '---' || line.trim() === '***' || line.trim() === '___') {
        blocks.push(
          <hr key={blockKey++} className="my-6 border-t border-white/15" />
        );
        i++;
        continue;
      }

      // 4. Blockquote / Callout (> ...)
      if (line.trim().startsWith('>')) {
        const quoteLines: string[] = [];
        while (i < lines.length && lines[i].trim().startsWith('>')) {
          quoteLines.push(lines[i].replace(/^>\s?/, ''));
          i++;
        }
        const fullQuote = quoteLines.join('\n');
        blocks.push(
          <div key={blockKey++} className="my-4 p-4 rounded-2xl bg-amber-500/10 border-l-4 border-amber-400 border-y border-r border-amber-400/20 shadow-md">
            <div className="flex items-start space-x-2.5 text-amber-200">
              <Lightbulb className="w-5 h-5 flex-shrink-0 text-amber-400 mt-0.5" />
              <div className="text-xs sm:text-sm leading-relaxed text-amber-100 font-medium">
                {renderInlineFormatted(fullQuote)}
              </div>
            </div>
          </div>
        );
        continue;
      }

      // 5. Headings
      if (line.startsWith('# ')) {
        blocks.push(
          <h1 key={blockKey++} className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-7 mb-3 pb-2 border-b border-white/15">
            {renderInlineFormatted(line.replace(/^#\s+/, ''))}
          </h1>
        );
        i++;
        continue;
      }
      if (line.startsWith('## ')) {
        blocks.push(
          <h2 key={blockKey++} className="text-xl sm:text-2xl font-bold text-amber-300 tracking-tight mt-6 mb-2 flex items-center space-x-2">
            <span>{renderInlineFormatted(line.replace(/^##\s+/, ''))}</span>
          </h2>
        );
        i++;
        continue;
      }
      if (line.startsWith('### ')) {
        blocks.push(
          <h3 key={blockKey++} className="text-lg sm:text-xl font-bold text-indigo-300 tracking-tight mt-5 mb-1.5">
            {renderInlineFormatted(line.replace(/^###\s+/, ''))}
          </h3>
        );
        i++;
        continue;
      }
      if (line.startsWith('#### ')) {
        blocks.push(
          <h4 key={blockKey++} className="text-base sm:text-lg font-semibold text-slate-200 mt-4 mb-1">
            {renderInlineFormatted(line.replace(/^####\s+/, ''))}
          </h4>
        );
        i++;
        continue;
      }

      // 6. Interactive Task / Checklist items (- [ ] or - [x])
      if (line.trim().startsWith('- [ ] ') || line.trim().startsWith('- [x] ') || line.trim().startsWith('- [X] ')) {
        const isChecked = line.trim().startsWith('- [x] ') || line.trim().startsWith('- [X] ');
        const taskText = line.replace(/^\s*-\s*\[[ xX]\]\s*/, '');
        const currentLineIndex = i;

        blocks.push(
          <div
            key={blockKey++}
            onClick={() => handleToggleChecklist(currentLineIndex)}
            className={`my-1.5 flex items-start space-x-3 p-2 rounded-xl cursor-pointer transition-colors ${
              isChecked ? 'bg-emerald-500/10 text-emerald-300/80 line-through' : 'hover:bg-white/5 text-slate-200'
            }`}
          >
            {isChecked ? (
              <CheckSquare className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" />
            ) : (
              <Square className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
            )}
            <span className="text-xs sm:text-sm font-medium select-none">
              {renderInlineFormatted(taskText)}
            </span>
          </div>
        );
        i++;
        continue;
      }

      // 7. Bullet Lists (- ... or * ...)
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const bulletText = line.replace(/^\s*[-*]\s+/, '');
        blocks.push(
          <li key={blockKey++} className="ml-5 my-1 text-slate-200 list-disc text-xs sm:text-sm">
            {renderInlineFormatted(bulletText)}
          </li>
        );
        i++;
        continue;
      }

      // 8. Numbered Lists (1. ...)
      const numMatch = line.match(/^\s*(\d+)\.\s+(.*)/);
      if (numMatch) {
        blocks.push(
          <div key={blockKey++} className="ml-2 my-1 flex items-start space-x-2 text-slate-200 text-xs sm:text-sm">
            <span className="font-bold text-amber-400/90 w-5 flex-shrink-0">{numMatch[1]}.</span>
            <div className="flex-1">{renderInlineFormatted(numMatch[2])}</div>
          </div>
        );
        i++;
        continue;
      }

      // 9. Blank line / Paragraph separator
      if (!line.trim()) {
        blocks.push(<div key={blockKey++} className="h-3" />);
        i++;
        continue;
      }

      // 10. Standard Paragraph
      blocks.push(
        <p key={blockKey++} className="my-1.5 text-slate-200 text-xs sm:text-sm leading-relaxed">
          {renderInlineFormatted(line)}
        </p>
      );
      i++;
    }

    return blocks;
  };

  return (
    <div className={`document-formatted-view ${fontFamilyClass} ${fontSizeClass} ${lineSpacingClass} select-text`}>
      {renderDocumentBlocks()}
    </div>
  );
};
