import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  Award, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  TrendingUp, 
  Clock, 
  RotateCcw, 
  BookOpen, 
  Zap, 
  Target, 
  AlertTriangle, 
  ChevronDown, 
  ChevronUp, 
  ArrowRight,
  Share2,
  Check,
  Flame,
  BrainCircuit,
  MessageSquare
} from 'lucide-react';
import { QuizAttempt, QuestionResult, FeedbackSummary, Quiz, NotebookEntry } from '../types';
import { sounds } from '../lib/sound';
import { safeFetchJson } from '../lib/api';

interface TestResultsModalProps {
  attempt: QuizAttempt;
  onRetakeTest: (quizId: string) => void;
  onStartTargetedDrill: (missedQuestions: QuestionResult[], subject: string) => void;
  onSaveNoteToNotebook: (note: { title: string; content: string; tags: string[]; subject: string }) => void;
  onClose: () => void;
  onOpenCoachWithTopic?: (topic: string) => void;
}

export const TestResultsModal: React.FC<TestResultsModalProps> = ({
  attempt,
  onRetakeTest,
  onStartTargetedDrill,
  onSaveNoteToNotebook,
  onClose,
  onOpenCoachWithTopic,
}) => {
  const [feedback, setFeedback] = useState<FeedbackSummary | null>(attempt.feedbackSummary || null);
  const [isLoadingFeedback, setIsLoadingFeedback] = useState(!attempt.feedbackSummary);
  const [expandedQuestionId, setExpandedQuestionId] = useState<string | null>(null);
  const [noteSaved, setNoteSaved] = useState(false);

  // Trigger celebratory confetti on high score or improvement
  useEffect(() => {
    sounds.playCompletionFanfare();
    if (attempt.scorePercentage >= 80 || (attempt.scoreImprovement && attempt.scoreImprovement > 0)) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#4f46e5', '#10b981', '#f59e0b', '#ec4899'],
        });
      } catch {
        // ignore
      }
    }
  }, [attempt]);

  // Fetch AI In-depth feedback if not cached
  useEffect(() => {
    if (feedback) return;

    const fetchFeedback = async () => {
      setIsLoadingFeedback(true);
      try {
        const data = await safeFetchJson<{ feedback: FeedbackSummary }>('/api/generate-feedback', {
          method: 'POST',
          body: JSON.stringify({
            quizTitle: attempt.quizTitle,
            subject: attempt.subject,
            totalQuestions: attempt.totalQuestions,
            correctCount: attempt.correctCount,
            scorePercentage: attempt.scorePercentage,
            totalDurationSeconds: attempt.totalDurationSeconds,
            questionResults: attempt.questionResults,
            previousAttemptScore: attempt.previousAttemptScore,
          }),
        });

        if (data && data.feedback) {
          setFeedback(data.feedback);
        }
      } catch (err) {
        console.error('Error fetching AI diagnostic feedback:', err);
      } finally {
        setIsLoadingFeedback(false);
      }
    };

    fetchFeedback();
  }, [attempt, feedback]);

  const missedQuestions = attempt.questionResults.filter(q => !q.isCorrect);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}m ${s < 10 ? '0' : ''}${s}s`;
  };

  const handleSaveToNotebook = () => {
    sounds.playClick();
    if (feedback?.generatedNotebookNote) {
      onSaveNoteToNotebook({
        title: feedback.generatedNotebookNote.title || `${attempt.quizTitle} - Review Guide`,
        content: feedback.generatedNotebookNote.content,
        tags: feedback.generatedNotebookNote.tags || [attempt.subject, 'Review'],
        subject: attempt.subject,
      });
      setNoteSaved(true);
      sounds.playCorrect();
    }
  };

  const toggleExpandQuestion = (id: string) => {
    sounds.playClick();
    setExpandedQuestionId(prev => (prev === id ? null : id));
  };

  // Grade color
  const getGradeColor = (score: number) => {
    if (score >= 90) return 'text-emerald-600 bg-emerald-50 border-emerald-200';
    if (score >= 75) return 'text-indigo-600 bg-indigo-50 border-indigo-200';
    if (score >= 60) return 'text-amber-600 bg-amber-50 border-amber-200';
    return 'text-rose-600 bg-rose-50 border-rose-200';
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 space-y-8 animate-fadeIn">
      
      {/* Top Banner / Scorecard */}
      <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] relative overflow-hidden text-white">
        
        {/* Decorative Background Glow */}
        <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          
          {/* Score Badge */}
          <div className="md:col-span-4 text-center md:text-left flex flex-col items-center md:items-start space-y-2">
            <span className="px-3 py-1 bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 rounded-full text-xs font-semibold uppercase tracking-wider backdrop-blur-md">
              {attempt.subject} Diagnostic
            </span>
            <div className="flex items-baseline space-x-2">
              <span className="text-5xl sm:text-6xl font-extrabold text-white tracking-tight drop-shadow-md">
                {attempt.scorePercentage}%
              </span>
              <span className="text-lg font-bold text-slate-400">
                ({attempt.correctCount}/{attempt.totalQuestions})
              </span>
            </div>
            
            {/* Score Comparison with Previous Attempt */}
            {attempt.scoreImprovement !== undefined && attempt.scoreImprovement !== 0 && (
              <div className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold backdrop-blur-md border ${
                attempt.scoreImprovement > 0
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30'
                  : 'bg-white/10 text-slate-300 border-white/10'
              }`}>
                <TrendingUp className="w-3.5 h-3.5" />
                <span>
                  {attempt.scoreImprovement > 0 ? `+${attempt.scoreImprovement}% improvement vs last attempt!` : `${attempt.scoreImprovement}% vs last attempt`}
                </span>
              </div>
            )}

            <p className="text-xs text-slate-300 font-medium">
              Completed in {formatTime(attempt.totalDurationSeconds)} (~{attempt.avgTimePerQuestion}s / question)
            </p>
          </div>

          {/* Core Highlights / Quick Action Grid */}
          <div className="md:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-3">
            
            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-center backdrop-blur-md">
              <Clock className="w-5 h-5 text-indigo-400 mx-auto mb-1" />
              <p className="text-[11px] text-slate-400 font-semibold uppercase">Pacing Speed</p>
              <p className="text-sm font-bold text-white">{attempt.avgTimePerQuestion}s / question</p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-center backdrop-blur-md">
              <Award className="w-5 h-5 text-amber-400 mx-auto mb-1" />
              <p className="text-[11px] text-slate-400 font-semibold uppercase">Mastery State</p>
              <p className="text-sm font-bold text-white">
                {feedback?.masteryRating || (attempt.scorePercentage >= 80 ? 'Mastered' : 'Developing')}
              </p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-2xl p-4 text-center backdrop-blur-md">
              <Target className="w-5 h-5 text-rose-400 mx-auto mb-1" />
              <p className="text-[11px] text-slate-400 font-semibold uppercase">Missed Areas</p>
              <p className="text-sm font-bold text-white">
                {missedQuestions.length} {missedQuestions.length === 1 ? 'Concept' : 'Concepts'}
              </p>
            </div>

          </div>

        </div>

        {/* Action Button Bar */}
        <div className="mt-6 pt-5 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <button
              onClick={() => { sounds.playClick(); onRetakeTest(attempt.quizId); }}
              className="inline-flex items-center space-x-2 px-4 py-2.5 bg-white/10 hover:bg-white/15 text-white rounded-xl text-xs font-semibold border border-white/15 backdrop-blur-md transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Retake Test (Beat Score)</span>
            </button>

            {missedQuestions.length > 0 && (
              <button
                onClick={() => {
                  sounds.playClick();
                  onStartTargetedDrill(missedQuestions, attempt.subject);
                }}
                className="inline-flex items-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 hover:to-purple-500 text-white rounded-xl text-xs font-semibold shadow-lg border border-white/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Launch Targeted Weak-Spot Drill ({missedQuestions.length})</span>
              </button>
            )}
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2 text-slate-400 hover:text-white text-xs font-semibold transition-colors"
          >
            Back to Tests
          </button>
        </div>

      </div>

      {/* AI In-Depth Diagnostic Feedback Section */}
      <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6 text-white">
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 flex items-center justify-center backdrop-blur-md">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="font-bold text-white text-base sm:text-lg">
                AI Diagnostic Performance Analysis
              </h2>
              <p className="text-xs text-slate-400">Personalized breakdown generated by Review You</p>
            </div>
          </div>

          {feedback?.generatedNotebookNote && (
            <button
              onClick={handleSaveToNotebook}
              disabled={noteSaved}
              className={`inline-flex items-center space-x-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all backdrop-blur-md ${
                noteSaved
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                  : 'bg-indigo-500/20 text-indigo-200 hover:bg-indigo-500/30 border border-indigo-400/30'
              }`}
            >
              {noteSaved ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Saved to Study Notebook</span>
                </>
              ) : (
                <>
                  <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Save Review Guide to Notebook</span>
                </>
              )}
            </button>
          )}
        </div>

        {isLoadingFeedback ? (
          <div className="py-12 text-center space-y-3">
            <div className="w-8 h-8 border-3 border-indigo-400 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm font-semibold text-white">Generating in-depth diagnostic feedback...</p>
            <p className="text-xs text-slate-400">Analyzing your speed, answer patterns, and topic mastery.</p>
          </div>
        ) : feedback ? (
          <div className="space-y-6">
            
            {/* Overall Analysis Quote */}
            <div className="p-5 bg-white/5 border border-white/10 rounded-2xl backdrop-blur-md">
              <p className="text-xs font-bold uppercase tracking-wider text-indigo-300 mb-1">
                Executive Coach Summary
              </p>
              <p className="text-sm text-slate-200 leading-relaxed font-medium">
                "{feedback.overallAnalysis}"
              </p>
              {feedback.speedInsight && (
                <p className="text-xs text-slate-400 mt-3 pt-2 border-t border-white/10 flex items-center space-x-1.5">
                  <Clock className="w-3.5 h-3.5 text-indigo-400 flex-shrink-0" />
                  <span><strong>Pace Critique:</strong> {feedback.speedInsight}</span>
                </p>
              )}
            </div>

            {/* Strengths & Improvement 2-Column Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Strengths */}
              <div className="bg-emerald-500/10 border border-emerald-400/25 rounded-2xl p-5 space-y-3 backdrop-blur-md">
                <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-300 flex items-center space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Mastered Strengths</span>
                </h3>
                <ul className="space-y-2 text-xs text-emerald-200">
                  {feedback.strengthAreas.map((item, idx) => (
                    <li key={idx} className="flex items-start space-x-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
                      <span className="leading-relaxed">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Areas Needing Improvement */}
              <div className="bg-rose-500/10 border border-rose-400/25 rounded-2xl p-5 space-y-3 backdrop-blur-md">
                <h3 className="text-xs font-bold uppercase tracking-wider text-rose-300 flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  <span>Areas Needing Review</span>
                </h3>
                <ul className="space-y-2 text-xs text-rose-200">
                  {feedback.improvementAreas.map((item, idx) => (
                    <li key={idx} className="flex items-start space-x-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-rose-400 mt-1.5 flex-shrink-0" />
                      <span className="leading-relaxed">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

            </div>

            {/* Weak Concepts Quick Tips */}
            {feedback.weakConceptsToReview && feedback.weakConceptsToReview.length > 0 && (
              <div className="bg-amber-500/10 border border-amber-400/25 rounded-2xl p-5 space-y-3 backdrop-blur-md">
                <h3 className="text-xs font-bold uppercase tracking-wider text-amber-300 flex items-center space-x-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <span>Memory Boosters & Recovery Tips</span>
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {feedback.weakConceptsToReview.map((conceptItem, idx) => (
                    <div key={idx} className="bg-white/5 border border-white/10 rounded-xl p-3.5 space-y-1.5 text-xs backdrop-blur-md">
                      <p className="font-bold text-white">{conceptItem.concept}</p>
                      <p className="text-slate-300 text-[11px]"><span className="font-semibold text-amber-300">Trap:</span> {conceptItem.whyDifficult}</p>
                      <p className="text-indigo-200 text-[11px] bg-indigo-500/20 p-2 rounded-lg font-medium border border-indigo-400/20">
                        💡 <span className="font-semibold">Quick Tip:</span> {conceptItem.quickTip}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        ) : (
          <p className="text-xs text-slate-400">Diagnostic feedback could not be loaded.</p>
        )}

      </div>

      {/* Question-by-Question Review */}
      <div className="bg-white/[0.08] backdrop-blur-xl border border-white/15 rounded-3xl p-6 sm:p-8 shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-6 text-white">
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div>
            <h3 className="font-bold text-white text-base sm:text-lg">
              Detailed Question Review ({attempt.questionResults.length})
            </h3>
            <p className="text-xs text-slate-400">Click any question to inspect model explanations and timing.</p>
          </div>
          <div className="flex items-center space-x-3 text-xs">
            <span className="flex items-center space-x-1 text-emerald-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{attempt.correctCount} Correct</span>
            </span>
            <span className="flex items-center space-x-1 text-rose-300">
              <XCircle className="w-3.5 h-3.5 text-rose-400" />
              <span>{attempt.totalQuestions - attempt.correctCount} Missed</span>
            </span>
          </div>
        </div>

        <div className="space-y-3">
          {attempt.questionResults.map((result, idx) => {
            const isExpanded = expandedQuestionId === result.questionId;

            return (
              <div
                key={result.questionId}
                className={`border rounded-2xl transition-all overflow-hidden backdrop-blur-md ${
                  result.isCorrect 
                    ? 'border-white/15 bg-white/5 hover:border-white/25' 
                    : 'border-rose-400/30 bg-rose-500/10'
                }`}
              >
                {/* Header Toggle */}
                <button
                  onClick={() => toggleExpandQuestion(result.questionId)}
                  className="w-full text-left p-4 sm:p-5 flex items-center justify-between gap-4"
                >
                  <div className="flex items-center space-x-3 min-w-0">
                    <div className={`w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 ${
                      result.isCorrect 
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30' 
                        : 'bg-rose-500/20 text-rose-300 border border-rose-400/30'
                    }`}>
                      {result.isCorrect ? <Check className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center space-x-2 text-[11px] text-slate-400 font-semibold mb-0.5">
                        <span>Q{idx + 1}</span>
                        <span>•</span>
                        <span>{result.topicTag || 'Concept'}</span>
                        <span>•</span>
                        <span>{result.timeSpentSeconds}s</span>
                      </div>
                      <p className="text-xs sm:text-sm font-semibold text-white truncate">
                        {result.questionText}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 flex-shrink-0">
                    <span className={`px-2.5 py-0.5 rounded-lg text-[11px] font-bold border ${
                      result.isCorrect ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30' : 'bg-rose-500/20 text-rose-300 border-rose-400/30'
                    }`}>
                      {result.isCorrect ? 'Correct' : 'Incorrect'}
                    </span>
                    {isExpanded ? <ChevronUp className="w-4 h-4 text-slate-400" /> : <ChevronDown className="w-4 h-4 text-slate-400" />}
                  </div>
                </button>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="px-5 pb-5 pt-2 border-t border-white/10 bg-black/20 space-y-3.5 text-xs">
                    
                    {/* Prompt Full */}
                    <div>
                      <p className="font-bold text-white text-sm">{result.questionText}</p>
                    </div>

                    {/* Answers Comparison */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div className={`p-3 rounded-xl border ${
                        result.isCorrect 
                          ? 'bg-emerald-500/10 border-emerald-400/30 text-emerald-200' 
                          : 'bg-rose-500/10 border-rose-400/30 text-rose-200'
                      }`}>
                        <p className="font-semibold text-[10px] uppercase tracking-wider mb-1 text-slate-300">Your Answer:</p>
                        <p className="font-medium text-white">{result.userAnswer || '(Blank)'}</p>
                      </div>

                      <div className="p-3 rounded-xl border bg-emerald-500/10 border-emerald-400/30 text-emerald-200">
                        <p className="font-semibold text-[10px] uppercase tracking-wider text-emerald-300 mb-1">Correct Model Answer:</p>
                        <p className="font-medium text-white">{result.correctAnswer}</p>
                      </div>
                    </div>

                    {/* AI Explanation */}
                    {result.explanation && (
                      <div className="p-4 bg-white/5 border border-white/10 rounded-xl text-slate-200 leading-relaxed space-y-2 backdrop-blur-md">
                        <p className="font-bold text-indigo-300 text-[11px] uppercase flex items-center space-x-1.5">
                          <BrainCircuit className="w-4 h-4 text-indigo-400" />
                          <span>In-Depth Explanation & Practical Examples:</span>
                        </p>
                        <div className="whitespace-pre-line text-xs text-slate-200 leading-relaxed">
                          {result.explanation}
                        </div>
                      </div>
                    )}

                    {/* AI Short Answer feedback if present */}
                    {result.aiFeedback && (
                      <div className="p-3.5 bg-indigo-500/15 border border-indigo-400/30 rounded-xl text-indigo-200 space-y-1">
                        <p className="font-bold text-[11px] uppercase text-indigo-300">AI Grader Feedback:</p>
                        <p>{result.aiFeedback}</p>
                      </div>
                    )}

                    {/* Ask AI Coach About This Question */}
                    {onOpenCoachWithTopic && (
                      <div className="pt-1 flex justify-end">
                        <button
                          onClick={() => onOpenCoachWithTopic(result.questionText)}
                          className="text-indigo-300 hover:text-white font-semibold text-xs flex items-center space-x-1"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Ask AI Coach to explain this question more deeply</span>
                        </button>
                      </div>
                    )}

                  </div>
                )}

              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
