export type QuestionType = 'multiple_choice' | 'true_false' | 'short_answer';

export type DifficultyLevel = 'easy' | 'medium' | 'hard' | 'adaptive';

export type StudyCategory = 'book' | 'test' | 'certificate' | 'other';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  avatarSeed?: string;
  studyGoal?: string;
  targetExam?: string;
  themeColor?: 'gold' | 'indigo' | 'emerald' | 'cyan' | 'rose' | 'purple' | 'orange';
  createdAt: string;
  lastLoginAt: string;
}

export interface BookReviewInfo {
  category?: StudyCategory;
  testName: string;
  gradeLevel?: string;
  learningTopic: string;
  bookTitle?: string;
  author?: string;
  chaptersOrPart?: string;
  keyThemesOrConcepts?: string;
  targetAudience?: string;
  additionalInstructions?: string;
  difficulty: DifficultyLevel;
  questionCount: number;
  questionTypes: QuestionType[];
}

export interface CopilotPromptData {
  category?: StudyCategory;
  testName: string;
  generatedPrompt: string;
  systemDirective: string;
  schemaExample: string;
  metadata: {
    category?: string;
    gradeLevel?: string;
    learningTopic?: string;
    subject: string;
    difficulty: DifficultyLevel;
    questionCount: number;
  };
}

export interface QuizQuestion {
  id: string;
  type: QuestionType;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  hint?: string;
  topicTag: string;
  timeLimitSeconds: number;
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  subject: string;
  studyCategory?: StudyCategory;
  gradeLevel?: string;
  learningGoals?: string;
  difficulty: DifficultyLevel;
  studyQuestions?: QuizQuestion[];
  questions: QuizQuestion[];
  createdAt: string;
  sourceNoteId?: string;
  sourcePrompt?: string;
  isCustomDrill?: boolean;
  bookTitle?: string;
  bookAuthor?: string;
  bookChapters?: string;
  copilotPrompt?: string;
  isCopilotGenerated?: boolean;
  bestScore?: number;
  bestTimeSeconds?: number;
  attemptsCount?: number;
}

export interface QuestionResult {
  questionId: string;
  questionText: string;
  type: QuestionType;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  timeSpentSeconds: number;
  pointsEarned?: number;
  aiFeedback?: string;
  keyPointsIncluded?: string[];
  keyPointsMissed?: string[];
  topicTag?: string;
  explanation?: string;
}

export interface FeedbackSummary {
  overallAnalysis: string;
  masteryRating?: string;
  strengthAreas: string[];
  improvementAreas: string[];
  speedInsight: string;
  scoreComparisonText?: string;
  recommendedAction: string;
  weakConceptsToReview: {
    concept: string;
    whyDifficult: string;
    quickTip: string;
  }[];
  generatedNotebookNote?: {
    title: string;
    content: string;
    tags: string[];
  };
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  quizTitle: string;
  subject: string;
  difficulty: DifficultyLevel;
  completedAt: string;
  totalQuestions: number;
  correctCount: number;
  scorePercentage: number;
  totalDurationSeconds: number;
  avgTimePerQuestion: number;
  questionResults: QuestionResult[];
  feedbackSummary?: FeedbackSummary;
  previousAttemptScore?: number;
  scoreImprovement?: number;
  timeImprovementSeconds?: number;
}

export interface FreeformNote {
  id: string;
  title: string;
  content: string;
  createdAt: string;
  lastModified: string;
  wordCount: number;
  charCount?: number;
  paragraphCount?: number;
  tags?: string[];
  category?: string;
  isFavorite?: boolean;
  paperStyle?: 'plain' | 'lined' | 'grid' | 'slate' | 'parchment' | 'word_light' | 'word_dark';
  fontFamily?: 'sans' | 'serif' | 'mono' | 'academic' | 'casual';
  fontSize?: 'xs' | 'sm' | 'base' | 'lg' | 'xl' | '2xl';
  lineSpacing?: '1.0' | '1.15' | '1.5' | '2.0';
  layoutMode?: 'paginated' | 'seamless' | 'split';
  pageSize?: 'letter' | 'a4' | 'legal';
  pageOrientation?: 'portrait' | 'landscape';
}

export interface NotebookEntry {
  id: string;
  title: string;
  subject: string;
  content: string;
  tags: string[];
  lastUpdated: string;
  generatedQuizIds?: string[];
  keyTerms?: string[];
}

export interface SubjectStats {
  subject: string;
  testsTaken: number;
  avgScore: number;
  bestScore: number;
  avgSpeedSeconds: number;
  masteryLevel: number; // 0 to 100
  recentTrend: 'up' | 'down' | 'steady';
  totalQuestionsAnswered: number;
  correctQuestionsAnswered: number;
}

export interface ConceptExplanation {
  title: string;
  summary: string;
  detailedExplanation: string;
  realWorldAnalogy: string;
  examTrapToAvoid: string;
  mnemonic: string;
  checkQuestions: {
    question: string;
    options: string[];
    correctAnswer: string;
    explanation: string;
  }[];
}
