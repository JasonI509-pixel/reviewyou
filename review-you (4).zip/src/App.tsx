/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Quiz, 
  QuizAttempt, 
  NotebookEntry, 
  QuestionResult, 
  FeedbackSummary,
  UserAccount
} from './types';
import { 
  loadQuizzes, 
  saveQuizzes, 
  loadNotebook, 
  saveNotebook, 
  loadAttempts, 
  saveAttempts,
  calculateSubjectStats,
  getActiveUser,
  logoutUser,
  loadAccounts,
  saveAccounts,
  syncAccountDataToServer,
  fetchUserDataFromServer
} from './lib/storage';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { TestGenerator } from './components/TestGenerator';
import { ActiveTestSession } from './components/ActiveTestSession';
import { TestResultsModal } from './components/TestResultsModal';
import { StudyNotebook } from './components/StudyNotebook';
import { FreeformNotebook } from './components/FreeformNotebook';
import { ProgressAnalytics } from './components/ProgressAnalytics';
import { AIConceptCoach } from './components/AIConceptCoach';
import { AuthModal } from './components/AuthModal';
import { ThemePickerModal } from './components/ThemePickerModal';
import { ThemeColor, THEMES, getSavedTheme, setSavedTheme, applyThemeCss } from './lib/theme';
import { sounds } from './lib/sound';
import { safeFetchJson } from './lib/api';
import { Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'quizzes' | 'test_session' | 'notebook' | 'analytics' | 'coach'>('quizzes');
  
  // User Account & Theme state
  const [activeUser, setActiveUser] = useState<UserAccount | null>(() => getActiveUser());
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authInitialMode, setAuthInitialMode] = useState<'signup' | 'login'>('signup');
  const [currentTheme, setCurrentTheme] = useState<ThemeColor>(() => {
    const user = getActiveUser();
    return (user?.themeColor as ThemeColor) || getSavedTheme() || 'gold';
  });
  const [showThemeModal, setShowThemeModal] = useState<boolean>(false);

  // Storage states
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [notebookEntries, setNotebookEntries] = useState<NotebookEntry[]>([]);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  
  // Active Test States
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [activeAttemptResult, setActiveAttemptResult] = useState<QuizAttempt | null>(null);
  const [isViewingPastAttempt, setIsViewingPastAttempt] = useState<QuizAttempt | null>(null);

  // Cross-component triggers
  const [prefilledTopic, setPrefilledTopic] = useState<string>('');
  const [prefilledNoteId, setPrefilledNoteId] = useState<string>('');
  const [coachPrompt, setCoachPrompt] = useState<string>('');

  // App settings
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [streakCount, setStreakCount] = useState<number>(3);
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'info' } | null>(null);

  // Apply theme on mount and when changed
  useEffect(() => {
    applyThemeCss(currentTheme);
  }, [currentTheme]);

  // Initialize data on mount and pull latest from cloud if authenticated
  useEffect(() => {
    const loadedQ = loadQuizzes();
    const loadedN = loadNotebook();
    const loadedA = loadAttempts();
    setQuizzes(loadedQ);
    setNotebookEntries(loadedN);
    setAttempts(loadedA);

    // Sync down cloud library if user is logged in
    const user = getActiveUser();
    if (user?.email) {
      fetchUserDataFromServer(user.email).then((updated) => {
        if (updated) {
          setQuizzes(loadQuizzes());
          setNotebookEntries(loadNotebook());
          setAttempts(loadAttempts());
        }
      });
    }

    // Track study streak
    const lastDate = localStorage.getItem('review_you_last_study_date');
    const todayStr = new Date().toDateString();
    const savedStreak = parseInt(localStorage.getItem('review_you_streak') || '3', 10);
    
    if (lastDate !== todayStr) {
      localStorage.setItem('review_you_last_study_date', todayStr);
      const nextStreak = savedStreak + 1;
      setStreakCount(nextStreak);
      localStorage.setItem('review_you_streak', nextStreak.toString());
    } else {
      setStreakCount(savedStreak);
    }
  }, []);

  const showToast = (text: string, type: 'success' | 'info' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleSelectTheme = (theme: ThemeColor) => {
    setCurrentTheme(theme);
    setSavedTheme(theme);
    if (activeUser) {
      const updated = { ...activeUser, themeColor: theme };
      setActiveUser(updated);
      saveAccounts(loadAccounts().map(a => a.id === updated.id ? updated : a));
      syncAccountDataToServer(activeUser.email);
    }
    showToast(`Theme changed to ${THEMES[theme]?.name}!`);
  };

  const handleAuthenticated = (user: UserAccount) => {
    setActiveUser(user);
    if (user.themeColor && THEMES[user.themeColor]) {
      setCurrentTheme(user.themeColor);
      setSavedTheme(user.themeColor);
    }
    setQuizzes(loadQuizzes());
    setNotebookEntries(loadNotebook());
    setAttempts(loadAttempts());
    setShowAuthModal(false);
    showToast(`Welcome, ${user.name}! Your workspace is synced across all devices.`);
  };

  const handleLogout = () => {
    logoutUser();
    setActiveUser(null);
    setActiveQuiz(null);
    setActiveAttemptResult(null);
    setIsViewingPastAttempt(null);
    showToast('Signed out of Review You.', 'info');
  };

  const openAuth = (mode: 'signup' | 'login') => {
    setAuthInitialMode(mode);
    setShowAuthModal(true);
  };

  // Start a Quiz
  const handleStartQuiz = (quiz: Quiz) => {
    sounds.playClick();
    setActiveQuiz(quiz);
    setActiveAttemptResult(null);
    setIsViewingPastAttempt(null);
    setCurrentTab('test_session');
  };

  // Save new Quiz from AI generator or 1-Click Importer
  const handleSaveNewQuiz = (newQuiz: Quiz) => {
    const exists = quizzes.find(q => q.id === newQuiz.id);
    let updated: Quiz[];
    if (exists) {
      updated = quizzes.map(q => q.id === newQuiz.id ? newQuiz : q);
    } else {
      updated = [newQuiz, ...quizzes];
    }
    setQuizzes(updated);
    saveQuizzes(updated);
    syncAccountDataToServer(activeUser?.email);
    showToast(`Test "${newQuiz.title}" saved to library!`);
  };

  // Delete Quiz
  const handleDeleteQuiz = (quizId: string) => {
    sounds.playClick();
    const updated = quizzes.filter(q => q.id !== quizId);
    setQuizzes(updated);
    saveQuizzes(updated);
    syncAccountDataToServer(activeUser?.email);
    if (activeQuiz?.id === quizId) {
      setActiveQuiz(null);
      setCurrentTab('quizzes');
    }
    showToast('Test removed from library.', 'info');
  };

  // Complete a Test Session
  const handleCompleteTest = (
    results: QuestionResult[],
    totalDurationSeconds: number,
    correctCount: number,
    scorePercentage: number
  ) => {
    if (!activeQuiz) return;

    // Look for previous best score on this specific quiz
    const previousAttemptsForQuiz = attempts.filter(a => a.quizId === activeQuiz.id);
    const previousLastScore = previousAttemptsForQuiz.length > 0
      ? previousAttemptsForQuiz[0].scorePercentage
      : undefined;

    const scoreImprovement = previousLastScore !== undefined 
      ? scorePercentage - previousLastScore 
      : undefined;

    const avgTimePerQuestion = activeQuiz.questions.length > 0 
      ? Math.round(totalDurationSeconds / activeQuiz.questions.length) 
      : 0;

    const newAttempt: QuizAttempt = {
      id: `attempt_${Date.now()}`,
      quizId: activeQuiz.id,
      quizTitle: activeQuiz.title,
      subject: activeQuiz.subject || 'General',
      difficulty: activeQuiz.difficulty,
      completedAt: new Date().toISOString(),
      totalQuestions: activeQuiz.questions.length,
      correctCount,
      scorePercentage,
      totalDurationSeconds,
      avgTimePerQuestion,
      questionResults: results,
      previousAttemptScore: previousLastScore,
      scoreImprovement,
    };

    // Save attempt
    const updatedAttempts = [newAttempt, ...attempts];
    setAttempts(updatedAttempts);
    saveAttempts(updatedAttempts);

    // Update Quiz Best Score and attemptsCount in library
    const updatedQuizzes = quizzes.map(q => {
      if (q.id === activeQuiz.id) {
        return {
          ...q,
          bestScore: Math.max(q.bestScore ?? 0, scorePercentage),
          bestTimeSeconds: Math.min(q.bestTimeSeconds ?? 999999, totalDurationSeconds),
          attemptsCount: (q.attemptsCount || 0) + 1,
        };
      }
      return q;
    });
    setQuizzes(updatedQuizzes);
    saveQuizzes(updatedQuizzes);
    syncAccountDataToServer(activeUser?.email);

    setActiveAttemptResult(newAttempt);
    setActiveQuiz(null);
  };

  // Exit Test
  const handleExitTest = () => {
    setActiveQuiz(null);
    setCurrentTab('quizzes');
  };

  // Start Targeted Recovery Drill based on missed questions
  const handleStartTargetedDrill = async (missedQuestions: QuestionResult[], subject: string) => {
    sounds.playClick();
    showToast('Creating targeted recovery drill for your missed concepts...', 'info');

    try {
      const data = await safeFetchJson<{ quiz: Quiz }>('/api/generate-targeted-drill', {
        method: 'POST',
        body: JSON.stringify({
          missedQuestions,
          subject,
        }),
      });

      if (data && data.quiz) {
        const drillQuiz: Quiz = {
          ...data.quiz,
          isCustomDrill: true,
        };
        handleSaveNewQuiz(drillQuiz);
        setActiveAttemptResult(null);
        setIsViewingPastAttempt(null);
        handleStartQuiz(drillQuiz);
      } else {
        throw new Error('No drill quiz returned by server');
      }
    } catch (err: any) {
      console.error('Targeted drill error:', err);
      showToast(err?.message || 'Could not create targeted drill. Please try again.', 'info');
    }
  };

  // Save Note in Notebook
  const handleSaveNotebookEntry = (entry: NotebookEntry) => {
    const exists = notebookEntries.find(e => e.id === entry.id);
    let updated: NotebookEntry[];
    if (exists) {
      updated = notebookEntries.map(e => e.id === entry.id ? entry : e);
    } else {
      updated = [entry, ...notebookEntries];
    }
    setNotebookEntries(updated);
    saveNotebook(updated);
    syncAccountDataToServer(activeUser?.email);
    showToast(`Study note "${entry.title}" saved!`);
  };

  const handleDeleteNotebookEntry = (id: string) => {
    sounds.playClick();
    const updated = notebookEntries.filter(e => e.id !== id);
    setNotebookEntries(updated);
    saveNotebook(updated);
    syncAccountDataToServer(activeUser?.email);
    showToast('Note deleted.', 'info');
  };

  // Turn Notebook Note into Quiz
  const handleGenerateTestFromNote = (note: NotebookEntry) => {
    sounds.playClick();
    setPrefilledNoteId(note.id);
    setPrefilledTopic(`Review Test: ${note.title}`);
    setActiveAttemptResult(null);
    setIsViewingPastAttempt(null);
    setCurrentTab('quizzes');
  };

  // Open Concept Coach with Topic
  const handleOpenCoachWithTopic = (concept: string) => {
    sounds.playClick();
    setCoachPrompt(concept);
    setActiveAttemptResult(null);
    setIsViewingPastAttempt(null);
    setCurrentTab('coach');
  };

  // Save Note from Concept Coach or Test Results
  const handleSaveNoteFromExternal = (noteData: { title: string; content: string; tags: string[]; subject: string }) => {
    const newNote: NotebookEntry = {
      id: `note_${Date.now()}`,
      title: noteData.title,
      subject: noteData.subject || 'General',
      content: noteData.content,
      tags: noteData.tags || ['Review'],
      lastUpdated: new Date().toISOString(),
    };
    handleSaveNotebookEntry(newNote);
  };

  // Delete Individual Test Attempt Record
  const handleDeleteAttempt = (attemptId: string) => {
    sounds.playClick();
    const updated = attempts.filter(a => a.id !== attemptId);
    setAttempts(updated);
    saveAttempts(updated);
    showToast('Test attempt log removed.', 'info');
  };

  // Clear All Past Test Records
  const handleClearAllAttempts = () => {
    sounds.playClick();
    setAttempts([]);
    saveAttempts([]);
    showToast('All past test history records cleared.', 'info');
  };

  const subjectStats = calculateSubjectStats(attempts);

  // If user is NOT signed in, render the informative, professional Landing Page
  if (!activeUser) {
    return (
      <>
        <LandingPage
          onGetStarted={() => openAuth('signup')}
          onSignIn={() => openAuth('login')}
        />
        {showAuthModal && (
          <AuthModal
            isOpen={true}
            initialMode={authInitialMode}
            onAuthenticated={handleAuthenticated}
            onClose={() => setShowAuthModal(false)}
          />
        )}
      </>
    );
  }

  // Active Signed-in User App Workspace
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950 relative overflow-x-hidden">
      
      {/* Frosted Glass Ambient Glowing Background */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950 via-slate-950 to-slate-950 opacity-95" />
        <div 
          className="absolute -top-32 -left-32 w-96 h-96 rounded-full blur-3xl opacity-20 transition-colors duration-700" 
          style={{ backgroundColor: THEMES[currentTheme]?.colorHex || '#FACC15' }}
        />
        <div 
          className="absolute top-1/4 -right-32 w-[30rem] h-[30rem] rounded-full blur-3xl opacity-15 transition-colors duration-700" 
          style={{ backgroundColor: THEMES[currentTheme]?.secondaryHex || '#F59E0B' }}
        />
        <div 
          className="absolute bottom-1/3 left-1/4 w-80 h-80 rounded-full blur-3xl opacity-15 transition-colors duration-700" 
          style={{ backgroundColor: THEMES[currentTheme]?.colorHex || '#FACC15' }}
        />
      </div>
      
      {/* Main interactive application container */}
      <div className="relative z-10 flex flex-col min-h-screen">
        
        {/* Navigation Header */}
        <Navbar
          currentTab={currentTab}
          setCurrentTab={(tab) => {
            setIsViewingPastAttempt(null);
            setActiveAttemptResult(null);
            setCurrentTab(tab);
          }}
          isTestActive={!!activeQuiz}
          onNewTestClick={() => {
            setPrefilledTopic('');
            setPrefilledNoteId('');
            setIsViewingPastAttempt(null);
            setActiveAttemptResult(null);
            setCurrentTab('quizzes');
          }}
          soundEnabled={soundEnabled}
          setSoundEnabled={setSoundEnabled}
          streakCount={streakCount}
          activeUser={activeUser}
          onLogout={handleLogout}
          onOpenAuth={() => openAuth('login')}
          currentTheme={currentTheme}
          onOpenThemePicker={() => setShowThemeModal(true)}
        />

        {/* Theme Customizer Modal */}
        <ThemePickerModal
          isOpen={showThemeModal}
          onClose={() => setShowThemeModal(false)}
          currentTheme={currentTheme}
          onSelectTheme={handleSelectTheme}
        />

        {/* Auth Modal (if triggered while logged in to switch account) */}
        {showAuthModal && (
          <AuthModal
            isOpen={true}
            initialMode={authInitialMode}
            onAuthenticated={handleAuthenticated}
            onClose={() => setShowAuthModal(false)}
          />
        )}

        {/* Floating Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 animate-bounce">
            <div className={`px-4 py-3 rounded-2xl shadow-2xl backdrop-blur-xl border flex items-center space-x-2.5 text-xs font-semibold ${
              toastMessage.type === 'success'
                ? 'bg-slate-900/90 text-white border-white/20 shadow-[0_8px_32px_0_rgba(0,0,0,0.4)]'
                : 'bg-indigo-900/90 text-white border-indigo-400/30 shadow-[0_8px_32px_0_rgba(0,0,0,0.4)]'
            }`}>
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>{toastMessage.text}</span>
            </div>
          </div>
        )}

        {/* Main Content Area */}
        <main className="flex-1">
          
          {/* If viewing a completed attempt or past diagnostic report */}
          {(activeAttemptResult || isViewingPastAttempt) ? (
            <TestResultsModal
              attempt={activeAttemptResult || isViewingPastAttempt!}
              onRetakeTest={(quizId) => {
                const q = quizzes.find(item => item.id === quizId);
                if (q) {
                  handleStartQuiz(q);
                }
              }}
              onStartTargetedDrill={handleStartTargetedDrill}
              onSaveNoteToNotebook={handleSaveNoteFromExternal}
              onClose={() => {
                setActiveAttemptResult(null);
                setIsViewingPastAttempt(null);
                setCurrentTab('quizzes');
              }}
              onOpenCoachWithTopic={handleOpenCoachWithTopic}
            />
          ) : currentTab === 'test_session' && activeQuiz ? (
            /* Active Timed Exam Room */
            <ActiveTestSession
              quiz={activeQuiz}
              onCompleteTest={handleCompleteTest}
              onExitTest={handleExitTest}
            />
          ) : currentTab === 'quizzes' ? (
            /* Test Creator, 1-Click Importer & Library */
            <TestGenerator
              quizzes={quizzes}
              notebookEntries={notebookEntries}
              onStartQuiz={handleStartQuiz}
              onDeleteQuiz={handleDeleteQuiz}
              onSaveNewQuiz={handleSaveNewQuiz}
              initialTopic={prefilledTopic}
              initialNoteId={prefilledNoteId}
            />
          ) : currentTab === 'studies' ? (
            /* Studies & Review Guides */
            <StudyNotebook
              entries={notebookEntries}
              onSaveEntry={handleSaveNotebookEntry}
              onDeleteEntry={handleDeleteNotebookEntry}
              onGenerateTestFromNote={handleGenerateTestFromNote}
              onExplainConcept={handleOpenCoachWithTopic}
            />
          ) : currentTab === 'notebook' ? (
            /* Blank Freeform Notebook Canvas */
            <FreeformNotebook
              onGenerateTestFromText={(title, text) => {
                setPrefilledTopic(title);
                setCurrentTab('quizzes');
              }}
            />
          ) : currentTab === 'analytics' ? (
            /* Progress & Diagnostics Analytics */
            <ProgressAnalytics
              attempts={attempts}
              subjectStats={subjectStats}
              onRetakeTest={(quizId) => {
                const q = quizzes.find(item => item.id === quizId);
                if (q) {
                  handleStartQuiz(q);
                }
              }}
              onViewAttemptDetails={(att) => {
                setIsViewingPastAttempt(att);
              }}
              onDeleteAttempt={handleDeleteAttempt}
              onClearAllAttempts={handleClearAllAttempts}
            />
          ) : currentTab === 'coach' ? (
            /* AI Review Coach & Concept Clarifier */
            <AIConceptCoach
              initialPrompt={coachPrompt}
              onSaveToNotebook={handleSaveNoteFromExternal}
              onStartQuizWithTopic={(topic) => {
                setPrefilledTopic(topic);
                setCurrentTab('quizzes');
              }}
            />
          ) : (
            /* Fallback */
            <TestGenerator
              quizzes={quizzes}
              notebookEntries={notebookEntries}
              onStartQuiz={handleStartQuiz}
              onDeleteQuiz={handleDeleteQuiz}
              onSaveNewQuiz={handleSaveNewQuiz}
            />
          )}

        </main>

        {/* Footer */}
        <footer className="border-t border-white/10 bg-slate-950/80 backdrop-blur-xl py-6 mt-12 text-center text-xs text-slate-400">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
            <p className="font-medium text-slate-300">Review You — AI Test Generator, Timed Exam Prep & Notebook Hub</p>
            <p className="text-slate-400">Beat your scores with timed precision & deep diagnostic feedback.</p>
          </div>
        </footer>

      </div>
    </div>
  );
}
